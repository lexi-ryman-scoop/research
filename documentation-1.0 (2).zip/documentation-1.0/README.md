# Scoop Documentation

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/66294c942995cf5e1ba7eb96_Logo%20Black.svg" width="300px" />

Welcome to Scoop's documentation. **Scoop is an autonomous AI data analyst that investigates your data and discovers insights you didn't know to ask for.**

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/683d43f303ddc05fa01b5332_Screenshot%20from%202025-06-01%2023-25-39.png" width="700px" />

*Your AI analyst at work - discovering hidden patterns and insights automatically*

## 🚀 Quick Start

### New to Scoop?
1. [Meet Your AI Data Analyst](docs/Start%20Guide/meet-your-ai-data-analyst.md) - Understand what makes Scoop revolutionary
2. [The Power of Why](docs/Start%20Guide/the-power-of-why.md) - Learn how to trigger investigations, not just queries
3. [Investigation Patterns](docs/Start%20Guide/investigation-patterns.md) - Master the art of asking the right questions

### Ready to Start?
- **[Add to Slack](docs/Scoop%20for%20Slack/scoop-for-slack/getting-started-with-scoop-for-slack.md)** - Start in 1 click, no signup required
- **[Web App](https://go.scoopanalytics.com)** - Full investigation capabilities

## 📚 Key Concepts

### What Makes Scoop Different
- [Scoop vs Traditional BI](docs/comparisons/scoop-vs-traditional-bi.md) - AI analyst vs query builders
- [What is Scoop](docs/Start%20Guide/what-is-scoop.md) - Deep dive into capabilities

### Core Capabilities
- **Investigations**: Multi-probe analysis to answer "why" questions
- **Discovery**: ML-powered pattern and segment finding  
- **Predictions**: Identify what drives outcomes and forecast futures
- **Natural Language**: Describe problems, get investigations

## 🎯 By Use Case

### I Want To...

**Understand Why Something Happened**
- Start with "Why did [metric] [change]?"
- See [The Power of Why](docs/Start%20Guide/the-power-of-why.md)

**Discover Patterns in My Data**
- Start with "Analyze my [data]"
- See [Investigation Patterns](docs/Start%20Guide/investigation-patterns.md)

**Connect My Data**
- [Choose a Data Source](docs/Connecting%20to%20Data/connect-your-data/choose-a-data-source.md)
- [Upload Files](docs/Connecting%20to%20Data/connect-your-data/upload-a-file-or-spreadsheet.md)
- [Connect Apps](docs/Connecting%20to%20Data/connecting-to-a-business-application.md)

**Share Insights**
- [Create Presentations](docs/Canvases/what-is-a-canvas-and-what-can-it-do.md)
- [Use in Slack](docs/Scoop%20for%20Slack/scoop-for-slack/using-scoop-in-channels.md)

## 🔧 Platform Guides

### Scoop for Slack
- [Getting Started](docs/Scoop%20for%20Slack/scoop-for-slack/getting-started-with-scoop-for-slack.md)
- [Working with Datasets](docs/Scoop%20for%20Slack/scoop-for-slack/working-with-datasets-in-scoop-for-slack.md)
- [Advanced Features](docs/Scoop%20for%20Slack/scoop-for-slack/advanced-features.md)

### Web Application
- [Exploring Data](docs/Exploring%20and%20Visualizing%20Data/visualizing-charts-and-tables.md)
- [Creating Canvases](docs/Canvases/what-is-a-canvas-and-what-can-it-do.md)
- [Live Worksheets](docs/Live%20Worksheets/creating-a-livesheet.md)

## 🎓 Advanced Topics

### Data Preparation
- [Dataset Basics](docs/Preparing%20Datasets/scoop-dataset-basics/index.md)
- [Adding Calculated Columns](docs/Preparing%20Datasets/adding-calculated-columns.md)
- [Blending Datasets](docs/Preparing%20Datasets/blending-two-datasets/index.md)

### AI & Machine Learning
- [Understanding Scoop AI](docs/Scoop%20for%20Slack/scoop-for-slack/understanding-scoop-ai.md)
- [ML Analytics](docs/Scoop%20for%20Slack/scoop-for-slack/machine-learning-analytics.md)
- [Process Mining](docs/Process%20Mining/scoop-process-mining.md)

## 🏢 Enterprise Features

### Bring Your Own Key (BYOK)
Use your own Claude or OpenAI API keys with Scoop:
- [BYOK Documentation](docs/Enterprise%20Features/bring-your-own-key-byok.md) - Complete setup guide
- Direct cost control and billing
- Use existing enterprise agreements
- Switch between providers anytime

### Enterprise Resources
- [Enterprise Features Overview](docs/Enterprise%20Features/index.md)
- [Enterprise Slack Sharing](docs/Scoop%20for%20Slack/scoop-for-slack/enterprise-slack-sharing.md)

## 💡 Best Practices

### Do's
- ✅ Ask "why" questions for deep investigations
- ✅ Use natural language, not SQL
- ✅ Let Scoop guide your exploration
- ✅ Trust the investigation process
- ✅ Follow up on discovered insights

### Don'ts
- ❌ Don't write SQL-like queries
- ❌ Don't be overly specific
- ❌ Don't ignore Scoop's suggestions
- ❌ Don't think in terms of single queries
- ❌ Don't pre-filter your questions

## 🆘 Need Help?

- **In Scoop**: Type "help" to see capabilities
- **Support**: support@scoopanalytics.com
- **Community**: Join our Slack community

---

**Remember**: Scoop isn't a query tool - it's your AI data analyst. Stop asking for data, start asking for insights.