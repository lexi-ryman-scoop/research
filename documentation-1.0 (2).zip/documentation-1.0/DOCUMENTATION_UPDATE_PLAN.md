# Scoop Documentation Comprehensive Update Plan

**Created:** December 3, 2025
**Last Updated:** December 3, 2025
**Purpose:** Transform Scoop's end-user documentation into a world-class resource that anticipates customer needs and enables AI-powered customer success workflows.

---

## 🚀 CURRENT STATUS (Read This First After Compaction)

### Session Progress (Dec 3, 2025)

**✅ PHASE 1 COMPLETE (Commit 754764b):**
1. Phase 0 Investigation - Full frontend/backend audit complete
2. Brad's Q&A - All 13 questions answered, decisions captured below
3. New docs created:
   - `docs/Connecting to Data/connect-your-data/importing-html-reports.md` (178 lines)
   - `docs/Connecting to Data/connect-your-data/grouped-reports.md` (175 lines)
4. Stub pages fixed:
   - `oracle-bi.md` expanded (14→79 lines)
   - `crystal-reports.md` expanded (23→136 lines)
   - `tableau.md` expanded (20→142 lines)
5. Enhanced `email-automated-imports.md` with SCOOP_DATE(), attachment types, confirmation emails
6. Removed on-premise deployment (Brad: "NEVER")
7. Added Scoop IP whitelist (`44.231.97.118`) to database docs
8. 13 database pages created earlier in session
9. **P1 Duplicate files consolidated:**
   - `google-analytics-copy.md` → `google-ads.md` (was mislabeled!)
   - `automated-snapshotting-...-copy.md` → `automated-snapshotting-of-excel-365-data.md`
   - Removed `-1` suffixes from 3 files
10. **P1 Video-only pages enhanced with text:**
    - `how-to-create-a-chart.md` (+62 lines)
    - `how-to-save-a-chart.md` (+69 lines)
    - `how-to-create-a-kpi.md` (+86 lines)
    - `how-to-save-a-kpi.md` (+113 lines)
    - `how-to-create-a-presentation.md` (+115 lines)

**✅ PHASE 2 COMPLETE (Commit 22204bc):**
11. **P2 Demo Chat doc** - `docs/AI Analytics/demo-chat.md` (95 lines)
    - Housing + Opportunities demo datasets
    - 20 prompts/day limit, sample questions
12. **P2 Meta Ads doc** - Expanded `meta-facebook-analytics.md` (190 lines)
    - Campaigns, Ad Sets, Ads, Insights extraction
    - 50+ fields, troubleshooting, use cases
13. **P2 Embedded Chat doc** - `docs/Enterprise Features/embedded-chat.md` (197 lines)
    - Token-based auth flow, iframe integration
    - Customization, events API, security model
14. **P2 ML Analysis** - Already exists as "Machine-Learning Playbooks" - no new doc needed

**✅ PHASE 3 PARTIAL (Commit eb6f874):**
15. **P3 Live Query docs** - Already existed (177 lines) - no work needed
16. **P3 App stubs expanded:**
    - `salesloft.md` (18 → 142 lines) - Cadence performance, pipeline analysis
    - `gong.md` (21 → 166 lines) - Forecast tracking, coaching metrics
    - `linkedin.md` (24 → 189 lines) - B2B advertising, cross-channel

**✅ PHASE 3 CONTINUED (Dec 3, 2025):**
17. **P3 Additional app stubs expanded:**
    - `google-data-studio.md` (18 → 147 lines) - Looker Studio, report imports, blending
    - `yardi.md` (19 → 186 lines) - Property management, rent roll, occupancy
    - `outreach.md` (23 → 181 lines) - Sales engagement, sequences, prospect tracking
    - `sharetribe.md` (23 → 207 lines) - Marketplace analytics, transactions, two-sided metrics
    - `sprout-social.md` (23 → 201 lines) - Social media, cross-channel marketing

18. **P3 Final app stubs expanded:**
    - `apolloio.md` (25 → 173 lines) - API connector, sales intelligence, sequences
    - `microsoft-power-bi.md` (25 → 199 lines) - Direct DB connection recommended, DAX preservation
    - `microsoft-reporting-services-ssrs.md` (25 → 225 lines) - Legacy BI, banded reports, email subscriptions
    - `multiple-listing-service-mls.md` (25 → 226 lines) - Real estate, snapshots, marketing ROI

**✅ PHASE 3 METADATA COMPLETE (Commit 07415a0):**
19. **All empty metadata fixed across 62 files:**
    - AI Analytics: 2 files
    - Process Mining: 2 files
    - Recipes + Enterprise: 2 files
    - Live Worksheets: 4 files
    - Preparing Datasets: 10 files
    - Canvases: 13 files
    - Exploring and Visualizing: 8 files
    - Connecting to Data: 21 files (including all specific applications)

**📋 REMAINING WORK:**

| Priority | Task | Est. Size |
|----------|------|-----------|
| P3 | ✅ All metadata filled | Done |
| P4 | Phase 4-7 per plan below | Future |

**🎯 KEY DECISIONS FROM BRAD:**
- Target audience: SMB, midmarket, retail, solopreneurs, tech-savvy
- PowerBI/Tableau messaging: "Connect to SAME backend, better AI" (not import reports)
- Legacy BI: Detail-level data, NOT formatted dashboards
- Demo Chat: Document publicly (Redfin housing is impressive)
- On-premise: NEVER (removed from docs)
- Connector Auto-Config: Skip for now
- Meta Ads: Ready to document
- Video content: Keep and augment, don't delete
- Coming Soon: Elaborate on features, keep vague timelines

**📁 KEY FILES:**
- This plan: `/home/bradpeters/dev/documentation/DOCUMENTATION_UPDATE_PLAN.md`
- Documentation repo: `/home/bradpeters/dev/documentation/`
- Frontend repo: `/home/bradpeters/dev/Single-Canvas-Scoop/`
- Backend repo: `/home/bradpeters/dev/scoop/`

---

## Executive Summary

This plan addresses 147 documentation files across 25 folders, ranging from excellent (Start Guide, AI Analytics) to critically deficient (stub pages, missing features). The goal is to create documentation so comprehensive that it can be fed to AI systems to generate customer-specific action plans.

### Key Metrics
- **Total Files:** 147 markdown files
- **Stub/Placeholder Pages:** 13+ (need content or removal)
- **Duplicate Files:** 5+ (need consolidation)
- **Missing Features:** 12+ major features undocumented (see Phase 2)
- **Application Docs:** 35 apps, highly variable quality (13-338 lines)
- **Report Ingestion:** 6 sophisticated capabilities completely undocumented (HTML, PDF, Banded, JSON, Email, Bulk)

---

## Phase 0: Investigation & Discovery (Pre-Work)

### ✅ 0.1 Codebase Feature Audit - COMPLETED (Dec 3, 2025)
> **Executor:** Claude Code
> **Purpose:** Identify all features that exist in code but lack documentation

- [x] **Frontend Routes Audit** - 25+ routes identified
- [x] **Backend API Audit** - 64+ API actions identified
- [x] **File Ingestion Capabilities** - HTML, PDF, Excel, CSV documented
- [x] **Connector Inventory** - 20 API connectors + JDBC support
- [x] **Deep Report Ingestion Scan** - Comprehensive backend analysis of all ingestion capabilities

**See detailed findings in Appendix D: Investigation Findings below.**
**See Appendix E: Report Ingestion Deep Dive for comprehensive backend analysis.**

### 0.2 Customer Questions Audit
> **Executor:** Brad (requires customer data access)

- [ ] Review last 90 days of support tickets for common questions
- [ ] Review Slack customer channels for frequently asked topics
- [ ] Identify top 10 "I wish the docs explained..." moments
- [ ] List features customers don't know exist

### 0.3 Competitive Documentation Review
> **Executor:** Claude Code

- [ ] Review Tableau documentation structure
- [ ] Review Power BI documentation structure
- [ ] Review Looker documentation structure
- [ ] Identify best practices we should adopt

---

## Phase 1: Critical Fixes (Week 1)

### 1.1 Remove/Hide Broken Pages
> **Priority:** P0 - Embarrassing gaps

| File | Action | Reason |
|------|--------|--------|
| `analyzing-changes-in-explorer.md` | DELETE or HIDE | Says "Need to fix this feature" |
| `oracle-bi.md` | HIDE until content added | Just a logo image |
| `how-to-create-a-chart.md` | Add text content | Video-only, no accessibility |
| `how-to-save-a-chart.md` | Add text content | Video-only |
| `how-to-create-a-kpi.md` | Add text content | Video-only |
| `how-to-save-a-kpi.md` | Add text content | Video-only |
| `how-to-create-a-presentation.md` | Add text content | Video-only |

**Checklist:**
- [ ] Set `hidden: true` on pages with no real content
- [ ] Add written content alongside all video embeds
- [ ] Verify no broken internal links result

### 1.2 Consolidate Duplicate Files

| Keep | Delete/Merge | Reason |
|------|--------------|--------|
| `google-analytics.md` | `google-analytics-copy.md` | Duplicate |
| `automated-snapshotting-of-google-sheets-data.md` | Rename `-copy` version | Actually Excel 365, misleading name |
| `connecting-to-a-database-1.md` | Remove `-1` suffix | Legacy naming |
| `uploading-a-single-report-1.md` | Remove `-1` suffix | Legacy naming |
| `loading-a-spreadsheet-1.md` | Remove `-1` suffix | Legacy naming |

**Checklist:**
- [ ] Audit content differences between duplicates
- [ ] Merge any unique content
- [ ] Delete redundant files
- [ ] Update any internal links
- [ ] Rename `-1` suffix files (check readme.com slug handling)

### 1.3 Add Missing Metadata

Many files have empty metadata:
```yaml
metadata:
  title: ''      # BAD - empty
  description: '' # BAD - empty
```

**Checklist:**
- [ ] Generate SEO-friendly titles for all pages
- [ ] Generate meta descriptions (150-160 chars) for all pages
- [ ] Ensure all pages have `robots: index` (unless intentionally hidden)
- [ ] Add keywords where supported

---

## Phase 2: Missing Feature Documentation (Week 2-3)

### 2.1 Embedded Chat
> **Status:** Feature exists, zero documentation

**Investigation Tasks:**
- [ ] Read `Single-Canvas-Scoop/src/components/screens/SocketChat/EmbeddedSocketChat/`
- [ ] Read `scoop/development/integrations/` for embed docs
- [ ] Read `developerdocumentation/features/embedded/` for technical specs
- [ ] Interview Brad: What are the use cases? Who is this for?

**Documentation to Create:**
- [ ] `docs/Enterprise Features/embedded-chat.md` - Main guide
- [ ] Add to Enterprise Features index
- [ ] Add to main index.md
- [ ] Create setup instructions with screenshots
- [ ] Document authentication flow
- [ ] Document customization options
- [ ] Add troubleshooting section

### 2.2 HTML/Legacy BI Report Ingestion
> **Status:** Major capability, completely undocumented
> **Priority:** P0 - This is a key differentiator for enterprise customers

**✅ Investigation Complete - Backend Capabilities Confirmed:**

| Capability | Implementation | Notes |
|-----------|----------------|-------|
| Standard HTML tables | `IngestedHTMLContent.java` | Full `<table>/<thead>/<tbody>/<tr>/<td>/<th>` support |
| Rowspan/Colspan | `RowSpan.java` class | Properly fills in spanned cells across multiple rows |
| Nested tables | Recursive extraction | Tables within table cells are extracted separately |
| Email text mangling fix | `demangleSpans()` method | Fixes text split by Apple Mail/Gmail clients |
| Link extraction | `DownloadLink.java` | Can download linked CSVs from embedded URLs in emails |
| GZIP handling | Built-in | Handles compressed responses from URLs |

**Key Classes:**
- `IngestedHTMLContent.java` - Main HTML parsing engine (uses JSoup)
- `HTMLDataGrid.java` - HTML table structure handling
- `HTMLCaptureDefinition.java` - Configuration for HTML capture rules

**Confirmed BI Tool Compatibility:**
Works with any tool that exports standard HTML tables:
- ✅ Tableau (HTML export)
- ✅ Crystal Reports (HTML export)
- ✅ SSRS (HTML rendering)
- ✅ Oracle BI (HTML export)
- ✅ Power BI (export to web/HTML)
- ✅ Any web-based report with `<table>` elements

**Documentation to Create:**
- [ ] `docs/Connecting to Data/connect-your-data/importing-html-reports.md`
- [ ] Include: Tableau exports, Crystal Reports, SSRS, Oracle BI, Power BI
- [ ] Step-by-step with screenshots for each BI tool export process
- [ ] Troubleshooting for malformed HTML (JavaScript-rendered tables won't work)
- [ ] Best practices for clean table extraction
- [ ] Email forwarding setup for automated HTML report ingestion

**Key Messaging:**
> "Already have reports from Tableau, Crystal Reports, SSRS, or Power BI? Just export as HTML and upload to Scoop - or forward the email directly. We intelligently extract tables from any HTML report, handling complex layouts with rowspan/colspan automatically. No reformatting required."

**Limitations to Document:**
- JavaScript-rendered tables require pre-rendering (HTML must contain actual `<table>` elements)
- Best results with well-formed HTML (proper table structure)
- Nested tables extracted as separate tables

### 2.3 Demo Chat Modes
> **Routes exist:** `/demo-chat/opportunities`, `/demo-chat/housing`

**Investigation Tasks:**
- [ ] Understand purpose of demo modes
- [ ] Are these customer-facing or internal?
- [ ] Document if customer-facing

### 2.4 Asset Types (Summary, Cluster, Tree)
> **Routes exist but documentation is sparse**

**Investigation Tasks:**
- [ ] Read `Single-Canvas-Scoop/src/components/screens/Asset/`
- [ ] Document each asset type's purpose and use case

**Documentation to Create:**
- [ ] `docs/AI Analytics/asset-types.md` or expand existing docs
- [ ] Summary Asset - what is it, when to use
- [ ] Cluster Asset - ML clustering visualization
- [ ] Tree Asset - decision tree visualization

### 2.5 Insights Screen
> **Route:** `/insights` - Appears to be main AI interface

**Investigation Tasks:**
- [ ] Read `Single-Canvas-Scoop/src/components/screens/Insights/`
- [ ] Understand relationship to AI Analytics docs
- [ ] Is this the "AI Explorer" referenced in docs?

### 2.6 Billing Flow
> **Routes:** `/billing/success`, `/billing/cancel`

**Investigation Tasks:**
- [ ] Is this customer-facing or just callback handling?
- [ ] Document if customers need to understand billing UI

### 2.7 PDF Report Ingestion
> **Status:** Sophisticated capability, completely undocumented
> **Priority:** P1 - Valuable for customers with PDF-based reporting

**✅ Investigation Complete - Backend Capabilities Confirmed:**

| Capability | Implementation | Notes |
|-----------|----------------|-------|
| Text extraction | Spire.PDF library | Multi-page support with per-page processing |
| Header/footer removal | Regex or line count | Configurable patterns or fixed N lines |
| Field extraction | `PDFFieldMatch` | Regex capture groups for metadata |
| Column detection | Space-based algorithm | Scans multiple lines to find alignment |
| Page filtering | `identifyMatch` regex | Process only matching pages |
| Table boundaries | `tableDataStart`/`tableDataEnd` | Regex markers for table regions |

**Key Classes:**
- `IngestedPDFContent.java` - PDF processing orchestrator
- `PDFPageSet.java` - Page-level configuration
- `PDFCaptureDefinition.java` - Field mapping configuration
- `PDFFieldMatch.java` - Regex-based field extraction

**Use Cases:**
- Financial reports with fixed layouts
- Regulatory filings (structured PDFs)
- Vendor invoices with consistent formats
- Any PDF with predictable table structures

**Limitations:**
- Requires capture configuration (not automatic table detection)
- Works best with text-based PDFs (not scanned images)
- Fixed-position reports work better than free-form

**Documentation to Create:**
- [ ] `docs/Connecting to Data/connect-your-data/importing-pdf-reports.md`
- [ ] Capture configuration examples
- [ ] Regex pattern guide for field extraction
- [ ] Troubleshooting for common PDF issues
- [ ] When to use PDF vs HTML export

### 2.8 Banded/Grouped Report Handling
> **Status:** Sophisticated auto-detection, completely undocumented
> **Priority:** P1 - Critical for Salesforce and enterprise ERP reports

**✅ Investigation Complete - Backend Capabilities Confirmed:**

This is a **hidden gem** - Scoop automatically detects and handles grouped/banded reports!

| Capability | Implementation | Notes |
|-----------|----------------|-------|
| Auto group detection | `BandedReportValidator.java` (38KB!) | Detects grouping columns from subtotal placement |
| Multi-level hierarchy | Level 0, 1, 2+ support | Tracks grouping depth per column |
| Subtotal detection | Pattern matching | Finds "subtotal"/"total" rows automatically |
| Subtotal validation | Aggregation verification | Validates subtotals actually sum correctly |
| Grand total handling | Position detection | Finds grand totals at start or end |
| Aggregation rules | Per-column detection | Identifies SUM, AVG, COUNT per column |
| Row type marking | `DataRowType.Subtotal` | Marks rows for filtering/analysis |

**Key Class:** `BandedReportValidator.java` - 38KB of sophisticated grouping logic

**Automatic Processing:**
1. Detects which columns are grouping columns
2. Identifies subtotal rows by pattern and position
3. Validates subtotals are mathematically correct
4. Marks aggregation rules per column
5. Filters data for clean analysis (removes subtotal rows)
6. Preserves grouping metadata for drill-down

**Supported Report Types:**
- ✅ Salesforce banded reports (explicitly supported)
- ✅ SAP reports with group subtotals
- ✅ Oracle reports with multi-level grouping
- ✅ Any Excel/CSV with subtotal rows
- ✅ Pivot-style reports with subtotals

**Documentation to Create:**
- [ ] `docs/Connecting to Data/connect-your-data/grouped-reports.md`
- [ ] Explain automatic subtotal detection
- [ ] Show before/after examples
- [ ] Salesforce-specific guide
- [ ] Best practices for report formatting
- [ ] Troubleshooting when detection fails

**Key Messaging:**
> "Export your Salesforce or SAP banded reports directly - Scoop automatically detects grouping levels, validates subtotals, and separates summary rows from detail data. No manual cleanup required."

### 2.9 Email Report Automation
> **Status:** Partially documented, but missing key details
> **Priority:** P1 - Core automation feature

**✅ Investigation Complete - Backend Capabilities Confirmed:**

| Capability | Implementation | Notes |
|-----------|----------------|-------|
| HTML body extraction | `text_html` content type | Tables extracted from email body |
| CSV attachments | `text_csv` | Direct processing |
| Excel attachments | `application_excel` | Full formula support |
| PDF attachments | `application_pdf` | With capture config |
| ZIP attachments | `application_zip` | Auto-extracts CSVs inside |
| JSON attachments | `json` | JSONPath mapping |
| Date override | `SCOOP_DATE(date)` in subject | Override inferred date |
| Confirmation emails | Automatic | Sent on first successful ingestion |
| Error forwarding | Configurable | Failed ingestions forwarded to admin |

**Key Classes:**
- `IngestEmail.java` - Main email processing
- `IngestEmailLambda.java` - AWS Lambda handler
- `ContentType.java` - Attachment type routing

**Advanced Features:**
- Inbox routing by email recipient or S3 tags
- User-based workspace restriction
- Unique key column detection with feedback
- Success/Warning/Error status in confirmation

**Documentation Gaps to Fill:**
- [ ] Expand `docs/Connecting to Data/connect-your-data/email-automated-imports.md`
- [ ] Document `SCOOP_DATE()` subject line override
- [ ] Document all supported attachment types
- [ ] Document ZIP file handling
- [ ] Add confirmation email examples
- [ ] Troubleshooting for failed ingestions

### 2.10 JSON Data Ingestion
> **Status:** Undocumented capability
> **Priority:** P2 - Developer-focused feature

**✅ Investigation Complete:**

| Capability | Implementation | Notes |
|-----------|----------------|-------|
| JSONPath navigation | `IngestedJsonContent.java` | Access nested structures |
| Array iteration | Built-in | Convert arrays to table rows |
| Column inference | From object keys | Auto-detect column names |
| Timestamp extraction | Configurable | Pull dates from JSON fields |
| Empty column pruning | Automatic | Remove null-only columns |

**Key Classes:**
- `IngestedJsonContent.java` - JSON processing
- `JsonCaptureDefinition.java` - JSONPath configuration
- `JsonPath.java`, `JsonField.java` - Path navigation

**Documentation to Create:**
- [ ] `docs/Connecting to Data/connect-your-data/importing-json-data.md`
- [ ] JSONPath syntax guide
- [ ] Examples for common API response formats
- [ ] Robot/automation integration

---

## Phase 3: Application Documentation Overhaul (Week 3-4)

### 3.1 Create Proper Applications Index

Current `specific-applications/index.md` is 17 lines with one paragraph.

**New Structure:**
```markdown
# Supported Applications

## CRM & Sales
- Salesforce | HubSpot | Pipedrive | Close.com | Attio | Copper CRM

## Marketing & Advertising
- Google Analytics | Meta/Facebook | LinkedIn | Marketo | Sprout Social

## Finance & Accounting
- QuickBooks | NetSuite

## Project Management
- Jira | Monday | Airtable

## Support & Service
- Zendesk

## Data & BI Tools
- Snowflake | Tableau | Power BI | Crystal Reports | Oracle BI | SSRS | Google Data Studio

## Other
- Workday | Yardi | Sharetribe | Gong | Outreach | Salesloft | Apollo | MLS
```

**Checklist:**
- [ ] Create categorized index with descriptions
- [ ] Add "quick start" summary for each category
- [ ] Include connector type badges (API, Robot, Email, Manual)

### 3.2 Establish Minimum Content Standards

**Minimum Viable Documentation (MVD) for each application:**

```markdown
---
title: [Application Name]
---

# [Application Name]

![Logo](logo.png)

## Overview
[2-3 sentences: What is this app, why connect to Scoop]

## What You Can Analyze
- [Bullet list of key objects/data types]

## Connection Method
[API | Robot | Email Forward | Manual Upload]

## Quick Start
1. Step 1
2. Step 2
3. Step 3

## Common Use Cases
- Use case 1
- Use case 2

## Snapshotting Recommendations
[Is snapshotting recommended? What objects?]

## Troubleshooting
- Common issue 1: Solution
- Common issue 2: Solution

## Related Resources
- [Links to recipes, guides]
```

### 3.3 Application Doc Quality Tiers

**Tier 1 - Comprehensive (100+ lines):** Salesforce, HubSpot, Pipedrive, Google Analytics
- Full use cases, recipes, writeback, troubleshooting

**Tier 2 - Standard (50-100 lines):** Most apps
- Core connection, use cases, troubleshooting

**Tier 3 - Stub (currently <25 lines):** Need immediate attention
| App | Current Lines | Action |
|-----|---------------|--------|
| Oracle BI | 13 | Expand or hide |
| Salesloft | 17 | Expand to MVD |
| Google Data Studio | 18 | Expand to MVD |
| Tableau | 19 | Expand to MVD |
| Yardi | 19 | Expand to MVD |
| Gong | 20 | Expand to MVD |
| Crystal Reports | 22 | Expand to MVD |
| Meta/Facebook | 22 | Expand to MVD |
| LinkedIn | 23 | Expand to MVD |
| Outreach | 23 | Expand to MVD |
| Sharetribe | 23 | Expand to MVD |
| Sprout Social | 23 | Expand to MVD |

---

## Phase 4: Section-by-Section Improvements (Week 4-6)

### 4.1 Exploring and Visualizing Data
> **Current State:** Multiple video-only stubs

**Improvements:**
- [ ] Add written content to all video pages
- [ ] Create chart type gallery with examples
- [ ] Document all chart customization options
- [ ] Add "when to use which chart" guide
- [ ] Document filtering and drill-down

### 4.2 Preparing Datasets
> **Current State:** Some hidden placeholders, incomplete

**Improvements:**
- [ ] Remove/fix `analyzing-changes-in-explorer.md`
- [ ] Expand calculated columns documentation
- [ ] Add formula reference/cheatsheet
- [ ] Document column type handling
- [ ] Add data cleaning best practices

### 4.3 Canvases
> **Current State:** Sparse

**Improvements:**
- [ ] Expand prompts documentation
- [ ] Document all canvas object types
- [ ] Add canvas design best practices
- [ ] Document sharing and permissions
- [ ] Add presentation mode documentation

### 4.4 Live Worksheets
> **Current State:** 4 short pages, dated feel

**Improvements:**
- [ ] Modernize language and screenshots
- [ ] Add more use case examples
- [ ] Document Google Sheets integration thoroughly
- [ ] Add Excel 365 integration guide
- [ ] Document formula-driven queries

### 4.5 Process Mining
> **Current State:** Only 3 pages

**Improvements:**
- [ ] Add more process mining examples
- [ ] Document Sankey diagram creation
- [ ] Add funnel analysis guide
- [ ] Document cycle time analysis
- [ ] Add bottleneck detection guide

### 4.6 FOR TEAMS
> **Current State:** Just 1 page

**Improvements:**
- [ ] Expand workspace management
- [ ] Document user roles and permissions
- [ ] Add team onboarding guide
- [ ] Document sharing best practices
- [ ] Add collaboration features

---

## Phase 5: New Content Creation (Week 6-8)

### 5.1 Troubleshooting Hub
> **Currently:** Only Slack FAQ exists

**Create:**
- [ ] `docs/Troubleshooting/index.md` - Central troubleshooting hub
- [ ] `docs/Troubleshooting/connection-issues.md`
- [ ] `docs/Troubleshooting/data-quality.md`
- [ ] `docs/Troubleshooting/performance.md`
- [ ] `docs/Troubleshooting/ai-responses.md`

### 5.2 Glossary
> **Currently:** Does not exist

**Create:**
- [ ] `docs/Reference/glossary.md`
- [ ] Define: Dataset, Inbox, Snapshot, Transactional, Canvas, Recipe, etc.
- [ ] Link from relevant pages

### 5.3 Use Case Library
> **Currently:** Recipes section exists but limited

**Expand:**
- [ ] Sales analytics use cases
- [ ] Marketing analytics use cases
- [ ] Customer success use cases
- [ ] Operations use cases
- [ ] Finance use cases
- [ ] HR/People analytics use cases

### 5.4 FAQ Expansion
> **Currently:** Only Slack FAQ

**Create:**
- [ ] General FAQ for web app
- [ ] Data security FAQ
- [ ] Pricing/billing FAQ
- [ ] Integration FAQ

### 5.5 Quick Reference Cards
> **Currently:** Does not exist

**Create:**
- [ ] Formula reference (Excel-like functions)
- [ ] Keyboard shortcuts
- [ ] Query syntax reference
- [ ] Date format reference

---

## Phase 6: AI-Ready Enhancements (Week 8-10)

### 6.1 Structured Data for AI Consumption

Add frontmatter metadata to enable AI action plan generation:

```yaml
---
title: Connecting to Salesforce
category: integration
subcategory: crm
difficulty: beginner
time_to_complete: 15 minutes
prerequisites:
  - Salesforce account with API access
  - Scoop workspace
outcomes:
  - Salesforce data connected to Scoop
  - Daily snapshots configured
  - First analysis complete
keywords:
  - salesforce
  - crm
  - sales data
  - pipeline
related_recipes:
  - pipeline-investigation
  - sales-forecasting
---
```

### 6.2 Decision Trees for Customer Onboarding

Create structured decision flows:

```markdown
## Choosing Your Data Connection Method

### What type of data source do you have?

**I have a SaaS application (CRM, Marketing, etc.)**
→ Go to [Application Connectors](specific-applications/index.md)

**I have a database (PostgreSQL, Snowflake, etc.)**
→ Go to [Database Connections](databases/index.md)

**I have spreadsheets or CSV files**
→ Go to [File Upload](connect-your-data/upload-a-file-or-spreadsheet.md)

**I have reports from another BI tool**
→ Go to [Importing BI Reports](connect-your-data/importing-html-reports.md)

**I receive reports via email**
→ Go to [Email Automation](connect-your-data/email-automated-imports.md)
```

### 6.3 Customer Journey Maps

Document common customer journeys:

- [ ] **First-time user journey** - Signup to first insight
- [ ] **Sales team journey** - Pipeline analysis setup
- [ ] **Marketing team journey** - Campaign attribution setup
- [ ] **Executive journey** - Dashboard to ad-hoc investigation
- [ ] **Data team journey** - Complex blending and automation

### 6.4 Outcome-Based Organization

Reorganize some content by outcome rather than feature:

- "I want to understand why sales dropped"
- "I want to predict customer churn"
- "I want to track pipeline changes over time"
- "I want to compare this quarter to last quarter"

---

## Phase 7: Quality Assurance (Ongoing)

### 7.1 Link Validation
- [ ] Run link checker across all docs
- [ ] Fix broken internal links
- [ ] Update external links
- [ ] Verify all images load

### 7.2 Screenshot Audit
- [ ] Identify outdated screenshots
- [ ] Capture new screenshots for updated UI
- [ ] Ensure consistent screenshot styling
- [ ] Add alt text to all images

### 7.3 Content Review Cadence

**Monthly:**
- [ ] Review "Coming Soon" sections - remove if shipped
- [ ] Check for new features without docs
- [ ] Update any changed UI references

**Quarterly:**
- [ ] Full link audit
- [ ] Screenshot freshness check
- [ ] Customer feedback review
- [ ] Competitive documentation review

---

## Questions for Brad - ANSWERED (Dec 3, 2025)

### Product Questions

| # | Question | Answer | Action |
|---|----------|--------|--------|
| 1 | **Embedded Chat** - Target audience? | All plans. Target: solopreneurs, tech-savvy people, BI/IT offloading work, understaffed midmarket. Enterprise needs direct sales. For people who search online for solutions. | Document for self-service users |
| 2 | **Demo Chat modes** - Customer-facing? | Yes, both are on public website. Housing uses Redfin's entire market dataset. | Document publicly - will excite prospects |
| 3 | **Asset types** - Relationship to AI? | Output types based on analysis - frontend formats unique textual responses from each | Skip detailed documentation for now |
| 4 | **HTML ingestion** - What works? | PowerBI & Tableau most common (connect to same backend for better AI). SSRS reports from legacy vertical apps. **Key insight:** Don't give complex formatted dashboards - give detail-level source data. We recreate formatting better. | Update docs to emphasize source data over formatted reports |
| 5 | **Connector Auto-Config** | Skip for now, will add soon | Remove from plan |
| 6 | **Meta Ads connector** | Ready to document | Add to Phase 2 |

### Business Questions

| # | Question | Answer | Action |
|---|----------|--------|--------|
| 7 | **Documentation priorities** | SMB, midmarket, and retail | Adjust tone and examples accordingly |
| 8 | **Video content** | Keep if current. ADD and augment. Only remove if demonstrably wrong/outdated. | Don't delete videos, enhance with text |
| 9 | **Coming Soon sections** | Keep but elaborate on what features will be | Expand Coming Soon with details |
| 10 | **Application coverage** | Need to check logs | Future task |

### Technical Questions

| # | Question | Answer | Action |
|---|----------|--------|--------|
| 11 | **IP Allowlist** | Customer sets up on their server. We should document OUR whitelist IPs. | Create IP whitelist reference page |
| 12 | **SSO/SAML** | Leave vague - will do if pressed | Keep Coming Soon, no timeline |
| 13 | **On-Premise** | **NEVER** - remove this | **DELETE from documentation** |

### Key Insights for Documentation Tone

**Target Audience Profile:**
- Solopreneurs and tech-savvy individuals
- BI/IT people wanting to offload work
- Understaffed midmarket companies
- SMB and retail verticals
- People who search online for solutions (not enterprise requiring direct sales)

**Messaging Adjustments:**
1. **PowerBI/Tableau users:** Emphasize connecting to the SAME backend, not importing reports. Better AI, better exploration, leverage existing investment.
2. **Legacy BI (SSRS):** Focus on reading reports from deeply vertical legacy applications.
3. **Data format:** Push for detail-level source data, NOT formatted executive dashboards. We recreate formatting better.
4. **Demo datasets:** Highlight Redfin housing data as impressive real-world example.

---

## Success Metrics

### Quantitative
- [ ] Zero stub pages (all pages > 30 lines of content)
- [ ] Zero duplicate files
- [ ] 100% metadata completion
- [ ] All applications at MVD standard
- [ ] Zero broken links

### Qualitative
- [ ] Documentation can answer 90% of customer questions
- [ ] AI can generate accurate customer action plans from docs
- [ ] New users can complete first analysis without support
- [ ] Support ticket volume decreases

---

## Appendix A: File Inventory by Priority

### P0 - Fix Immediately
```
docs/Preparing Datasets/scoop-dataset-basics/analyzing-changes-in-explorer.md
docs/Connecting to Data/specific-applications/oracle-bi.md
docs/Exploring and Visualizing Data/chart-types/how-to-create-a-chart.md
docs/Exploring and Visualizing Data/chart-types/how-to-save-a-chart.md
docs/Exploring and Visualizing Data/creating-kpis/how-to-create-a-kpi.md
docs/Exploring and Visualizing Data/creating-kpis/how-to-save-a-kpi.md
```

### P1 - Create This Week
```
docs/Enterprise Features/embedded-chat.md (NEW)
docs/Connecting to Data/connect-your-data/importing-html-reports.md (NEW)
docs/Connecting to Data/specific-applications/index.md (REWRITE)
```

### P2 - Expand This Month
```
docs/Connecting to Data/specific-applications/salesloft.md
docs/Connecting to Data/specific-applications/google-data-studio.md
docs/Connecting to Data/specific-applications/tableau.md
docs/Connecting to Data/specific-applications/yardi.md
docs/Connecting to Data/specific-applications/gong.md
[+ 8 more stub application docs]
```

---

## Appendix B: Investigation Commands

For Claude Code to run during execution:

```bash
# Find all routes in frontend
grep -r "path:" Single-Canvas-Scoop/src/router/

# Find all MobileAPI actions
grep -n "case \"" scoop/app/src/main/java/scoop/mobile/MobileAPI.java | head -100

# Find all supported file types
ls scoop/app/src/main/java/scoop/ingest/

# Find all connector definitions
cat Single-Canvas-Scoop/src/api/datasourceConfig.js

# Find HTML parsing capabilities
find scoop/app/src/main/java/scoop -name "*HTML*" -o -name "*Html*"

# Find all undocumented screens
diff <(grep "path:" Single-Canvas-Scoop/src/router/routes.js | sort) \
     <(find documentation/docs -name "*.md" | sort)
```

---

## Appendix C: Content Templates

### Application Documentation Template
```markdown
---
title: [App Name]
excerpt: Connect [App Name] to Scoop for advanced analytics
metadata:
  description: How to connect [App Name] to Scoop Analytics for AI-powered insights
  robots: index
---

# [App Name]

![App Logo](logo.png)

[App Name] integration enables you to [primary value proposition].

## What You Can Analyze

| Object | Description | Snapshot Recommended? |
|--------|-------------|----------------------|
| [Object 1] | [Description] | Yes/No |
| [Object 2] | [Description] | Yes/No |

## Connection Method

**Type:** [API / Robot / Email / Manual]

**Prerequisites:**
- [ ] [Prerequisite 1]
- [ ] [Prerequisite 2]

## Quick Start

### Step 1: [Action]
[Instructions with screenshot]

### Step 2: [Action]
[Instructions with screenshot]

### Step 3: [Action]
[Instructions with screenshot]

## Common Use Cases

### [Use Case 1]
[Description and example question to ask]

### [Use Case 2]
[Description and example question to ask]

## Snapshotting Guide

[When and what to snapshot]

## Troubleshooting

### [Common Issue 1]
**Symptom:** [What user sees]
**Cause:** [Why it happens]
**Solution:** [How to fix]

### [Common Issue 2]
[...]

## Related Resources

- [Recipe: Related Recipe](../Recipes/recipe.md)
- [Guide: Related Guide](../guide.md)
```

### Troubleshooting Page Template
```markdown
---
title: Troubleshooting [Topic]
---

# Troubleshooting [Topic]

## Quick Checks

Before diving deep, verify:
- [ ] Check 1
- [ ] Check 2
- [ ] Check 3

## Common Issues

### Issue: [Problem Description]

**Symptoms:**
- Symptom 1
- Symptom 2

**Possible Causes:**
1. Cause 1
2. Cause 2

**Solutions:**

**For Cause 1:**
```
Step-by-step fix
```

**For Cause 2:**
```
Step-by-step fix
```

**Still stuck?** Contact support@scoopanalytics.com with:
- Your workspace ID
- Screenshot of the error
- Steps to reproduce

---

[Repeat for each issue]
```

---

## Appendix D: Investigation Findings (Dec 3, 2025)

### D.1 Frontend Features Inventory

#### Routes & Screens (25+ identified)

| Route | Screen | Status |
|-------|--------|--------|
| `/login`, `/signup` | Auth | Documented |
| `/onboarding` | Questionnaire | Partially documented |
| `/canvas`, `/canvas/:canvasID` | Canvas Dashboard/Editor | Partially documented |
| `/explorer` | Explorer (Chart Builder) | Partially documented |
| `/insights` | Insights Hub (3 tabs) | **UNDOCUMENTED** |
| `/sources`, `/sources/:inboxID` | Dataset Management | Documented |
| `/account` | Account Settings (4 tabs) | Partially documented |
| `/live-query` | Live Query | **NEW - Just documented** |
| `/live-worksheets` | Live Worksheets | Partially documented |
| `/recipe` | Recipe Box | **UNDOCUMENTED** |
| `/asset` | Asset Viewer | **UNDOCUMENTED** |
| `/accept-invitation` | Team Invitations | Not documented |
| `/demo-chat/opportunities` | Public Demo (Opportunities) | Internal? |
| `/demo-chat/housing` | Public Demo (Housing) | Internal? |
| `/embedded-chat` | Embedded Chat Widget | **UNDOCUMENTED** |
| `/billing/success`, `/billing/cancel` | Billing Flow | Not documented |
| `/canvas/:id/presentation/:slideId` | Presentation Mode | Not documented |

#### Insights Screen - 3 Major Undocumented Features

**Tab 1: Ask Scoop (Chat-Based AI)**
- Natural language query interface
- WebSocket real-time communication
- Processing steps visualization
- Query history and saved queries
- Location: `/src/components/screens/SocketChat/`

**Tab 2: Data Science Discovery Studio (ML)**
- Decision tree/RIPPER model analysis
- Column selection and filtering
- Time series analysis
- Cluster analysis visualization
- Group analysis results
- Location: `/src/components/screens/Insights/ML/`

**Tab 3: Process Analysis (Business Process Mining)**
- Process flow diagram generation
- Sankey diagrams
- Filter and time range controls
- Go-diagram integration
- Location: `/src/components/screens/Insights/Process/`

#### Canvas Object Types (12 types)

| Object | Description | Documentation Status |
|--------|-------------|---------------------|
| Insights | Embedded charts | Partially documented |
| KPI | Key performance indicators | Partially documented |
| Worksheets | Data tables with drill | Partially documented |
| Sheetlets | Data preview widgets | **UNDOCUMENTED** |
| Text Editor | Rich text | Documented |
| Images | Image upload/embedding | Documented |
| Videos | Video embedding | Documented |
| Arrows | Annotation arrows | Not documented |
| Frames | Layout grouping | Not documented |
| Prompts | Saved prompt snippets | Not documented |
| Process Diagrams | Embedded flows | **UNDOCUMENTED** |
| Generic Shapes | Drawing shapes | Not documented |

#### Data Source Connectors (Frontend)

| Connector | Documentation Status |
|-----------|---------------------|
| File Upload | Documented |
| Database (MySQL, PostgreSQL, etc.) | **NEW - Just documented** |
| API Connector (Generic) | Not documented |
| HubSpot | Documented |
| Salesforce | Documented |
| Gmail | Not documented |
| Google Data Studio | Stub only |
| Jira | Documented |
| LinkedIn | Stub only |
| Apollo | Documented |
| Sharetribe | Stub only |
| Email Forward | Not documented |
| Dataset Blending | **UNDOCUMENTED** |

### D.2 Backend Features Inventory

#### File Ingestion Capabilities (KEY FINDING)

| Format | Capability | Documentation Status |
|--------|-----------|---------------------|
| **HTML Tables** | Parses HTML tables from uploaded files with rowspan/colspan handling. **CAN INGEST LEGACY BI TOOL EXPORTS** | **COMPLETELY UNDOCUMENTED** |
| **PDF Table Capture** | Field and table extraction from PDFs | **UNDOCUMENTED** |
| CSV | Full support with column detection | Documented |
| Excel/XLSX | Multi-sheet with formula preservation | Documented |
| Email Attachments | Auto-extraction from reports | Partially documented |
| Google Sheets | Direct sync | Documented |
| Banded Reports | Complex multi-level report layouts | **UNDOCUMENTED** |

**Key Files for HTML Ingestion:**
- `/scoop/datagrid/HTMLDataGrid.java`
- `/scoop/ingest/html/IngestedHTMLContent.java`
- `/scoop/ingest/html/HTMLCaptureDefinition.java`

#### API Connectors (20 confirmed)

Salesforce, HubSpot, Jira, Monday.com, Pipedrive, Quickbooks, Google Analytics, Meta, TikTok, Airtable, Amplitude, Apollo, Attio, Close, Copper, MailerLite, Slack, LinkedIn, Google Data Studio, Zendesk

#### Query Types & ML Capabilities

| Feature | Description | Documentation Status |
|---------|-------------|---------------------|
| Natural Language Query | AI converts questions to SQL | Partially documented |
| Multi-Pass Reasoning | Complex questions with synthesis | **UNDOCUMENTED** |
| ML Classification (CART/RIPPER) | Rule-based ML models | **UNDOCUMENTED** |
| ML Period Analysis | Temporal patterns | **UNDOCUMENTED** |
| ML Group Analysis | Categorical patterns | **UNDOCUMENTED** |
| Clustering | Unsupervised segmentation | **UNDOCUMENTED** |
| Investigation Orchestration | Multi-level drill trees | **UNDOCUMENTED** |

#### AI & Intelligence Features

| Feature | Description | Documentation Status |
|---------|-------------|---------------------|
| AI Insight Generation | Auto-discovery of patterns | Partially documented |
| AI Presentation Generation | Auto-generated slides | Partially documented |
| Domain Intelligence | Learned business context | **UNDOCUMENTED** |
| Dataset Semantics | AI-generated descriptions | Not documented |
| Calculated Fields (Excel formulas) | Excel-compatible formulas | Partially documented |
| AI Formula Generation | NL to formula | Partially documented |

#### Integration Points

| Feature | Description | Documentation Status |
|---------|-------------|---------------------|
| Slack Bot | Query from Slack | Documented |
| Embedded Analytics (JWT) | White-label embedding | **UNDOCUMENTED** |
| BYOK AI Providers | Bring your own Claude/OpenAI | **UNDOCUMENTED** |
| Chargebee Billing | Subscription management | Not customer-facing |
| AppSumo Integration | License management | Not customer-facing |

#### Change & Comparison Analysis

| Feature | Description | Documentation Status |
|---------|-------------|---------------------|
| What's Changed Analysis | Detect changes between snapshots | **UNDOCUMENTED** |
| Snapshot Comparison | Side-by-side comparison | **UNDOCUMENTED** |
| Change Summary | Impact metrics | **UNDOCUMENTED** |

### D.3 Priority Documentation Gaps

**P0 - Must Document (Major Features with Zero Docs)**

1. **HTML Table Extraction** - Can ingest reports from Tableau, Crystal Reports, SSRS, Oracle BI, Power BI
2. **Banded/Grouped Report Auto-Detection** - 38KB of logic that auto-detects subtotals, grouping levels, aggregation rules
3. **Embedded Chat/Analytics** - Enterprise feature for white-label embedding
4. **ML Analysis Tab** - Decision trees, clustering, RIPPER rules
5. **Process Analysis Tab** - Business process mining
6. **Multi-Pass Reasoning** - Complex investigation queries
7. **What's Changed Analysis** - Snapshot comparison

**P1 - Should Document (Significant Gaps)**

1. **PDF Report Ingestion** - Capture configs, field extraction, table detection
2. **Email Automation Details** - SCOOP_DATE(), ZIP handling, all attachment types
3. **JSON Data Ingestion** - JSONPath, array iteration, API response handling
4. Dataset Blending (combining multiple datasets)
5. Sheetlet creation
6. Recipe Box templates
7. BYOK AI provider setup
8. Investigation drilling
9. Domain Intelligence (learned context)

**P2 - Nice to Have**

1. Canvas object types (arrows, frames, shapes)
2. Presentation mode keyboard shortcuts
3. Advanced filtering logic
4. Demo mode explanation
5. Capture definition configuration (advanced users)

### D.4 Recommended New Documentation Pages

Based on investigation, these pages should be created:

**Report Ingestion (Priority - Unique Differentiators):**
1. `docs/Connecting to Data/connect-your-data/importing-html-reports.md` - Legacy BI import (Tableau, Crystal, SSRS, Power BI)
2. `docs/Connecting to Data/connect-your-data/grouped-reports.md` - Banded report auto-detection
3. `docs/Connecting to Data/connect-your-data/importing-pdf-reports.md` - PDF extraction with capture configs
4. `docs/Connecting to Data/connect-your-data/importing-json-data.md` - JSON/API response ingestion

**AI & Analytics:**
5. `docs/AI Analytics/ml-analysis.md` - ML tab features (CART, RIPPER, clustering)
6. `docs/AI Analytics/process-mining.md` - Process analysis tab
7. `docs/AI Analytics/investigations.md` - Multi-pass reasoning
8. `docs/Preparing Datasets/whats-changed.md` - Change analysis between snapshots

**Enterprise Features:**
9. `docs/Enterprise Features/embedded-chat.md` - Embedded analytics with JWT
10. `docs/Enterprise Features/byok-ai.md` - Bring your own API keys

**Other:**
11. `docs/Preparing Datasets/dataset-blending.md` - Combining datasets
12. `docs/Reference/recipe-templates.md` - Recipe box guide

---

## Appendix E: Report Ingestion Deep Dive (Dec 3, 2025)

### E.1 Complete Ingestion Architecture

```
Email/File Source
    ↓
[IngestFile] routes by ContentType
    ↓
[IngestedContent] subclasses parse format
├─ IngestedHTMLContent (JSoup → HTMLDataGrid)
├─ IngestedExcelContent (POI → ExcelDataGrid)
├─ IngestedCSVContent (CSVScanner → CSVDataGrid)
├─ IngestedPDFContent (Spire.PDF → PDFPageSet → CSVDataGrid)
└─ IngestedJsonContent (Jackson → CSVDataGrid)
    ↓
[DataGrid] abstraction layer
├─ Trim blank rows/columns
├─ Prune double spacing
├─ Split on blank row sections
└─ Column type detection
    ↓
[Optional: BandedReportValidator]
├─ Group detection
├─ Subtotal removal
└─ Grand total validation
    ↓
[ReportInstance] → [ReportSeriesTable] → Database load
```

### E.2 Supported Content Types

| ContentType | Extension | Handler | Notes |
|-------------|-----------|---------|-------|
| `text_html` | .html, .htm | `IngestedHTMLContent` | JSoup parsing, table extraction |
| `text_csv` | .csv | `IngestedCSVContent` | RFC4180, section splitting |
| `application_excel` | .xlsx, .xls | `IngestedExcelContent` | POI, formula evaluation |
| `application_pdf` | .pdf | `IngestedPDFContent` | Spire.PDF, capture configs |
| `application_zip` | .zip | `IngestFile` | Auto-extracts, processes CSVs |
| `json` | .json | `IngestedJsonContent` | JSONPath navigation |
| `text_plain` | .txt | Skipped | Not processed |
| `image_*` | .png, .jpg | Skipped | Not processed |

### E.3 HTML Ingestion Technical Details

**Class:** `IngestedHTMLContent.java`
**Library:** JSoup for HTML parsing

**Table Extraction Algorithm:**
1. Parse HTML with JSoup
2. Find all `<table>` elements
3. For each table:
   - Extract header row from `<thead>` or first `<tr>` with `<th>` elements
   - Extract data rows from `<tbody>` or remaining `<tr>` elements
   - Handle `rowspan` by duplicating cell values across rows
   - Handle `colspan` by duplicating cell values across columns
   - Recursively extract nested tables (tables within `<td>`)
4. Create `HTMLDataGrid` for each extracted table

**Special Features:**
- `demangleSpans()` - Fixes email client text mangling (Apple Mail, Gmail split text into spans)
- `DownloadLink` - Extracts and downloads linked files from HTML (e.g., CSV links)
- Handles GZIP-compressed downloads

**Cell Types:**
- `HTMLCell` - Preserves original HTML content as text
- Numeric detection for cells containing only numbers
- Date detection for common date formats

### E.4 PDF Ingestion Technical Details

**Class:** `IngestedPDFContent.java`
**Library:** Spire.PDF for text extraction

**Configuration Structure (PDFCaptureDefinition):**
```java
PDFPageSet {
    headerMatch: String     // Regex to remove header
    footerMatch: String     // Regex to remove footer
    headerLines: int        // Fixed lines to remove from top
    footerLines: int        // Fixed lines to remove from bottom
    identifyMatch: String   // Regex to filter which pages to process
    tableDataStart: String  // Regex marking table start
    tableDataEnd: String    // Regex marking table end (optional)
    fieldMatches: PDFFieldMatch[]  // Metadata field extraction
    pageTable: PDFPageTable        // Column configuration
}
```

**Field Extraction (PDFFieldMatch):**
```java
PDFFieldMatch {
    patternBefore: String   // Regex before value
    patternAfter: String    // Regex after value (optional)
    columnName: String      // Target column name
    maxLength: int          // Maximum value length
    inferTimestamp: boolean // Parse as date
    caseSensitive: boolean  // Match case
}
```

**Column Detection Algorithm:**
1. Collect text from multiple rows
2. Find consistent whitespace positions across rows
3. Use whitespace boundaries as column separators
4. Apply to remaining rows for data extraction

### E.5 Banded Report Detection Details

**Class:** `BandedReportValidator.java` (38KB - substantial logic!)

**Detection Algorithm:**
1. **Group Column Detection:**
   - Scan for columns where values change when subtotal rows appear
   - Track "grouping level" per column (0 = innermost, higher = outer)

2. **Subtotal Row Detection:**
   - Pattern match: rows containing "subtotal", "total", "sub-total"
   - Position analysis: rows following group boundary changes
   - Value validation: check if numeric columns sum correctly

3. **Aggregation Rule Detection:**
   - Compare subtotal values to detail row values
   - Detect: SUM, AVG, COUNT, MIN, MAX per column
   - Mark non-additive columns separately

4. **Grand Total Validation:**
   - Detect grand total at report start or end
   - Validate grand total = sum of all subtotals
   - Handle non-additive grand totals gracefully

**Output:**
- Detail rows only (subtotals filtered out)
- Column metadata with aggregation rules
- Grouping hierarchy preserved for drill-down
- `DataRowType` markers on original rows

### E.6 Email Processing Details

**Classes:** `IngestEmail.java`, `IngestEmailLambda.java`

**Routing Logic:**
1. Check S3 tag `inboxName` → direct routing
2. Check email recipient address → inbox name match
3. Check subject line patterns → inbox name inference

**Special Subject Line Commands:**
- `SCOOP_DATE(2024-01-15)` - Override inferred date
- `SCOOP_DATE(January 15, 2024)` - Flexible date parsing

**Confirmation Email Flow:**
1. First successful ingestion triggers confirmation
2. HTML template with inline Scoop logo
3. Includes: row count, column count, unique key detection
4. Status: Success (green), Warning (yellow), Error (red)

**Error Handling:**
- Failed ingestions forwarded to configured admin email
- Detailed error message in forwarded email
- Event log entry for debugging

### E.7 Excel-Specific Features

**Class:** `IngestedExcelContent.java`
**Library:** Apache POI

**Named Range Support:**
- Define named ranges in Excel (e.g., "SalesData")
- Reference by name in Scoop configuration
- Scoop extracts only the named range

**Formula Evaluation:**
- Uses `MemWorkbook` calculation engine
- Evaluates formulas to get computed values
- Handles most Excel functions

**Date Detection:**
- Recognizes Excel date formats
- Converts to proper Date objects
- Disabled for files >2000 rows (performance)

**Multi-Sheet Handling:**
- Process specific sheet by name or index
- Extract multiple sheets as separate tables

### E.8 JSON-Specific Features

**Class:** `IngestedJsonContent.java`
**Library:** Jackson

**JSONPath Navigation:**
```java
JsonCaptureDefinition {
    arrayPath: String       // Path to array (e.g., "$.data.records")
    fields: JsonField[]     // Column mappings
}

JsonField {
    path: String            // JSONPath within each array element
    columnName: String      // Target column name
    inferTimestamp: boolean // Parse as date
}
```

**Array Iteration:**
- Navigate to array using JSONPath
- Each array element becomes a row
- Object keys become column names

**Nested Object Handling:**
- Use dot notation: `address.city`
- Use array index: `items[0].name`
- Flatten nested structures to columns

### E.9 Bulk Load for Massive Files

**Command:** `./scripts/runscoop --bulkload`
**Class:** `BulkCSVLoader.java`

For files 10GB+:
- Bypasses normal ingestion pipeline
- Direct `LOAD DATA INFILE` to ColumnStore
- 10-100x faster than row-by-row insert
- Tested with 130GB, 156M row file (EZCorp project)

**Usage:**
```bash
./scripts/runscoop --bulkload /path/to/huge.csv \
  --workspaceID W123 \
  --inboxName "Dataset Name" \
  --clusterId ezcorp
```

---

*This plan will be updated as investigation phases complete and priorities shift.*
