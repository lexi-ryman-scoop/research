# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with the documentation in this repository.

## MDX Validation Issues with readme.com

### Problem
When pushing documentation to readme.com, some Markdown files may be rejected as having "invalid MDX" even though they work fine as regular Markdown. MDX parsers are stricter than regular Markdown parsers because they need to handle JSX/React components.

### Common MDX Parsing Issues

1. **Angle Brackets in Tables**
   - **Issue**: `<10K`, `>1M`, `<2 hours` in table cells are interpreted as unclosed HTML/JSX tags
   - **Solution**: Replace with words: `Less than 10K`, `More than 1M`, `Less than 2 hours`
   - **Example**: 
     ```markdown
     ❌ | <10K | Instant | Check connection |
     ✅ | Less than 10K | Instant | Check connection |
     ```

2. **Escaped Image Syntax**
   - **Issue**: `!\[Screenshot: description]` (with backslash) is invalid
   - **Solution**: Remove the backslash: `![Screenshot: description]`
   - **Note**: This appears in working files too, so may not always be the issue

3. **Special Characters**
   - MDX can be sensitive to certain character combinations
   - Emojis, ampersands (&), and arrow symbols (→) are generally fine
   - The issue is usually more specific, like angle brackets

### Debugging Process

1. **Check for angle brackets**: Search for `<` and `>` symbols, especially in tables
   ```bash
   grep -n "[<>]" filename.md
   ```

2. **Test incrementally**: Create minimal versions to isolate the issue
3. **Focus on table content**: MDX parsers are particularly strict about table cell content

### Files Fixed (July 2025)
- `faq-troubleshooting.md` - Fixed `<10K`, `>1M`, and `<2 hours` in tables
- `machine-learning-analytics.md` - No issues found (already MDX-compliant)
- `understanding-scoop-ai.md` - No issues found (already MDX-compliant)

### Best Practices for MDX-Compatible Markdown

1. **Avoid angle brackets in content**: Use "Less than" / "More than" instead of < >
2. **Use standard image syntax**: `![alt text]` not `!\[alt text]`
3. **Test with MDX parser**: Consider using an MDX linter before pushing to readme.com
4. **Keep original formatting**: Emojis, special characters, and formatting are generally fine

## Documentation Structure

The Slack documentation is located in:
```
/home/brad-peters/dev/documentation/docs/Scoop for Slack/scoop-for-slack/
```

Key files include:
- FAQ & Troubleshooting
- Machine Learning Analytics  
- Understanding Scoop AI
- Various guides for Slack integration features