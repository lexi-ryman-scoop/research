---
title: Security & Compliance
excerpt: How Scoop protects your data and meets enterprise requirements
deprecated: false
hidden: false
metadata:
  title: Security & Compliance - Scoop Analytics
  description: Learn about Scoop's security architecture, data protection, and compliance certifications including SOC 2.
  robots: index
---

# Security & Compliance

Scoop is built for enterprise security requirements. This document outlines our security architecture, data protection practices, and compliance certifications.

---

## Security Overview

### Data Protection Principles

| Principle | Implementation |
|-----------|----------------|
| **Encryption at Rest** | All data encrypted using AES-256 |
| **Encryption in Transit** | TLS 1.2+ for all communications |
| **Data Isolation** | Multi-tenant architecture with strict isolation |
| **Access Control** | Role-based permissions at workspace level |
| **Audit Logging** | Comprehensive activity logging |

---

## Infrastructure Security

### Cloud Architecture

Scoop runs on AWS with enterprise-grade security:

- **Compute**: AWS Lambda and ECS with isolated execution environments
- **Database**: Amazon RDS with encryption enabled
- **Storage**: Amazon S3 with server-side encryption
- **Networking**: VPC with private subnets, security groups, and NACLs

### Network Security

- All external traffic over HTTPS (TLS 1.2+)
- Web Application Firewall (WAF) protection
- DDoS protection via AWS Shield
- No direct database access from internet

### Availability

- Multi-AZ deployment for high availability
- Automated backups with point-in-time recovery
- 99.9% uptime SLA for enterprise customers

---

## Data Security

### Data Encryption

**At Rest:**
- All databases encrypted with AES-256
- S3 buckets use server-side encryption (SSE-S3)
- Encryption keys managed by AWS KMS

**In Transit:**
- TLS 1.2+ required for all connections
- HTTPS enforced for web and API access
- WebSocket connections secured with WSS

### Data Isolation

Scoop uses a multi-tenant architecture with strict data isolation:

- Each workspace has isolated data storage
- Cross-tenant data access is architecturally impossible
- Database queries scoped to tenant context
- No shared data between organizations

### Data Residency

- Primary data centers in US (AWS us-east-1, us-west-2)
- Enterprise customers can request specific region deployment
- Contact sales for EU data residency requirements

---

## Access Control

### Authentication

**Supported Methods:**
- Email/password with secure password requirements
- Google OAuth (SSO)
- Enterprise SSO via SAML (on request)

**Session Security:**
- Secure, HTTP-only session cookies
- Automatic session timeout after inactivity
- Concurrent session limits

### Authorization

**Role-Based Access Control:**

| Role | Capabilities |
|------|--------------|
| **Owner** | Full account control, billing, user management |
| **Admin** | Workspace management, user invites, settings |
| **Member** | View and analyze data, create content |
| **Viewer** | Read-only access to shared content |

**Workspace Permissions:**
- Users can be assigned to specific workspaces
- Dataset-level access controls
- Channel-specific sharing for Slack integration

### API Security

- API keys for programmatic access (Enterprise)
- Keys are hashed and never stored in plaintext
- Scoped permissions per API key
- Rate limiting to prevent abuse

---

## Compliance

### SOC 2 Type II

Scoop maintains SOC 2 Type II certification, demonstrating:

- **Security**: Protection against unauthorized access
- **Availability**: System availability per SLA commitments
- **Confidentiality**: Protection of confidential information
- **Processing Integrity**: Accurate and complete processing
- **Privacy**: Personal information handling per privacy notice

*Contact sales for SOC 2 report access.*

### Additional Compliance

- **CCPA**: California Consumer Privacy Act compliance
- **HIPAA**: Available for healthcare customers (BAA required)

---

## Security Practices

### Secure Development

- Secure coding practices and code review
- Dependency vulnerability scanning
- Static application security testing (SAST)
- Regular penetration testing by third parties

### Incident Response

- 24/7 security monitoring
- Documented incident response procedures
- Customer notification within 72 hours for breaches
- Post-incident analysis and remediation

### Employee Security

- Background checks for all employees
- Security awareness training
- Principle of least privilege access
- Secure remote work policies

---

## Data Handling

### Data Retention

| Data Type | Retention |
|-----------|-----------|
| User data/datasets | Until account deletion |
| Activity logs | 90 days |
| Backup data | 30 days |
| Deleted content | Purged within 30 days |

### Data Deletion

When you delete data or close your account:
- Data removed from active systems immediately
- Removed from backups within 30 days
- Deletion is irreversible

**Account Deletion:**
Contact support@scoopanalytics.com to request full account deletion.

### Data Export

You can export your data at any time:
- Download datasets in CSV format
- Export presentations to PowerPoint
- API access for bulk data export (Enterprise)

---

## Third-Party Security

### Sub-processors

Scoop uses the following sub-processors:

| Provider | Purpose | Location |
|----------|---------|----------|
| AWS | Cloud infrastructure | US |
| Anthropic | AI processing (Claude) | US |
| OpenAI | AI processing (optional) | US |

*Full sub-processor list available on request.*

### AI Data Handling

When you use Scoop's AI features:
- Your data is sent to AI providers for processing
- Data is not used to train AI models
- Processing occurs in real-time, not stored by providers
- Enterprise customers can use BYOK for direct AI provider relationship

---

## Enterprise Security Features

### Available for Enterprise Plans:

- **Single Sign-On (SSO)**: SAML integration with your IdP
- **Advanced Audit Logs**: Extended retention and export
- **Custom Data Retention**: Configure per your policies
- **Dedicated Support**: Named security contact
- **Security Review**: Annual security questionnaire assistance
- **BYOK AI**: Use your own AI provider API keys

---

## Reporting Security Issues

### Responsible Disclosure

If you discover a security vulnerability:

1. **Email**: security@scoopanalytics.com
2. **Include**: Description, steps to reproduce, potential impact
3. **Do Not**: Access other users' data or disrupt services
4. **We Will**: Acknowledge within 48 hours, provide updates

We appreciate security researchers and will credit those who report valid issues (with permission).

---

## Contact

**Security Team:** security@scoopanalytics.com

**Privacy Questions:** privacy@scoopanalytics.com

**Compliance Documents:** Contact your account manager or sales@scoopanalytics.com

---

*Last Updated: November 2025*
