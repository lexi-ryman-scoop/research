---
title: Admin Guide
excerpt: Managing users, workspaces, and settings in Scoop
deprecated: false
hidden: false
metadata:
  title: Admin Guide - Scoop Analytics
  description: How to manage users, workspaces, permissions, and account settings in Scoop Analytics.
  robots: index
---

# Admin Guide

This guide covers administrative tasks for Scoop account owners and admins, including user management, workspace configuration, and account settings.

---

## User Management

### Inviting Users

**To invite a new user:**

1. Go to **Account Settings** → **Users**
2. Click **Invite User**
3. Enter their email address
4. Select their role (Admin, Member, or Viewer)
5. Choose which workspaces they can access
6. Click **Send Invite**

The user will receive an email with instructions to create their account.

### User Roles

| Role | Permissions |
|------|-------------|
| **Owner** | Full account control: billing, users, all settings |
| **Admin** | Manage users, workspaces, and settings (except billing) |
| **Member** | Create and analyze data, share content |
| **Viewer** | View shared dashboards and presentations only |

### Managing Existing Users

**To change a user's role or access:**

1. Go to **Account Settings** → **Users**
2. Find the user in the list
3. Click the **Edit** icon
4. Modify role or workspace access
5. Click **Save**

**To remove a user:**

1. Go to **Account Settings** → **Users**
2. Find the user
3. Click **Remove** → Confirm

> **Note**: Removing a user does not delete content they created. Their datasets and visualizations remain accessible to other users.

---

## Workspace Management

### What Are Workspaces?

Workspaces are containers for organizing datasets, analyses, and users. Use them to:
- Separate different teams or departments
- Organize by project or client
- Control data access

### Creating a Workspace

1. Go to **Workspaces** in the main navigation
2. Click **Create Workspace**
3. Enter a name and optional description
4. Click **Create**

### Workspace Settings

Each workspace has its own settings:

| Setting | Description |
|---------|-------------|
| **Name** | Display name for the workspace |
| **Description** | Optional context for users |
| **Default Dataset** | Dataset loaded by default for new queries |
| **Members** | Users who can access this workspace |

### Managing Workspace Members

**To add users to a workspace:**

1. Open the workspace
2. Go to **Settings** → **Members**
3. Click **Add Members**
4. Select users from your account
5. Click **Add**

**To remove users:**

1. Open workspace **Settings** → **Members**
2. Click **Remove** next to the user

---

## Dataset Permissions

### Access Levels

Datasets can have different access levels:

| Level | Who Can Access |
|-------|----------------|
| **Private** | Only the creator |
| **Workspace** | All workspace members |
| **Shared** | Specific users you select |

### Changing Dataset Access

1. Open the dataset
2. Go to **Settings** → **Sharing**
3. Select access level
4. If "Shared", add specific users
5. Click **Save**

### Dataset Ownership

Each dataset has an owner (the creator by default). Owners can:
- Delete the dataset
- Change access settings
- Transfer ownership to another user

---

## Slack Integration Management

### Connecting Slack

1. Go to **Account Settings** → **Integrations**
2. Click **Connect Slack**
3. Authorize Scoop in your Slack workspace
4. Select default workspace for Slack queries

### Channel Dataset Sharing

Control which datasets are available in specific Slack channels:

1. Go to **Account Settings** → **Slack** → **Channel Settings**
2. Select a channel
3. Choose which datasets are accessible
4. Click **Save**

This allows different teams to see only relevant data in their channels.

### Slack User Mapping

Scoop automatically maps Slack users to Scoop accounts by email. For users without Scoop accounts:
- They can view shared insights in channels
- DM queries require a Scoop account
- Invite them to enable full functionality

---

## Account Settings

### General Settings

Access via **Account Settings** → **General**:

| Setting | Description |
|---------|-------------|
| **Account Name** | Your organization's display name |
| **Default Workspace** | Workspace new users see first |
| **Time Zone** | Default time zone for reports |

### AI Provider Settings

Configure how Scoop uses AI:

**System Default:**
- Uses Scoop's AI allocation
- No additional configuration needed

**Bring Your Own Key (BYOK):**
- Use your own Claude or OpenAI API key
- Direct billing with AI provider
- See [BYOK Guide](bring-your-own-key-byok.md) for setup

### Billing & Subscription

Access via **Account Settings** → **Billing**:

- View current plan and usage
- Update payment method
- Download invoices
- Upgrade or change plan

> **Note**: Only Account Owners can access billing settings.

---

## Data Connections

### Managing Connected Apps

View and manage data source connections:

1. Go to **Account Settings** → **Data Connections**
2. See all active connections
3. Click a connection to view details or disconnect

### Connection Health

Scoop monitors connection health automatically:

| Status | Meaning |
|--------|---------|
| ✅ **Active** | Connection working normally |
| ⚠️ **Warning** | Recent sync issues, may need attention |
| ❌ **Error** | Connection failed, requires action |

**To fix a failed connection:**
1. Click the connection
2. Review the error message
3. Re-authenticate or update credentials
4. Test the connection

### Scheduled Syncs

For connected data sources, configure sync frequency:

- **Real-time**: Sync on every query (API sources)
- **Hourly**: Update every hour
- **Daily**: Update once per day
- **Manual**: Only sync when triggered

---

## Security Settings

### Password Requirements

Account-wide password policy:
- Minimum 8 characters
- Must include uppercase, lowercase, and number
- Cannot reuse recent passwords

### Session Management

Configure session timeout:
1. Go to **Account Settings** → **Security**
2. Set **Session Timeout** (default: 24 hours)
3. Optionally enable **Require re-auth for sensitive actions**

### Two-Factor Authentication

Enable 2FA for enhanced security:
1. Go to **Account Settings** → **Security**
2. Click **Enable 2FA**
3. Follow setup instructions

> **Enterprise**: Enforce 2FA for all users in account settings.

---

## Audit & Activity

### Activity Logs

View account activity:
1. Go to **Account Settings** → **Activity**
2. Filter by user, action type, or date range
3. Export logs as CSV (Enterprise)

**Logged Activities:**
- User logins and logouts
- Data uploads and connections
- Query execution
- Sharing and permission changes
- Settings modifications

### Audit Requirements

For compliance and security audits:
- Activity logs retained for 90 days (standard)
- Extended retention available (Enterprise)
- Export capabilities for external audit tools

---

## Troubleshooting

### Common Admin Issues

**User can't access a workspace:**
- Verify they're added to the workspace members
- Check their role has sufficient permissions
- Ensure workspace isn't restricted

**Data connection not syncing:**
- Check connection status in Data Connections
- Re-authenticate if credentials expired
- Verify source system is accessible

**Slack integration not working:**
- Ensure Scoop app is installed in Slack workspace
- Check channel dataset permissions
- Verify user email matches Scoop account

### Getting Help

**Support Resources:**
- Email: support@scoopanalytics.com
- Documentation: docs.scoopanalytics.com
- Status page: status.scoopanalytics.com

**Enterprise Support:**
- Dedicated support contact
- Priority response times
- Scheduled check-ins

---

## Best Practices

### User Management
- Use meaningful role assignments (don't over-provision Admin)
- Regularly audit user access
- Remove users promptly when they leave

### Workspace Organization
- Create workspaces by team or function
- Use clear naming conventions
- Document workspace purposes in descriptions

### Data Governance
- Review dataset permissions quarterly
- Use workspace-level sharing for team data
- Keep sensitive data in restricted workspaces

---

*Last Updated: November 2025*
