---
title: CRM Writeback
excerpt: 'Push calculated values back to your CRM automatically'
deprecated: false
hidden: false
metadata:
  title: CRM Writeback
  description: >-
    Scoop allows you to blend data, create new fields, and write back calculated
    values into your CRM by establishing an API connection and mapping fields
    from your dataset to your CRM. This enables seamless updates to your CRM
    with sophisticated calculations from Scoop.
  robots: index
next:
  description: ''
---

CRM Writeback lets you push calculated values from Scoop back into your CRM system. Blend data from multiple sources, create sophisticated calculations, and automatically update your CRM with the results—enabling enriched customer records without manual data entry.

# Why Use CRM Writeback?

| Use Case | Description |
|----------|-------------|
| **Customer Health Scores** | Calculate scores from multiple data sources, write to CRM |
| **Lead Scoring** | Combine behavioral data with firmographics for enriched leads |
| **Territory Assignment** | Calculate optimal territory and update account records |
| **Lifecycle Stage** | Determine customer lifecycle position from activity data |
| **Propensity Scores** | Calculate purchase likelihood and push to sales records |
| **Data Enrichment** | Add external data attributes to CRM records |

# How It Works

```
┌────────────────────────────────────────────────────────────┐
│ 1. EXTRACT                                                  │
│    CRM Data → Scoop Dataset (includes Record ID)           │
├────────────────────────────────────────────────────────────┤
│ 2. ENRICH                                                   │
│    Blend with other data sources                           │
│    Add calculated columns                                   │
│    Create derived metrics                                   │
├────────────────────────────────────────────────────────────┤
│ 3. WRITEBACK                                                │
│    Scoop → CRM (using Record ID)                           │
│    Automatic on each dataset processing                    │
└────────────────────────────────────────────────────────────┘
```

# Supported CRMs

CRM Writeback is available for systems with API connections:

- Salesforce
- HubSpot
- Microsoft Dynamics 365
- Other CRMs with API connectors

See specific application documentation for connector details.

# Setting Up CRM Writeback

## Prerequisites

Before configuring writeback:

1. **API Connection** — Establish API connection to your CRM
2. **Record ID** — Extract records with their unique CRM Record ID
3. **Calculated Data** — Create the values you want to write back

## Step 1: Extract CRM Data with Record ID

When extracting from your CRM, include the Record ID column:

- **Salesforce**: `Id` field
- **HubSpot**: `record_id` or object-specific ID
- **Dynamics**: `accountid`, `contactid`, etc.

**Critical:** The Record ID is required to update the correct records.

## Step 2: Create Calculated Values

Option A: **Calculated Columns**
- Add formulas directly to your CRM dataset
- Use spreadsheet functions for calculations
- See [Adding Calculated Columns](../Preparing%20Datasets/adding-calculated-columns)

Option B: **Blended Dataset**
- Combine CRM data with other sources
- Preserve the Record ID through the blend
- Always include Record ID in column selection

## Step 3: Configure Writeback

Once your dataset has calculated values and Record IDs:

1. Open the dataset menu
2. Select **Setup Application Writeback**

<Image align="center" width="300px" src="https://files.readme.io/04a04ab-image.png" />

## Step 4: Map Fields

In the writeback configuration:

<Image align="center" width="400px" src="https://files.readme.io/3b94bc6-image.png" />

1. Select the **source table** from your dataset
2. Map **Scoop columns** to **CRM fields**
3. Specify which column contains the Record ID

<Image align="center" width="400px" src="https://files.readme.io/244a1d5-image.png" />

For each CRM field you want to update:
- Select the Scoop column that contains the value
- Verify data types are compatible

## Step 5: Activate Writeback

Save your configuration. Now:
- Each time the dataset processes, writeback runs automatically
- Values are pushed to your CRM using the Record IDs
- CRM records update with calculated values

# Common Writeback Scenarios

## Customer Health Score

**Data Sources:**
- CRM: Account info, contract value
- Support: Ticket volume, resolution time
- Product: Usage metrics, feature adoption

**Calculation:**
```
Health Score = (Usage Score × 0.4) + (Support Score × 0.3) + (Engagement Score × 0.3)
```

**Writeback:**
- Map `Health_Score` column → CRM `Customer_Health__c` field
- Sales team sees scores directly in CRM

## Lead Scoring

**Data Sources:**
- CRM: Lead demographics, company size
- Marketing: Email engagement, website visits
- Third-party: Firmographic enrichment

**Calculation:**
```
Lead Score = Demographic Score + Behavioral Score + Fit Score
```

**Writeback:**
- Map `Lead_Score` → CRM lead score field
- Marketing automation triggers based on score

## Cost to Serve

**Data Sources:**
- CRM: Account and revenue data
- Support: Tickets and time spent
- Finance: Service costs allocated

**Calculation:**
```
Cost to Serve = Total Support Cost / Revenue
```

**Writeback:**
- Map `Cost_to_Serve` → Account custom field
- Account managers see profitability context

# Best Practices

## Data Quality

- Validate calculations before enabling writeback
- Test with a small subset first
- Monitor for unexpected values

## Record ID Handling

- **Never modify** the Record ID column
- **Always include** Record ID when blending
- **Verify** Record IDs match CRM format

## Field Mapping

- Match data types (text to text, number to number)
- Consider field length limits
- Check for required field dependencies

## Processing Schedule

- Writeback runs each time dataset processes
- Schedule during off-peak hours for large updates
- Monitor CRM API limits

# Troubleshooting

## Records Not Updating

- Verify Record ID column is correctly mapped
- Check Record IDs exist in the CRM
- Confirm API connection is active

## Partial Updates

- Check for null values in Scoop columns
- Verify data type compatibility
- Look for CRM validation rule failures

## API Errors

- Check CRM API rate limits
- Verify user permissions for field updates
- Review API connection status

## Wrong Values Written

- Review calculation logic
- Check for data type conversions
- Verify correct column is mapped

# Monitoring Writeback

Track writeback success:

- Check dataset processing logs
- Monitor CRM field update timestamps
- Verify sample records after processing

# Security Considerations

- Writeback uses your established API credentials
- Only fields you map will be updated
- Changes are logged in both Scoop and CRM
- Consider which users can configure writeback

# Related Topics

- [HubSpot Integration](../Connecting%20to%20Data/specific-applications/hubspot) - HubSpot-specific writeback
- [Adding Calculated Columns](../Preparing%20Datasets/adding-calculated-columns) - Create derived values
- [Blending Datasets](../Preparing%20Datasets/blending-two-datasets/index) - Combine multiple sources
- [Application Connectors](../Connecting%20to%20Data/specific-applications/index) - Connect to your CRM
