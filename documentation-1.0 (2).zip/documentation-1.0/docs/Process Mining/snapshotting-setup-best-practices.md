---
title: Snapshotting Setup & Best Practices
excerpt: >-
  Snapshotting is one of Scoop's most powerful sales and revenue operations
  functionalities. It enables historical pipeline tracking by capturing daily
  snapshots of your data, allowing you to analyze how records progress through
  different stages over time.
deprecated: false
hidden: false
metadata:
  robots: index
---
Snapshotting is one of Scoop's most powerful sales and revenue operations functionalities. It enables historical pipeline tracking by capturing daily snapshots of your data, allowing you to analyze how records progress through different stages over time.

***

## What Problems Does Snapshotting Solve?

### Sophisticated Pipeline Questions

Native CRM systems cannot answer questions like:

* "How many touchpoints does it take from a fresh lead to become a sales opportunity?"
* "What's the average time from qualified to closed won?"
* "What's our conversion rate between proof of concept and close?"
* "How do inbound leads compare to outbound leads in terms of cycle time?"

These questions require **historical state tracking**, which snapshotting provides.

### Key Business Insights

Snapshotting enables sales ops teams to track:

* Pipeline accuracy
* Forecasting accuracy
* Conversion rates and percentages at each stage
* Stage-to-stage cycle times
* Lead/deal progression patterns
* Performance differences across segments (inbound vs. outbound, source channels, etc.)

***

## How Snapshotting Works

### The Mechanism

1. **Daily capture**: Scoop captures a snapshot of your entire pipeline every day
2. **Status preservation**: Each snapshot includes all status fields and their current values
3. **Individual tracking**: Records are tracked individually using their unique IDs
4. **Historical comparison**: By comparing snapshots day-over-day, Scoop can track progression through stages

### Example Timeline

```
Day 1: Lead A is in "New" status
Day 2: Lead A is in "Contacted" status
Day 3: Lead A is in "Contacted" status
Day 4: Lead A is in "Qualified" status
...
Day 30: Lead A is in "Closed Won" status
```

With this historical data, Scoop can calculate:

* Lead A took 30 days from new to closed won
* Lead A progressed through 4 status changes
* Lead A spent 2 days in the "Contacted" stage
* Conversion rate from "Qualified" to "Closed Won" was 100% for this record

***

## Setup Requirements

### 1. Enable Snapshotting

When loading a data set into Scoop, you must turn on the **snapshot option**. This is a setting during the data source configuration.

⚠️ **Important**: Snapshotting must be enabled from the beginning. You cannot retroactively snapshot historical data.

### 2. Include Unique Record IDs

Your data source must include unique identifiers for each record:

* **Close CRM**: Automatically includes record IDs
* **Salesforce**: Includes record IDs by default
* **Custom sources**: Ensure each record has a unique ID field

✅ **Critical**: Make sure you bring the ID field into Scoop when setting up your data source. Without unique IDs, Scoop cannot track individual records over time.

### 3. Allow Sufficient Time

You need **enough snapshots to make the data reasonable**. Recommendations:

* **Minimum**: Several days of snapshots (for basic analysis)
* **Recommended**: Weeks to months of snapshots
* **Ideal**: Continuous snapshotting that matches your sales cycle length

Example from the demo: A Salesforce data set with daily snapshots going back for months enables comprehensive analysis.

***

## What Can You Analyze?

### 1. Process Flow Visualization

**Process Diagrams** show:

* Visual representation of your sales stages
* Conversion percentages between each stage
* Time lag from stage to stage
* Drop-off points in your funnel

**Example**:

```
New (100 leads) → Contacted (80 leads) [80% conversion, avg 2 days]
Contacted (80 leads) → Qualified (50 leads) [62.5% conversion, avg 5 days]
Qualified (50 leads) → Proof of Concept (30 leads) [60% conversion, avg 7 days]
Proof of Concept (30 leads) → Closed Won (20 leads) [67% conversion, avg 14 days]
```

### 2. Cycle Time Analysis

Track how long records spend in each stage:

* Average time in "Contacted" status
* Time from first touch to qualified opportunity
* Total cycle time from lead to close
* Comparison by segment (see below)

### 3. Conversion Rate Metrics

Calculate conversion rates at any point:

* Stage-to-stage conversion (e.g., Qualified → Proof of Concept)
* Overall funnel conversion (e.g., New Lead → Closed Won)
* Win rates at different stages
* Loss analysis at each stage

### 4. Segmentation & Comparison

Filter process diagrams and metrics by attributes:

**By Lead Source**:

* Inbound leads vs. Outbound leads
* Email campaigns vs. Phone outreach vs. Snail mail
* Paid advertising vs. Organic

**By Time Period**:

* Q1 2024 vs. Q2 2024
* This month vs. last month
* Before/after a process change

**By Team/Rep**:

* Individual sales rep performance
* Team-based comparisons
* Territory analysis

**Example Question**: "How long do inbound leads usually take to convert versus outbound?"

* With snapshotting enabled, Scoop can show you that inbound leads average 21 days while outbound average 35 days.

### 5. Pipeline Accuracy & Forecasting

Track how accurate your pipeline forecasts are:

* Compare what you predicted vs. what actually closed
* Identify which stages have the most forecast slippage
* Improve forecast accuracy over time based on historical patterns

### 6. Touchpoint Analysis

Answer questions like "How many touchpoints does it take from a fresh lead to a sales opportunity?"

* Track status changes as "touchpoints"
* Count interactions required to move between stages
* Identify optimal engagement patterns

***

## Using Snapshotted Data

### 1. Visual Analysis

Navigate to your snapshotted data set and view:

* Process diagrams with conversion flows
* Timeline charts showing stage progression
* Cohort analysis comparing different segments

### 2. AI Chat Queries

Ask natural language questions directly:

**Example questions you can ask**:

* "What is the conversion rate from proof of concept to closed won?"
* "What is the cycle time between qualified and closed?"
* "Show me the average time leads spend in each stage"
* "Compare conversion rates for inbound vs outbound leads"
* "How has our pipeline velocity changed over the last quarter?"
* "What percentage of qualified leads close within 30 days?"

Scoop's AI will automatically understand you're asking about progression over time and use the snapshotted data to answer.

### 3. Custom Calculations

Build your own metrics using spreadsheet formulas:

* Create custom velocity scores
* Calculate weighted pipeline values
* Build predictive models based on historical patterns

***

## Best Practices

### 1. Start Snapshotting Immediately

Don't wait to enable snapshotting. The sooner you start, the sooner you'll have meaningful historical data to analyze.

### 2. Ensure Data Quality

* Verify that unique IDs are present in your data
* Confirm status fields are properly mapped
* Check that snapshots are running daily (you should see a new snapshot each day)

### 3. Match Your Sales Cycle

For meaningful analysis, collect snapshots that span your typical sales cycle:

* 7-day cycle: Need at least 2 weeks of snapshots
* 30-day cycle: Need at least 2-3 months of snapshots
* 90-day cycle: Need at least 6 months of snapshots

### 4. Regular Review

Check your snapshotted data regularly:

* Are snapshots running daily?
* Is the snapshot count increasing?
* Are status progressions showing up correctly?

### 5. Segment Your Analysis

Don't just look at overall metrics—segment by:

* Lead source
* Product line
* Sales rep
* Time period
* Deal size

This reveals insights that overall averages might hide.

***

## Common Use Cases for Sales Ops

### Use Case 1: Pipeline Velocity

**Question**: "Is our pipeline moving faster or slower than last quarter?"

**How snapshotting helps**: Compare average days-in-stage across quarters to identify if deals are moving faster or if there are new bottlenecks.

### Use Case 2: Conversion Optimization

**Question**: "Where are we losing the most deals in our funnel?"

**How snapshotting helps**: Process diagrams show exactly which stage-to-stage transitions have the lowest conversion rates, helping you focus improvement efforts.

### Use Case 3: Channel Performance

**Question**: "Which lead sources produce the fastest closes?"

**How snapshotting helps**: Filter by lead source and compare cycle times to understand which channels generate the highest-quality, fastest-converting leads.

### Use Case 4: Rep Coaching

**Question**: "Why is Rep A closing faster than Rep B?"

**How snapshotting helps**: Compare their individual process flows to see if one rep moves leads through qualification faster, or has better conversion at specific stages.

### Use Case 5: Forecast Improvement

**Question**: "Are we accurately predicting what will close this quarter?"

**How snapshotting helps**: Track historical close rates by stage to build more accurate probability models for your forecast.

***

## Troubleshooting

### "I don't see any snapshots"

* **Check**: Is snapshotting enabled on your data set?
* **Check**: Has enough time passed? Snapshots run daily, so you need at least 2 days.
* **Check**: Is your data source connection active?

### "I can't track individual records"

* **Check**: Are unique IDs included in your data import?
* **Check**: Is the ID field properly mapped in Scoop?

### "My conversion rates don't make sense"

* **Check**: Do you have enough snapshot history? Early data might be incomplete.
* **Check**: Are all relevant status values included?
* **Check**: Are you filtering in a way that excludes important records?

### "I need more historical data"

Unfortunately, you cannot retroactively create snapshots. However:

* Start snapshotting now to begin building history
* If you need immediate insights, consider manually analyzing historical exports from your CRM

***

## Summary

Snapshotting transforms Scoop from a reporting tool into a powerful sales ops platform by:

✅ Capturing daily pipeline states automatically  
✅ Enabling historical trend analysis  
✅ Tracking individual record progression  
✅ Calculating conversion rates and cycle times  
✅ Comparing performance across segments  
✅ Improving forecast accuracy  
✅ Identifying process bottlenecks

**Key Takeaway**: Enable snapshotting immediately on any data set where you need to track progression over time. The longer it runs, the more valuable your insights become.
