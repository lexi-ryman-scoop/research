---
title: Teradata
excerpt: Connect to Teradata for enterprise data warehouse analytics
deprecated: false
hidden: false
metadata:
  title: Connecting to Teradata
  description: >-
    Connect Scoop to your Teradata data warehouse for AI-powered analytics
    on your enterprise data.
  robots: index
---

Teradata is an enterprise data warehouse platform known for handling massive data volumes and complex analytical workloads. Scoop connects directly to Teradata, enabling AI-powered analysis on your data warehouse.

## Connection Details

| Setting | Value |
|---------|-------|
| Default Port | 1025 |
| Connection Type | TCP/IP |
| SSL | Recommended |

## Prerequisites

Before connecting Scoop to Teradata:

1. **Teradata database** (version 16.20 or later recommended)
2. **Read-only user** with SELECT permissions
3. **Network access** from Scoop's IP addresses

## Create a Read-Only User

Connect to your Teradata database as an administrator and run:

```sql
-- Create the user
CREATE USER scoop_user
FROM your_database
AS PERMANENT = 0
PASSWORD = "your_secure_password"
DEFAULT DATABASE = your_database;

-- Grant SELECT on specific database
GRANT SELECT ON your_database TO scoop_user;

-- Grant SELECT on specific tables
GRANT SELECT ON your_database.your_table TO scoop_user;

-- Grant access to system views if needed
GRANT SELECT ON DBC TO scoop_user;
```

Replace `your_database` and the password with your actual values.

## Whitelist Scoop IP Addresses

### For Teradata Vantage (Cloud)
1. Go to your Teradata Vantage console
2. Navigate to **Network** > **Access Management**
3. Add Scoop's IP addresses to the allowlist

### For On-Premises Teradata
Configure your firewall to allow incoming connections on port 1025 from Scoop's IP addresses.

Contact Scoop support for the current list of IP addresses to whitelist.

## Connect in Scoop

1. Navigate to **Datasets** and click **New Dataset**
2. Select **Database** as your source
3. Choose **Teradata** from the database type dropdown
4. Enter your connection details:
   - **Server Host**: Your Teradata hostname or IP
   - **Port**: 1025 (or your custom port)
   - **Database**: Your default database name
   - **Username**: scoop_user
   - **Password**: The user's password
5. Click **Test Connection** to verify
6. Enter your SQL query and proceed

## Connection URL Format

If using a JDBC URL directly:

```
jdbc:teradata://hostname/DATABASE=database_name
```

With additional parameters:
```
jdbc:teradata://hostname/DATABASE=database_name,DBS_PORT=1025,CHARSET=UTF8
```

## Query Syntax Notes

Teradata SQL has unique syntax elements:

```sql
-- Use SAMPLE for random sampling
SELECT * FROM your_table SAMPLE 1000

-- Use TOP for limiting rows
SELECT TOP 100 * FROM your_table

-- Date arithmetic
SELECT CURRENT_DATE, CURRENT_TIMESTAMP

-- QUALIFY for window function filtering
SELECT *
FROM your_table
QUALIFY ROW_NUMBER() OVER (PARTITION BY category ORDER BY amount DESC) = 1
```

## Best Practices

- **Use primary indexes** effectively for data distribution
- **Avoid product joins** (Cartesian joins) which are expensive
- **Use EXPLAIN** to understand query execution plans
- **Leverage Teradata's partitioning** for time-series data

## Troubleshooting

### Connection Error 8017
- Verify the Teradata server is reachable
- Check that the hostname/IP is correct
- Ensure port 1025 is open in your firewall

### Logon Failed - Invalid Username or Password
- Verify the username and password are correct
- Check if the user account is locked
- Ensure the user was created successfully

### No SELECT Permission
- Verify GRANT SELECT was executed
- Check permissions: `SHOW GRANT ON your_database TO scoop_user;`
- Ensure access to the specific database is granted
