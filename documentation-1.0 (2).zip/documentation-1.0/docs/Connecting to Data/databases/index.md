---
title: Supported Databases
excerpt: Connect to your data warehouse or database for real-time analysis
deprecated: false
hidden: false
metadata:
  title: Supported Databases
  description: >-
    Scoop supports direct connections to major cloud data warehouses and relational
    databases. Connect your data for AI-powered analysis without importing.
  robots: index
---

Scoop connects directly to your database or data warehouse, enabling powerful AI-driven analysis on your live data. Whether you're using a cloud data warehouse like Snowflake or BigQuery, or a traditional relational database like PostgreSQL or MySQL, Scoop makes it easy to query and analyze your data.

## Supported Databases

| Database | Type | Default Port | Best For |
|----------|------|--------------|----------|
| [Snowflake](snowflake) | Cloud Data Warehouse | 443 | Enterprise analytics, large-scale data |
| [PostgreSQL](postgresql) | Relational Database | 5432 | General purpose, web applications |
| [MySQL](mysql) | Relational Database | 3306 | Web applications, widely deployed |
| [Amazon Redshift](redshift) | Cloud Data Warehouse | 5439 | AWS ecosystem, petabyte-scale analytics |
| [Google BigQuery](bigquery) | Cloud Data Warehouse | 443 | Google Cloud ecosystem, serverless analytics |
| [Oracle](oracle) | Enterprise Database | 1521 | Enterprise applications, legacy systems |
| [SQL Server](sqlserver) | Enterprise Database | 1433 | Microsoft ecosystem, enterprise apps |
| [MariaDB](mariadb) | Relational Database | 3306 | MySQL-compatible, open source |
| [ClickHouse](clickhouse) | Analytical Database | 8123 | Real-time analytics, high-volume data |
| [Greenplum](greenplum) | Data Warehouse | 5432 | Large-scale analytics, PostgreSQL-compatible |
| [IBM DB2](ibm-db2) | Enterprise Database | 50000 | Enterprise systems, mainframe integration |
| [Teradata](teradata) | Enterprise Data Warehouse | 1025 | Enterprise analytics, large organizations |
| [Vertica](vertica) | Analytical Database | 5433 | High-performance analytics |

## Connection Methods

Scoop offers two ways to connect to your database:

### 1. Import Mode (Traditional)
Import your data into Scoop for analysis. Best for:
- Scheduled reports that run daily
- Data that needs transformation before analysis
- Combining data from multiple sources

### 2. Live Query Mode
Query your database directly without importing. Best for:
- Real-time analysis on current data
- Large datasets where importing isn't practical
- Star schema queries with fact and dimension tables

## Getting Started

1. **Choose your database** from the list above
2. **Create a read-only user** in your database (see database-specific instructions)
3. **Whitelist Scoop's IP addresses** in your firewall
4. **Enter connection details** in Scoop

## Scoop IP Address for Whitelisting

When configuring your database or firewall to allow Scoop connections, add the following IP address:

| Environment | IP Address |
|-------------|------------|
| **Production** | `44.231.97.118` |

All Scoop services (API, Live Query, scheduled imports) connect from this single IP address. Add this to your database's IP allowlist or firewall rules.

### Cloud Database Setup

| Cloud Provider | Where to Whitelist |
|----------------|-------------------|
| **AWS (RDS, Redshift)** | Security Groups > Inbound Rules |
| **Google Cloud (BigQuery, Cloud SQL)** | VPC Network > Firewall Rules |
| **Azure (SQL Database, Synapse)** | Networking > Firewall Rules |
| **Snowflake** | Network Policies |

### On-Premises Databases

Configure your firewall to allow incoming connections from `44.231.97.118` on your database's port (e.g., 5432 for PostgreSQL, 3306 for MySQL).

## Security Best Practices

- **Always use read-only credentials** - Scoop only needs SELECT permissions
- **Use SSL/TLS connections** when available
- **Whitelist Scoop's IP address** (`44.231.97.118`) rather than opening to all traffic
- **Rotate credentials** periodically according to your security policy

For detailed setup instructions, select your database from the list above.
