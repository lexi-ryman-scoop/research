---
title: Snowflake
excerpt: Connect to Snowflake for cloud data warehouse analytics
deprecated: false
hidden: false
metadata:
  title: Connecting to Snowflake
  description: >-
    Connect Scoop to your Snowflake data warehouse for AI-powered analytics
    on your cloud data.
  robots: index
---

Snowflake is a cloud-native data warehouse that provides elastic scaling, secure data sharing, and near-unlimited concurrent workloads. Scoop connects directly to Snowflake, enabling AI-powered analysis on your data warehouse.

## Connection Details

| Setting | Value |
|---------|-------|
| Default Port | 443 |
| Connection Type | HTTPS |
| Authentication | Username/Password or OAuth |

## Prerequisites

Before connecting Scoop to Snowflake:

1. **Snowflake account** with an active warehouse
2. **Read-only user** with SELECT permissions on required schemas
3. **Network access** from Scoop's IP addresses

## Create a Read-Only User

Run this SQL in Snowflake to create a dedicated user for Scoop:

```sql
-- Create a role for Scoop
CREATE ROLE SCOOP_READONLY;

-- Grant access to your database and schema
GRANT USAGE ON DATABASE YOUR_DATABASE TO ROLE SCOOP_READONLY;
GRANT USAGE ON SCHEMA YOUR_DATABASE.YOUR_SCHEMA TO ROLE SCOOP_READONLY;
GRANT SELECT ON ALL TABLES IN SCHEMA YOUR_DATABASE.YOUR_SCHEMA TO ROLE SCOOP_READONLY;

-- Grant future table access (optional but recommended)
GRANT SELECT ON FUTURE TABLES IN SCHEMA YOUR_DATABASE.YOUR_SCHEMA TO ROLE SCOOP_READONLY;

-- Create the user
CREATE USER SCOOP_USER PASSWORD='your_secure_password';
GRANT ROLE SCOOP_READONLY TO USER SCOOP_USER;

-- Grant warehouse usage
GRANT USAGE ON WAREHOUSE YOUR_WAREHOUSE TO ROLE SCOOP_READONLY;
```

Replace `YOUR_DATABASE`, `YOUR_SCHEMA`, `YOUR_WAREHOUSE`, and the password with your actual values.

## Whitelist Scoop IP Addresses

Configure your Snowflake network policy to allow connections from Scoop. In Snowflake:

1. Go to **Admin** > **Security** > **Network Policies**
2. Create or edit a network policy
3. Add Scoop's IP addresses to the allowed list

Contact Scoop support for the current list of IP addresses to whitelist.

## Connect in Scoop

1. Navigate to **Datasets** and click **New Dataset**
2. Select **Database** as your source
3. Choose **Snowflake** from the database type dropdown
4. Enter your connection details:
   - **Server Host**: Your Snowflake account URL (e.g., `abc12345.us-east-1.snowflakecomputing.com`)
   - **Port**: 443
   - **Database**: Your database name
   - **Username**: The read-only user you created
   - **Password**: The user's password
5. Click **Test Connection** to verify
6. Enter your SQL query and proceed

## Connection URL Format

If using a JDBC URL directly:

```
jdbc:snowflake://account_identifier.snowflakecomputing.com/?db=DATABASE&schema=SCHEMA&warehouse=WAREHOUSE
```

## Best Practices

- **Use a dedicated warehouse** for Scoop queries to avoid impacting production workloads
- **Set warehouse auto-suspend** to minimize costs when not in use
- **Use the smallest warehouse size** that meets your query performance needs
- **Grant access only to required schemas** following least-privilege principles

## Troubleshooting

### Connection Timeout
- Verify your Snowflake account URL is correct
- Check that Scoop's IP addresses are whitelisted
- Ensure the warehouse is running (not suspended)

### Permission Denied
- Verify the user has the SCOOP_READONLY role granted
- Check that SELECT permissions are granted on the target tables
- Ensure USAGE is granted on the database, schema, and warehouse

### Query Performance
- Consider using a larger warehouse for complex queries
- Ensure statistics are up to date on frequently queried tables
- Use clustering keys on large tables for better performance
