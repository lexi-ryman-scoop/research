---
title: Google Ads
excerpt: Connect to Google Ads for campaign performance analysis
deprecated: false
hidden: false
metadata:
  title: Google Ads Integration
  description: >-
    Connect Scoop to Google Ads for campaign, keyword, and shopping performance
    analysis. Extract metrics and dimensions from 100+ Google Ads resources.
  robots: index
---


<Image align="left" border={false} width="100px" src="https://files.readme.io/a91b86e76eb1c34ac9365405fb38649ab508ac21376e0f7147aebd19eda09773-image.png" />

Google Ads Scoop allows you to extract and analyze the diverse reporting information available in Google Ads

<br />

When adding a Google Ads connection, connect using the standard Scoop OAuth Flow. Then select the account you are using to run your Google Ads.

<Image align="center" border={false} width="400px" src="https://files.readme.io/91004a7f171bf390e78b6d6142f1614364c24082432ab13d166cc7fc52a4154a-image.png" />

After selecting the customer ID, select the resource and the fields you wish to extract:

<Image align="center" border={false} width="500px" src="https://files.readme.io/3692c0c5ed30c4eb0361b74a26fc9cabb349e046437a479f23444a7364381ed7-image.png" />

Scoop makes available all of the resources, attributes and metrics available in the published Google Ads API.

# Google Ads Dataset Configuration Guide

## Choosing the Right Properties for Your Google Ads Dataset

Google Ads organizes data into different levels (account, campaign, ad group, keyword) and segments (device, time, geography) that have specific compatibility rules. Selecting the wrong combination of properties can result in errors or incomplete data. This guide provides a streamlined approach to selecting compatible properties for your analysis needs.

### The Challenge

Google Ads data is structured hierarchically with strict rules about which dimensions and metrics can be combined:

* Account-level metrics don't mix with keyword-level data
* Some segments require specific metric combinations
* Performance metrics have different aggregation rules
* Attribution models affect which conversions can be queried together

Rather than trial and error, you can leverage AI to help select compatible property combinations.

### Quick Solution: Use AI to Select Compatible Properties

#### Step 1: Define Your Analysis Goal

Be specific about what you want to analyze:

* "I want to analyze campaign performance and ROI"
* "I need to understand keyword performance and quality scores"
* "I want to track ad creative performance and testing results"
* "I need to analyze geographic performance and market expansion"
* "I want to understand device performance and mobile optimization"
* "I need to track shopping campaign product performance"

#### Step 2: Choose Your Google Ads Resource

Google Ads organizes data into different resources. Select the resource type that matches your analysis needs from this complete list:

**Core Campaign & Ad Resources:**

* `campaign` - Campaign-level performance and settings
* `campaign_budget` - Budget allocation and spending
* `campaign_criterion` - Campaign targeting criteria
* `campaign_audience_view` - Campaign audience performance
* `ad_group` - Ad group settings and performance
* `ad_group_ad` - Individual ad performance
* `ad_group_criterion` - Keywords and targeting at ad group level
* `ad` - Ad creative details and performance

**Keyword & Search Resources:**

* `keyword_view` - Keyword performance metrics
* `search_term_view` - Actual search queries that triggered ads
* `keyword_plan` - Keyword planning and forecasting
* `keyword_plan_campaign` - Keyword plan campaign data
* `keyword_plan_ad_group` - Keyword plan ad group data
* `keyword_plan_ad_group_keyword` - Keyword plan keywords
* `keyword_plan_campaign_keyword` - Campaign-level keyword plans
* `display_keyword_view` - Display network keyword performance
* `dynamic_search_ads_search_term_view` - DSA search terms

**Shopping & Product Resources:**

* `shopping_performance_view` - Shopping campaign product performance
* `shopping_product` - Product-level shopping data
* `product_group_view` - Product group performance
* `product_link` - Product feed connections

**Audience & Demographics:**

* `age_range_view` - Performance by age range
* `gender_view` - Performance by gender
* `parental_status_view` - Performance by parental status
* `income_range_view` - Performance by household income
* `user_interest` - Interest-based audience performance
* `user_list` - Remarketing list performance
* `audience` - Custom and in-market audiences
* `combined_audience` - Combined audience targeting
* `custom_audience` - Custom audience segments
* `detailed_demographic` - Detailed demographic targeting

**Geographic Resources:**

* `geographic_view` - Geographic performance data
* `location_view` - Targeted location performance
* `distance_view` - Radius targeting performance
* `user_location_view` - User location data

**Asset & Extension Resources:**

* `asset` - Ad assets (images, videos, etc.)
* `asset_group` - Asset group performance
* `asset_group_asset` - Individual assets within groups
* `asset_set` - Collections of assets
* `asset_field_type_view` - Asset field performance

**Performance Views:**

* `click_view` - Detailed click-level data
* `conversion_action` - Conversion tracking setup
* `conversion_value_rule` - Conversion value rules
* `landing_page_view` - Landing page performance
* `webpage_view` - Website performance data
* `video` - Video ad performance
* `hotel_performance_view` - Hotel ads performance
* `hotel_group_view` - Hotel group performance

**Account & Management:**

* `customer` - Account-level data
* `customer_asset` - Account-level assets
* `customer_label` - Account labels
* `billing_setup` - Billing configuration
* `account_budget` - Budget management
* `account_link` - Linked accounts

**Advanced Resources:**

* `bidding_strategy` - Bidding strategy performance
* `experiment` - Campaign experiments
* `change_event` - Account change history
* `change_status` - Change approval status
* `call_view` - Call tracking data
* `lead_form_submission_data` - Lead form submissions
* `offline_conversion_upload_client_summary` - Offline conversion uploads
* `recommendation` - Google Ads recommendations
* `batch_job` - Batch processing status

**Partner & Special Resources:**

* `third_party_app_analytics_link` - Third-party app data
* `local_services_lead` - Local services ads
* `local_services_lead_conversation` - LSA conversations
* `travel_activity_group_view` - Travel campaign data
* `travel_activity_performance_view` - Travel activity performance

**Other Available Resources:**

* `ad_parameter` - Ad customizer parameters
* `ad_schedule_view` - Ad scheduling performance
* `carrier_constant` - Mobile carrier targeting
* `currency_constant` - Currency information
* `custom_conversion_goal` - Custom goal tracking
* `customizer_attribute` - Feed customizer attributes
* `domain_category` - Domain category targeting
* `expanded_landing_page_view` - Expanded URL performance
* `geo_target_constant` - Geographic constants
* `label` - Label management
* `language_constant` - Language targeting
* `life_event` - Life event targeting
* `managed_placement_view` - Managed placement performance
* `media_file` - Media file management
* `mobile_app_category_constant` - App category targeting
* `mobile_device_constant` - Mobile device targeting
* `operating_system_version_constant` - OS version targeting
* `paid_organic_search_term_view` - Paid/organic search data
* `per_store_view` - Store-level performance
* `qualifying_question` - Lead form questions
* `remarketing_action` - Remarketing setup
* `shared_criterion` - Shared negative keywords
* `shared_set` - Shared negative keyword lists
* `smart_campaign_search_term_view` - Smart campaign searches
* `smart_campaign_setting` - Smart campaign configuration
* `topic_constant` - Topic targeting options
* `topic_view` - Topic performance data

#### Step 3: Ask AI for Resource-Specific Properties

Use this two-step approach with Claude, ChatGPT, or another AI assistant:

**First Prompt - Get Available Properties:**

```
What are the available properties/fields for the Google Ads API [RESOURCE_NAME] resource? 
List all available dimensions and metrics that can be selected for this resource.
```

**Second Prompt - Get Recommendations:**

```
I'm creating a Google Ads dataset in Scoop using the [RESOURCE_NAME] resource. 
My goal is to [insert your analysis goal here]. 

From the available properties for this resource, recommend up to 15 properties that will:
- Work together without compatibility issues
- Follow Google Ads API segmentation rules
- Provide actionable insights for my analysis goal
- Include both dimensions for grouping and metrics for measurement

Please explain why these specific properties work well together for my goal.
```

#### Step 4: Apply the Recommendations

Take the 15 properties suggested by the AI and check them off in your Scoop dataset configuration. The AI will have already ensured they're compatible with your chosen resource.

### Understanding Google Ads Resources

Google Ads organizes data into over 100 different resource types, each with its own set of compatible properties. The complete list above shows all available resources in Scoop, organized by category to help you find the right one for your analysis.

Each resource has its own set of compatible dimensions and metrics. The AI will help you find the right combination based on your chosen resource and analysis goals.

### Important Notes

* **Resource Selection**: Start by choosing the right resource for your analysis goal
* **Property Compatibility**: Each resource has its own set of compatible properties
* **AI Assistance**: Let AI help you find current properties and ensure compatibility
* **Data Freshness**: Some metrics have reporting delays (conversions may lag 1-3 days)
* **Attribution Windows**: Conversion metrics depend on your attribution model settings

### Example Workflows

Here are example workflows for common analysis scenarios:

**Campaign Performance Analysis**

1. Choose resource: `campaign`
2. Ask AI: "What properties are available for the Google Ads campaign resource?"
3. Then: "I want to analyze campaign ROI and performance trends. Recommend 15 properties from the campaign resource."
4. Apply the AI's recommendations in Scoop

**Keyword Performance Analysis**

1. Choose resource: `keyword_view`
2. Ask AI: "What properties are available for the Google Ads keyword_view resource?"
3. Then: "I need to optimize keyword bids and quality scores. Recommend 15 properties from keyword_view."
4. Apply the AI's recommendations in Scoop

**Shopping Campaign Analysis**

1. Choose resource: `shopping_performance_view`
2. Ask AI: "What properties are available for the Google Ads shopping_performance_view resource?"
3. Then: "I want to analyze product performance and ROAS. Recommend 15 properties."
4. Apply the AI's recommendations in Scoop

**Search Term Mining**

1. Choose resource: `search_term_view`
2. Ask AI: "What properties are available for the Google Ads search_term_view resource?"
3. Then: "I need to find new keyword opportunities and negative keywords. Recommend 15 properties."
4. Apply the AI's recommendations in Scoop

### Pro Tips for Using AI to Find Properties

1. **Be Specific About Your Resource**: Always specify exactly which Google Ads resource you're working with
2. **Current Information**: Ask for "current Google Ads API" properties to get the most up-to-date list
3. **Explain Your Goal**: The more specific your analysis goal, the better the AI's recommendations
4. **Ask for Explanations**: Request that AI explain why certain properties work well together
5. **Verify Compatibility**: Ask AI to confirm that all recommended properties can be queried together

### Tips for Success

1. **Start with Campaign Level**: If unsure, begin with campaign-level analysis as it's the most flexible
2. **Match Hierarchy Levels**: Don't mix account-level metrics with keyword-level dimensions
3. **Consider Attribution**: Remember that conversion metrics depend on your attribution settings
4. **Test with Date Ranges**: Start with shorter date ranges to verify your property selection works
5. **Use Segments Wisely**: Adding segments (device, geography, time) multiplies your data rows

Remember: The use an AI assistant to help ensure you're selecting properties that work together and align with Google Ads' data structure. This approach saves time and prevents frustrating errors from incompatible property combinations.
