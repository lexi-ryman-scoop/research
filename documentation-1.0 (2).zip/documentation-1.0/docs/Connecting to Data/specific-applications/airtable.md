---
title: Airtable
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Airtable Integration
  description: >-
    Scoop allows you to integrate Airtable data with other sources, perform
    advanced calculations, and save the results back to Airtable. To connect
    Airtable to Scoop, create a new dataset, select Airtable as the source,
    grant access, choose the desired Base and table, and then create the
    dataset.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/6d3dff281b542d7ea9e7c60b8e7e9e33490caa6b5cf9060079ddd3c02435832a-image.png" />

<br />

With Scoop, you can capture your Airtable data and blend it with other sources. In addition, you can run sophisticated calculations in your Scoop dataset using powerful spreadsheet logic and even save that data back into Airtable.

# Connecting to Airtable

To connect to Airtable as a datasource, create a new dataset linked to Airtable. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Airtable:

<Image align="center" width="300px" src="https://files.readme.io/af8a6dc99ea6137201e88f46664c49ad276790029a79a1a88da9cc5b89e4ac48-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" width="300px" src="https://files.readme.io/c84d085-image.png" />

Next click on the link to take you to Airtable where you can login and then choose which Bases you would like to utilize with Scoop and then click "Grant Access".

<Image align="center" width="300px" src="https://files.readme.io/20a0b29a90b17038429c6293fc043f159d0f14fa5e74c4b45fef34524a14d31e-image.png" />

After that, return to the Scoop window and select the Base for this dataset.

<Image align="center" width="300px" src="https://files.readme.io/8de852003d95d87629a53800149653f361a5b777f1f05068dafb311d26c531ef-image.png" />

Select the table you would like to leverage and the fields you would like to bring into Scoop.

<Image align="center" width="400px" src="https://files.readme.io/ef6c03379a65e44c738e5c5e171ea344d6a1fe30eeb303de157ba9728a2ad482-image.png" />

Also, specify a dataset name and then click "Create Data Source" to create a Scoop dataset from this table.
