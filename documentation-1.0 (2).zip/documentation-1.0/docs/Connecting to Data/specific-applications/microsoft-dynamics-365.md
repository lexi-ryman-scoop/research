---
title: Microsoft Dynamics 365
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Microsoft Dynamics 365 Integration
  description: >-
    Import Dynamics 365 CRM and ERP data into Scoop for enhanced sales
    reporting, pipeline snapshotting, and blending with financial and marketing
    data.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/2d05bc25ff06db72287d75ba2806ec0687ef853be41dbe6a3e47e1b89757c783-Dynamics-365-Logo-2016.png" />

Scoop is able to grab any report data from Dynamics. To do this, use the Dynamics application option in Application Report option when creating a new dataset. 

# Typical Dynamics Use Cases with Dynamics Only

Typical use cases for Scoop with Dynamics data only include:

* General Dynamics reporting with better visuals and analysis
* Snapshotting any/all attributes on any Salesforce object like Opportunities or Leads
* Analyzing sales and/or marketing processes to understand conversion rates and cycle times
* Combining Dynamics marketing lead data with Dynamics sales data to understand the full lifecycle and process for a customer from raw lead to closed deal.
  * Conversion rates
  * Cycle times
  * Channel efficiency

# Typical Use Cases Combining Dynamics with other Applications

Combining Dynamics data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance. While Dynamics allows some limited ability to bring in some outside sources, like basic financial data, the integration is much more complex and the data and analysis options are limited. Scoop opens up tremendously rich opportunities to slice and dice Salesforce data in conjunction with data from other applications.

## Uncaptured Audience or Channel Data

Because Scoop can easily handle spreadsheets, lookup tables that augment attributes for your campaign are very easy to add. It's exceptionally easy and painless to augment your marketing data with key attributes that likely are either anecdotal or captured in some sort of ad hoc way. Scoop makes it extraordinarily simple to include this data by maintaining it in a spreadsheet and being able to join that spreadsheet to your other marketing data.

## Financial Expense Data

Financial applications such as NetSuite, QuickBooks or other accounting applications (including other Microsoft applications) can bring in expense data very easily into Scoop. This enables some powerful analysis:

* Dollar cost efficiency of marketing efforts: This analysis allows you to assess by campaign, audience, channel, message, etc. the efficiency of dollars in to dollars out of closed won deals. This use case combines snapshot lead data, snapshot sales data and financial expense data for marketing campaigns.
* Customer acquisition cost
* Cost per lead analysis

## Service Data

To understand better what audiences might be more expensive to serve, Scoop allows you to blend your marketing or sales data with data from your service desk (e.g. Zendesk)

## Product Usage Data

Understand the usage patterns of your customers based on their marketing segmentation.

## Engineering Data

Understand what types of customers cost the most in terms of engineering time by integrating with a tool like Jira.
