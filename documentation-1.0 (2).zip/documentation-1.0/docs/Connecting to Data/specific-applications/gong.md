---
title: Gong
excerpt: Import conversation intelligence for sales coaching and forecasting
deprecated: false
hidden: false
metadata:
  title: Gong Integration
  description: >-
    Import Gong data into Scoop for conversation analysis, sales coaching,
    and forecast tracking. Combine call insights with CRM and pipeline data.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/0813f4ba8d0eefff49802798e1d78aa1c6ec9fe54afee5ec03db914bca3d7b93-gong-io-vector-logo-2022.png" />

## Overview

Gong captures and analyzes your sales conversations. Import Gong data into Scoop to combine conversation intelligence with your CRM, track forecast evolution over time, and identify winning behaviors across your sales team.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Call Analytics** | "What's the talk-to-listen ratio for top performers?" |
| **Deal Insights** | "Which deals have the most stakeholder engagement?" |
| **Forecast Tracking** | "How has our forecast changed over the quarter?" |
| **Coaching Metrics** | "Which reps mention pricing too early?" |
| **Win/Loss Patterns** | "What topics appear most in won deals?" |

## Importing Gong Data

### Option 1: Export Reports from Gong

1. In Gong, navigate to **Insights** or **Analytics**
2. Select or create a report
3. Export to CSV format
4. Upload to Scoop as a new dataset

### Option 2: Scheduled Email Reports

1. Configure Gong to email reports on a schedule
2. Forward to your Scoop ingest address
3. Scoop processes automatically

### Option 3: API Export (Advanced)

For teams with Gong API access:
1. Export data via Gong's API
2. Save as CSV
3. Upload to Scoop or automate via script

## Key Reports to Import

### Forecast History
Track how your forecast evolves:
- Weekly/monthly forecast snapshots
- Stage-by-stage progression
- Commit vs. close accuracy

**Why This Matters**: Scoop can snapshot your Gong forecast over time, showing exactly how predictions changed and when deals slipped or accelerated.

### Call Activity Summary
Analyze conversation patterns:
- Calls per rep/week
- Average call duration
- Customer-to-rep talk ratio

### Scorecard Results
Import coaching scorecards:
- Discovery question coverage
- Competitive mention rates
- Next step clarity scores

### Deal Intelligence
Track deal-level engagement:
- Stakeholders involved
- Meeting frequency
- Risk indicators

## Forecast Evolution Analysis

One of the most powerful uses of Gong data in Scoop:

1. **Import weekly forecast exports** as a snapshot dataset
2. **Track changes over time**: "Show forecast for Q4 as it evolved week-by-week"
3. **Identify patterns**: "Which reps' forecasts are most accurate?"

```
Ask Scoop:
"Compare our current forecast to what it was 30 days ago.
Which deals changed the most?"
```

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Salesforce/CRM** | Full deal context + conversation insights |
| **Revenue Data** | Conversation quality vs. deal value |
| **Marketing Data** | Lead source to conversation quality |
| **Activity Data** | Email engagement + call insights |

### Example: Win Rate by Conversation Quality

```
Ask Scoop:
"Compare win rates for deals with above-average
talk-to-listen ratios vs below-average"
```

## Best Practices

### Snapshot Your Forecast
- Import weekly at a consistent time
- Track commit accuracy over time
- Identify which changes drive variance

### Include Deal Identifiers
Ensure exports include:
- Opportunity ID or Deal ID
- Account name
- Close date and amount

### Focus on Actionable Metrics
Priority metrics for most teams:
- Talk-to-listen ratio
- Question count per call
- Next steps mentioned
- Competitor mentions

## Common Use Cases

### Sales Coaching
Identify specific coaching opportunities:
> "Show calls where reps talked more than 65% of the time"

### Forecast Accuracy
Track prediction reliability:
> "Compare forecasted amount to actual closed by rep"

### Winning Behaviors
Find what works:
> "What's the average discovery call length for deals that close?"

### Risk Identification
Spot deals in trouble:
> "Which deals have had no customer meetings in 2+ weeks?"

## Troubleshooting

### Forecast Data Doesn't Match CRM
- Check snapshot timing (Gong vs. Salesforce sync)
- Verify deal IDs match between systems
- Account for timezone differences

### Missing Calls
- Verify recording is enabled for all meeting types
- Check that meetings are correctly associated to deals
- Ensure calendar integration is active

## Related Resources

- [Snapshot Datasets](../connect-your-data/snapshot-datasets) - Track changes over time
- [Salesforce Integration](salesforce) - Combine with CRM
- [Email Automated Imports](../connect-your-data/email-automated-imports)
