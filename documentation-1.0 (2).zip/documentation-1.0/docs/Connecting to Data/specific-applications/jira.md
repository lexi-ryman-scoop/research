---
title: Jira
excerpt: 'Analyze engineering velocity, issue resolution, and development processes'
deprecated: false
hidden: false
metadata:
  title: Jira Integration
  description: >-
    Scoop can extract data from Jira to analyze engineering and service
    processes, track issue resolution over time, and compare cycle types and
    success rates across different products, customers, and development teams.
    It can also help summarize Jira data for non-development teams and be used
    to combine issue tracking with other data sources for insights such as
    customer cost analysis and customer health/risk scoring.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/97248d1a60fbee8f2f12f5d23efcfa8f8c6590bd0e83456d51fd440aa512865c-image.png" />

<br />

<br />

Connect Jira to Scoop to analyze engineering velocity, track issue resolution patterns, and understand how work flows through your development and service teams. Snapshot issues to see exactly how they progress through statuses, measure cycle times, and identify bottlenecks.

# What You Can Analyze

| Analysis Type | Questions Answered |
|---------------|-------------------|
| **Velocity** | How much work is the team completing per sprint? |
| **Cycle Time** | How long do issues take from creation to resolution? |
| **Bottlenecks** | Where do issues get stuck? Which statuses have the longest dwell time? |
| **Quality** | What's the bug rate? How often do issues reopen? |
| **Capacity** | How is work distributed across team members? |
| **Predictability** | Are estimates accurate? What affects delivery? |

# Connecting Jira to Scoop

## Option 1: Native Connector

1. Create a new dataset in Scoop
2. Select **Jira** from the application list
3. Authenticate with your Atlassian account
4. Select the project(s) to sync
5. Choose which issue types to include

## Option 2: Email Reports

Configure Jira to email reports to your Scoop data email address:

1. In Jira, create a saved filter for the issues you want
2. Set up a subscription to email the filter results
3. Use your Scoop dataset email as the recipient
4. Schedule daily or weekly delivery

## Option 3: CSV Export

For one-time or periodic analysis:

1. Export issues from Jira as CSV
2. Upload to Scoop manually or via Google Drive

# Recommended Data to Extract

## Essential Fields

| Field | Analysis Use |
|-------|--------------|
| **Issue Key** | Unique identifier for snapshotting |
| **Status** | Track lifecycle progression |
| **Created Date** | Measure age and volume trends |
| **Resolution Date** | Calculate cycle time |
| **Issue Type** | Segment by bugs, stories, tasks |
| **Priority** | Analyze priority distribution |
| **Assignee** | Workload analysis |

## Valuable Additional Fields

| Field | Analysis Use |
|-------|--------------|
| **Sprint** | Velocity tracking |
| **Story Points** | Effort estimation accuracy |
| **Components** | Area-based analysis |
| **Labels** | Custom categorization |
| **Time in Status** | Bottleneck identification |
| **Customer/Account** | Cost-to-serve analysis |

# Setting Up Snapshot Analysis

For powerful process analysis, configure your Jira dataset as a **Snapshot** type:

## Recommended Filter

Include issues that are either open or recently resolved:

```
status != Done OR resolved >= -7d
```

This captures:
- All currently active issues
- Recently closed issues (to record final state change)

## Key Metrics Enabled

With snapshotting, you can analyze:

| Metric | What It Shows |
|--------|---------------|
| **Stage conversion rates** | % of issues that reach each status |
| **Average time in status** | Days spent in each stage |
| **Velocity trends** | Work completed over time |
| **Aging analysis** | Issues stuck for too long |
| **Reopening rates** | Quality issues requiring rework |

See [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) for setup details.

# Analysis Examples

## Engineering Velocity Dashboard

Track sprint performance over time:
- Story points completed per sprint
- Bug vs. feature ratio
- Burndown patterns
- Velocity trend lines

## Cycle Time Analysis

Understand how long work takes:
- Average time from creation to resolution
- Time spent in each status
- Comparison across issue types
- Identification of outliers

## Team Workload

Analyze capacity and distribution:
- Issues per team member
- Work in progress limits
- Assignment patterns
- Bottleneck identification

## Quality Metrics

Monitor quality trends:
- Bug creation rate over time
- Severity distribution
- Time to resolve by priority
- Reopening frequency

# Blending Jira with Other Data

Jira becomes even more powerful when combined with other sources:

## Jira + CRM Data

**Goal**: Understand which customers drive the most engineering work

| Jira Field | CRM Field | Insight |
|------------|-----------|---------|
| Customer label | Account ID | Issues per customer |
| Story points | Contract value | Cost to serve ratio |
| Priority | Customer tier | Priority alignment |

## Jira + Product Usage

**Goal**: Correlate product areas with engineering investment

- Which features generate the most bugs?
- Are high-usage areas getting appropriate attention?
- Where should engineering focus?

## Jira + Financial Data

**Goal**: Calculate true cost of engineering work

- Cost per issue resolved
- Engineering investment by product area
- ROI on bug fixes vs. features

# Best Practices

## Data Hygiene

- Use consistent labeling for customers/products
- Ensure all issues have proper type classification
- Keep status workflows standardized

## Snapshot Frequency

- **Daily** for active development tracking
- **Weekly** for longer-term trend analysis

## Field Selection

- Include all fields you might want to analyze
- Add custom fields that contain business context
- Exclude sensitive personal data if sharing broadly

# Troubleshooting

## Missing Issues

- Check your Jira filter includes all needed statuses
- Verify permissions allow access to all projects
- Confirm date range covers expected data

## Duplicate Records

- Ensure Issue Key is recognized as unique identifier
- Check for multiple projects with overlapping keys

## Status Changes Not Tracking

- Confirm dataset type is "Snapshot"
- Verify daily data loads are occurring
- Check filter includes recently modified issues

# Related Topics

- [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) - Track issue state changes
- [Process Analysis](../../Exploring%20and%20Visualizing%20Data/process-analysis) - Visualize issue flows
- [Blending Datasets](../../Preparing%20Datasets/blending-two-datasets) - Combine with other sources
