---
title: Workday
excerpt: 'Analyze HR, finance, and workforce data for strategic insights'
deprecated: false
hidden: false
metadata:
  title: Workday Integration
  description: >-
    Import Workday HR and financial data into Scoop via automated email reports
    for enhanced visualization, snapshotting, and blending with CRM and sales
    data.
  robots: index
next:
  description: ''
---
<Image align="left" width="250px" src="https://files.readme.io/c5d1179-image.png" />

<br />

<br />

<br />

<br />

Connect Workday to Scoop to analyze your HR, financial, and workforce data. Go beyond Workday's built-in reporting with enhanced visualization, process analysis through snapshotting, and the ability to blend HR and financial data with operational metrics.

# What You Can Analyze

| Domain | Analysis Types |
|--------|---------------|
| **HR/People** | Headcount trends, attrition analysis, hiring velocity |
| **Finance** | Revenue tracking, expense analysis, budget vs. actual |
| **Payroll** | Compensation trends, overtime patterns, labor costs |
| **Procurement** | Spend analysis, vendor performance, order cycles |
| **Recruiting** | Time to hire, offer acceptance rates, source effectiveness |

# Connecting Workday to Scoop

## Automated Email Reports

Workday's scheduled reports can be emailed directly to Scoop:

1. In Workday, create or select a report
2. Schedule the report for automatic delivery
3. Add your Scoop dataset email as a recipient
4. Choose frequency (daily, weekly, monthly)

## Report Format Support

Scoop handles multiple Workday export formats:

| Format | Best For |
|--------|----------|
| **CSV** | Transactional data, detail reports |
| **Excel** | Financial statements, formatted reports |
| **PDF** | Not recommended (use CSV/Excel instead) |

## Manual Upload

For one-time or ad-hoc analysis:

1. Export report from Workday
2. Upload to Scoop via file upload or Google Drive
3. Configure dataset settings
4. Process and analyze

# Recommended Data Extracts

## Financial Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **P&L** | Account, Period, Amount | Profitability trends |
| **Balance Sheet** | Account, Date, Balance | Financial health |
| **Revenue** | Customer, Product, Amount | Revenue segmentation |
| **Expenses** | Category, Dept, Amount | Cost management |

## HR/People Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **Headcount** | Employee, Dept, Status | Workforce planning |
| **Terminations** | Employee, Reason, Date | Attrition analysis |
| **New Hires** | Employee, Start Date, Dept | Growth tracking |
| **Compensation** | Employee, Salary, Bonus | Compensation analysis |

## Transactional Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **Purchase Orders** | PO ID, Vendor, Amount, Status | Procurement analysis |
| **Invoices** | Invoice ID, Customer, Amount | AR analysis |
| **Time Entries** | Employee, Project, Hours | Resource utilization |

# Use Cases: Workday Only

## Financial Analysis

Enhanced reporting beyond Workday's built-in capabilities:

- **Trend analysis**: Revenue and expense trends over time
- **Variance analysis**: Budget vs. actual with drill-down
- **Segmentation**: Performance by department, product, region
- **Forecasting**: Project trends based on historical patterns

## HR Analytics

Deeper workforce insights:

- **Attrition tracking**: Why and when employees leave
- **Hiring velocity**: Time from requisition to start date
- **Compensation equity**: Pay analysis across demographics
- **Workforce planning**: Headcount trends and projections

## Process Analysis

Snapshot Workday entities to analyze workflows:

- **PO approval cycles**: Time through approval stages
- **Hiring process**: Candidate progression through stages
- **Invoice processing**: Time from receipt to payment

# Use Cases: Blending with Other Sources

## Workday + CRM

**Goal**: Connect financial outcomes to sales activities

| Workday Data | CRM Data | Combined Insight |
|--------------|----------|------------------|
| Revenue by customer | Account details | Revenue by segment/industry |
| Collections data | Customer health | Risk-adjusted forecasting |
| Renewal revenue | Opportunity pipeline | Retention vs. new business |

## Workday + Marketing

**Goal**: Measure true customer acquisition cost

- Marketing spend per campaign
- Leads per campaign
- Revenue per acquired customer
- Full-funnel CAC calculation

## Workday + Product Usage

**Goal**: Correlate usage with financial outcomes

- Revenue per active user
- Feature adoption vs. expansion revenue
- Usage patterns of churned vs. retained customers

## Workday + Support

**Goal**: Calculate complete cost to serve

- Revenue per customer
- Support cost per customer
- Net profitability by segment

# Best Practices

## Report Design

- Include unique identifiers (Employee ID, PO Number)
- Add date columns for time-based analysis
- Use consistent naming across reports
- Include all fields needed for segmentation

## Snapshot Configuration

For process analysis, configure as Snapshot dataset:

- **HR snapshots**: Track employee status changes over time
- **Financial snapshots**: Not typically needed (transactional)
- **PO snapshots**: Track order progress through stages

## Update Frequency

| Data Type | Recommended Frequency |
|-----------|----------------------|
| Financial summaries | Monthly |
| Headcount data | Weekly or monthly |
| Transaction data | Daily |
| Process data (POs, requisitions) | Daily |

# Troubleshooting

## Report Format Issues

- Ensure exports are in CSV or Excel format
- Check for merged cells in Excel exports
- Verify column headers are in the first row

## Missing Data

- Confirm report filters include expected data
- Check date ranges cover the period
- Verify user permissions for all data types

## Data Not Updating

- Confirm scheduled report is running
- Check email delivery to Scoop address
- Verify dataset is configured to receive email

# Related Topics

- [Blending Datasets](../../Preparing%20Datasets/blending-two-datasets) - Combine Workday with other sources
- [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) - Track process changes
- [Adding Calculated Columns](../../Preparing%20Datasets/adding-calculated-columns) - Create derived metrics
- [Email Data Ingestion](../connect-your-data/data-email-ingestion) - Set up automated data loading
