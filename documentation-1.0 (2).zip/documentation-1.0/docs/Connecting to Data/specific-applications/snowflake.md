---
title: Snowflake
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Snowflake Integration
  description: >-
    Connect Snowflake data warehouse to Scoop for AI-powered analysis,
    snapshotting, and blending with data from CRM, marketing, and other
    business applications.
  robots: index
next:
  description: ''
---
<Image align="left" src="https://files.readme.io/89bd6472d424ad9403d631c65f8336478e103c61682b67fbd35b56e726c938d8-image.png" />

<br />

Snowflake is a cloud-based data warehouse and platform that offers a variety of data services, including data storage, processing, and analytics. 

<br />

Scoop can load data from Snowflake and combine it with other data sources. Scoop can also do snapshot reporting on data that is stored in Snowflake.

# Connecting to Snowflake

To connect to Snowflake as a datasource, create a new dataset linked to Snowflake. First, on the datasets page, select applications as a source:

<Image align="center" src="https://files.readme.io/e10fcf467ad6e91eb1ef9aa3dc49cb5d93f62ebd118f856e45b88282bc346232-image.png" />

Next, select Database:

<Image align="center" src="https://files.readme.io/d26a9ef8e7c4df20849e1456b429b40581febe1377481cabc56c4a35dd149984-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" src="https://files.readme.io/ae031d62e2dc3c4cb2622fd243e0aae96633f86e547032f7cf2c4b4b37893d28-image.png" />

<br />

Click URL connection string and fill out the requested information 

<Image align="right" src="https://files.readme.io/19e7929e22e5fe1fb38e6d1c56b01155a468cf37432a3c11e97b659fabbca934-image.png" />

<br />

<br />

<br />

<br />

<br />

<br />

<br />

Then name the connector

<Image align="center" src="https://files.readme.io/fa34479992914538a512946ac76dcd0c38919cbaaed9dba6be653863973ea589-image.png" />

<br />

After you save this dialog, you can elect to have Scoop run an immediate extract (by checking the extract data now button). Scoop will automatically run this extract overnight each day after you set this up.
