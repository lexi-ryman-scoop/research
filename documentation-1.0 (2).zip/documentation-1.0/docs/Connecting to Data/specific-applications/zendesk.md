---
title: Zendesk
excerpt: 'Analyze support operations, ticket resolution, and customer service quality'
deprecated: false
hidden: false
metadata:
  title: Zendesk Integration
  description: >-
    Zendesk can be set up to automatically send reports to Scoop, which offers
    enhanced visualization, collaboration, and reporting capabilities beyond the
    standard features of Zendesk. Scoop allows for blending Zendesk data with
    other sources to calculate metrics like cost to serve and improve customer
    success processes.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/f0cc03b097106c7ed5d5249fe2eb0362afa20e58beae9adb1242e7606d5b6d2f-image.png" />

<br />

<br />

<br />

<br />

Connect Zendesk to Scoop to analyze your support operations, track ticket resolution patterns, and understand service quality across your customer base. Snapshot tickets to see exactly how they progress through your support workflow, measure response times, and identify areas for improvement.

# What You Can Analyze

| Analysis Type | Questions Answered |
|---------------|-------------------|
| **Volume** | How many tickets are we handling? What are the trends? |
| **Resolution Time** | How long does it take to resolve issues? |
| **First Response** | Are we meeting SLA for initial response? |
| **Agent Performance** | How are individual agents performing? |
| **Customer Patterns** | Which customers need the most support? |
| **Channel Mix** | Where are tickets coming from (email, chat, phone)? |

# Connecting Zendesk to Scoop

## Option 1: Native Connector

1. Create a new dataset in Scoop
2. Select **Zendesk** from the application list
3. Enter your Zendesk subdomain
4. Authenticate with admin credentials
5. Select objects to sync (tickets, users, organizations)

## Option 2: Scheduled Email Reports

Configure Zendesk to email reports to Scoop:

1. In Zendesk, create a report in Explore
2. Schedule the report for email delivery
3. Use your Scoop dataset email as recipient
4. Set frequency (daily recommended for snapshot analysis)

## Option 3: CSV Export

For one-time or ad-hoc analysis:

1. Export tickets from Zendesk as CSV
2. Upload to Scoop manually
3. Process and analyze immediately

# Recommended Data to Extract

## Essential Fields

| Field | Analysis Use |
|-------|--------------|
| **Ticket ID** | Unique identifier for snapshotting |
| **Status** | Track lifecycle (New → Open → Pending → Solved) |
| **Created At** | Volume trends and aging analysis |
| **Solved At** | Resolution time calculation |
| **Priority** | Urgency distribution |
| **Assignee** | Agent workload analysis |
| **Requester** | Customer pattern analysis |

## Valuable Additional Fields

| Field | Analysis Use |
|-------|--------------|
| **Organization** | Customer-level analysis |
| **Tags** | Issue categorization |
| **Channel** | Source analysis (email, chat, phone) |
| **First Reply Time** | SLA monitoring |
| **Satisfaction Rating** | Quality measurement |
| **Group** | Team-based analysis |
| **Ticket Form** | Request type segmentation |

# Setting Up Snapshot Analysis

For powerful process analysis, configure your Zendesk dataset as a **Snapshot** type:

## Recommended Filter

Include tickets that are either open or recently resolved:

```
status:open OR status:pending OR status:new OR solved>2days
```

This captures:
- All currently active tickets
- Recently solved tickets (to record final state change)

## Key Metrics Enabled

With snapshotting, you can analyze:

| Metric | What It Shows |
|--------|---------------|
| **Status conversion rates** | % of tickets reaching each status |
| **Average time in status** | Days spent in each stage |
| **Resolution trends** | Tickets solved over time |
| **Aging analysis** | Tickets open too long |
| **Escalation patterns** | How tickets move through teams |

See [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) for setup details.

# Analysis Examples

## Support Operations Dashboard

Track overall support health:
- Tickets created vs. resolved
- Average resolution time
- Open ticket backlog
- SLA compliance rates

## Agent Performance

Understand individual and team performance:
- Tickets handled per agent
- Average resolution time by agent
- First response time
- Customer satisfaction scores

## Customer Analysis

Identify support patterns by customer:
- Tickets per organization
- Most common issues by customer
- High-touch vs. low-touch customers
- Support cost by account

## Channel Effectiveness

Compare support channels:
- Volume by channel (email, chat, phone)
- Resolution time by channel
- Satisfaction by channel
- Cost per interaction

# Blending Zendesk with Other Data

Zendesk becomes even more powerful when combined with other sources:

## Zendesk + CRM Data

**Goal**: Calculate cost to serve and identify high-maintenance customers

| Zendesk Field | CRM Field | Insight |
|---------------|-----------|---------|
| Organization | Account ID | Match tickets to accounts |
| Ticket count | ARR | Support cost ratio |
| Resolution time | Customer tier | SLA alignment |

## Zendesk + Product Usage

**Goal**: Correlate support needs with product adoption

- Do power users need less support?
- Which features generate the most tickets?
- Is there correlation between usage and satisfaction?

## Zendesk + Financial Data

**Goal**: Understand true cost of customer support

- Cost per ticket resolved
- Support cost as % of revenue
- ROI on support improvements

# Key Performance Indicators

## Volume Metrics

| KPI | Formula | Target Example |
|-----|---------|----------------|
| **Tickets Created** | Count of new tickets | Trending down |
| **Tickets Solved** | Count of solved tickets | > Created |
| **Backlog** | Open tickets | < 100 |

## Time Metrics

| KPI | Formula | Target Example |
|-----|---------|----------------|
| **First Response Time** | Created → First Reply | < 1 hour |
| **Resolution Time** | Created → Solved | < 24 hours |
| **Time in Status** | Entry → Exit | Varies by status |

## Quality Metrics

| KPI | Formula | Target Example |
|-----|---------|----------------|
| **CSAT** | Satisfied / Total Rated | > 90% |
| **First Contact Resolution** | Solved without handoff | > 70% |
| **Reopening Rate** | Reopened / Total Solved | < 5% |

# Best Practices

## Data Hygiene

- Use consistent tagging for issue categories
- Ensure organizations are properly linked to tickets
- Maintain accurate assignee information

## Snapshot Frequency

- **Daily** for active support operations
- Consider more frequent for high-volume environments

## Field Selection

- Include all fields needed for analysis
- Add custom fields containing business context
- Consider privacy when including customer data

# Troubleshooting

## Missing Tickets

- Check your Zendesk filter includes all needed statuses
- Verify API permissions allow ticket access
- Confirm date range covers expected data

## Duplicate Records

- Ensure Ticket ID is recognized as unique identifier
- Check for test vs. production data mixing

## Status Changes Not Tracking

- Confirm dataset type is "Snapshot"
- Verify daily data loads are occurring
- Check filter includes recently solved tickets

## Organization Not Matching

- Verify organization field is included in export
- Check for naming inconsistencies between systems
- Consider using organization ID for reliable matching

# Related Topics

- [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) - Track ticket state changes
- [Process Analysis](../../Exploring%20and%20Visualizing%20Data/process-analysis) - Visualize support flows
- [Blending Datasets](../../Preparing%20Datasets/blending-two-datasets) - Combine with CRM/financial data
- [CRM Writeback](../../Enterprise%20Features/crm-writeback) - Push support metrics to CRM
