---
title: Supported Applications
excerpt: 'Connect your favorite business applications to Scoop for AI-powered analytics'
deprecated: false
hidden: false
metadata:
  title: Supported Applications
  description: >-
    Connect CRM, marketing, finance, and other business applications to Scoop.
    Native API connectors, automated report capture, and data blending across
    sources.
  robots: index
next:
  description: ''
---

Scoop connects to the applications your business already uses, bringing all your data together for AI-powered analysis. Whether you need native API integration, automated report capture, or manual imports, Scoop has you covered.

# Connection Methods

Scoop supports multiple ways to connect to your applications:

| Method | Description | Best For |
|--------|-------------|----------|
| **Native API** | Direct OAuth connection with automatic daily sync | CRM, marketing platforms, databases |
| **Robot Capture** | Automated browser-based report extraction | Applications without API access |
| **Email Forward** | Auto-ingest reports sent via email | Scheduled reports, legacy systems |
| **Manual Upload** | Upload CSV, Excel, or other files | Ad-hoc analysis, one-time imports |

---

# CRM & Sales

Track your pipeline, analyze deal velocity, and understand what drives wins.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Salesforce](salesforce) | API + Reports | Pipeline snapshots, opportunity tracking, lead analysis, writeback |
| [HubSpot](hubspot) | API | Deal tracking, contact analysis, marketing attribution, writeback |
| [Pipedrive](pipedrive) | API + Reports | Pipeline waterfall, deal velocity, activity tracking, writeback |
| [Close.com](closecom) | API | Sales sequences, call analytics, pipeline management |
| [Copper CRM](copper-crm) | API | Google Workspace integration, relationship tracking |
| [Attio](attio) | API | Modern CRM analytics, relationship intelligence |
| [Microsoft Dynamics 365](microsoft-dynamics-365) | Reports | Enterprise CRM, ERP integration |

**Popular Use Cases:**
- Snapshot your pipeline daily to track every change - what moved, what closed, what slipped
- Analyze conversion rates and cycle times by rep, region, or deal type
- Blend CRM data with financial data to calculate true customer acquisition cost

---

# Marketing & Advertising

Measure campaign performance, attribution, and marketing ROI across channels.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Google Analytics](google-analytics) | API | Web traffic, user behavior, conversion tracking |
| [Meta/Facebook Ads](meta-facebook-analytics) | API | Campaign performance, ad spend, audience insights |
| [LinkedIn](linkedin) | Reports | B2B advertising, audience targeting, lead gen forms |
| [Marketo](marketo) | Reports | Marketing automation, lead scoring, campaign analysis |
| [Sprout Social](sprout-social) | Reports | Social media analytics, engagement, sentiment |
| [Google Ads](google-ads) | Reports | Search campaigns, keyword performance, ROAS |

**Popular Use Cases:**
- Combine ad spend from multiple platforms with revenue data to calculate true ROAS
- Track lead-to-customer conversion by marketing channel
- Blend website analytics with CRM data to understand the full customer journey

---

# Sales Engagement

Analyze outbound effectiveness, sequence performance, and conversation intelligence.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Outreach](outreach) | Reports | Sequence analytics, prospect engagement, rep performance |
| [Salesloft](salesloft) | Reports | Cadence analysis, email metrics, call tracking |
| [Gong](gong) | Reports | Conversation analytics, deal intelligence, coaching insights |
| [Apollo.io](apolloio) | API | Sales intelligence, sequence tracking, contact enrichment |

**Popular Use Cases:**
- Compare sequence performance across reps and campaigns
- Blend engagement data with CRM outcomes to optimize outreach
- Track conversation patterns that correlate with won deals

---

# Finance & Accounting

Connect financial data for profitability analysis and business intelligence.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [QuickBooks](quickbooks) | Reports | P&L, balance sheet, invoices, cash flow |
| [NetSuite](netsuite) | Reports | Financial statements, transactions, customer data |
| [Workday](workday) | Reports | HR financials, expense management, workforce planning |

**Popular Use Cases:**
- Calculate customer profitability by blending revenue with service costs
- Track financial KPIs over time with automatic snapshots
- Blend financial data with sales data for revenue attribution

---

# Project & Work Management

Analyze workflows, track productivity, and optimize processes.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Jira](jira) | API | Issue tracking, sprint analytics, cycle times |
| [Monday.com](monday) | API | Work management, deal tracking, project status |
| [Airtable](airtable) | API | Flexible databases, custom workflows |

**Popular Use Cases:**
- Track engineering velocity and identify bottlenecks
- Analyze issue resolution times by product, team, or customer
- Blend project data with customer data for resource planning

---

# Customer Support

Measure service quality, response times, and support costs.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Zendesk](zendesk) | Reports | Ticket analytics, response times, CSAT |

**Popular Use Cases:**
- Calculate cost-to-serve by customer segment
- Track support trends over time with snapshots
- Blend support data with revenue to prioritize high-value customers

---

# Data Warehouses & BI Tools

Connect to your existing data infrastructure for advanced analytics.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Snowflake](snowflake) | Database | Direct query, large datasets, enterprise scale |
| [Microsoft Power BI](microsoft-power-bi) | Reports | Existing dashboards, semantic models |
| [Tableau](tableau) | Reports | Dashboard data, workbook exports |
| [SSRS](microsoft-reporting-services-ssrs) | Reports | Legacy BI, enterprise reports |
| [Crystal Reports](crystal-reports) | Reports | Legacy reports, banded layouts |
| [Oracle BI](oracle-bi) | Reports | Enterprise BI, OBIEE exports |
| [Google Data Studio/Looker Studio](google-data-studio) | Reports | Marketing dashboards, connected sheets |

**Key Insight:** For Power BI and Tableau users, we recommend connecting Scoop directly to your underlying database rather than importing formatted reports. Scoop's AI works best with detail-level data, and you can keep using your existing BI tools alongside Scoop.

---

# Industry-Specific

Specialized connectors for vertical markets.

| Application | Connection | Key Features |
|-------------|------------|--------------|
| [Yardi](yardi) | Reports | Property management, rent rolls, occupancy |
| [MLS (Multiple Listing Service)](multiple-listing-service-mls) | Reports | Real estate listings, market analysis |
| [Sharetribe](sharetribe) | Reports | Marketplace analytics, transaction data |

---

# Getting Started

## Step 1: Choose Your Application
Browse the categories above and click on your application for specific setup instructions.

## Step 2: Connect
- **API connectors:** Click "Connect" and authorize with OAuth
- **Report imports:** Follow the application-specific guide for export instructions
- **Email forwards:** Set up automatic forwarding to your Scoop inbox address

## Step 3: Configure Snapshotting
For any data that changes over time (deals, opportunities, projects), enable daily snapshots to track how your data evolves.

## Step 4: Start Asking Questions
Once connected, go to the Insights tab and ask questions in plain English:
- "What happened to my pipeline this week?"
- "Which campaigns are generating the best leads?"
- "Show me deals that slipped from Q4 to Q1"

---

# Don't See Your Application?

Scoop can ingest data from virtually any application through:

1. **Email Reports:** If your app can email a report, Scoop can ingest it automatically
2. **File Upload:** Export to CSV or Excel and upload directly
3. **Database Connection:** Connect to your app's underlying database
4. **API Development:** Contact us about custom connector development

For applications not listed, see [Connecting to a Business Application](../connecting-to-a-business-application) for generic setup options.
