---
title: Sharetribe
excerpt: Import marketplace data for transaction and user analytics
deprecated: false
hidden: false
metadata:
  title: Sharetribe Integration
  description: >-
    Import Sharetribe marketplace data into Scoop for transaction analysis,
    user behavior tracking, and marketplace performance insights.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/579183a2dc79cb46051a813ab2839dc940ddf22dc0211b806ebd8e26689e08a9-image.png" />

## Overview

Sharetribe powers online marketplaces, connecting buyers and sellers on custom platforms. Import your Sharetribe data into Scoop to analyze transaction performance, user behavior, marketplace health, and blend with payment and marketing data for complete business visibility.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Transactions** | "What's our average order value by category?" |
| **Listings** | "Which listings have the highest conversion rate?" |
| **Users** | "How many sellers had their first transaction this month?" |
| **Revenue** | "Show provider payouts vs. platform commission" |
| **Marketplace Health** | "What's our buyer-to-seller ratio by region?" |
| **Growth** | "Track month-over-month transaction growth" |

## Importing Sharetribe Data

### Option 1: Scoop Bot (Recommended)

The Scoop bot automatically ingests data from Sharetribe on a scheduled basis:

1. Contact Scoop support to configure the Sharetribe integration
2. Provide your Sharetribe API credentials
3. Set your sync frequency (daily is typical)
4. Data flows automatically into Scoop

### Option 2: Manual Export

1. In Sharetribe Console, navigate to **Manage** → **Reports**
2. Select your report type and date range
3. Export to CSV
4. Upload to Scoop as a new dataset

### Option 3: API Export (Custom)

For advanced needs:
1. Use Sharetribe's Integration API
2. Export transactions, listings, or users
3. Upload CSV to Scoop

## Key Data Types

### Transactions
Complete transaction records:
- Transaction ID and status
- Customer ID and provider ID
- Pay in and pay out amounts
- Platform commission
- Currency and payment method
- Created date and completion date

### Listings
Product/service inventory:
- Listing ID and title
- Provider information
- Price and availability
- Category and attributes
- Creation date and status

### Users
Marketplace participants:
- User ID and role (buyer/seller/both)
- Registration date
- Last transaction date
- Stripe account status
- Profile information

### Payouts
Provider payments:
- Payout amount and date
- Provider information
- Transaction references
- Stripe payout ID

## Snapshotting for Trending

Marketplace data changes constantly. Scoop snapshots enable:

- **Track GMV trends** - Daily snapshots show transaction volume growth
- **Monitor inventory** - Weekly snapshots reveal listing patterns
- **User growth** - Track new registrations over time
- **Compare periods** - "How does Q4 compare to Q3?"

See [Snapshot Datasets](../connect-your-data/snapshot-datasets) for setup.

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Stripe** | Payment success rates, chargebacks |
| **Marketing** | Acquisition cost per buyer/seller |
| **Support** | Dispute rates by provider |
| **Email** | Engagement to transaction conversion |

### Example: Unit Economics Analysis

```
Ask Scoop:
"Show average commission per transaction
by category with marketing acquisition cost"
```

## Best Practices

### Track Both Sides
Marketplaces have two sides to monitor:
- **Buyer health**: Transaction frequency, retention, AOV
- **Seller health**: Listing quality, response time, reviews

### Include All Transaction States
Don't filter to just completed transactions:
- Track abandoned and canceled transactions
- Analyze conversion rates through the funnel
- Identify friction points

### Monitor Marketplace Balance
Track supply and demand:
- Listings per buyer
- Buyer-to-seller ratio
- Time-to-first-transaction for new sellers

## Common Use Cases

### Revenue Analysis
Understand commission performance:
> "Show total GMV and platform commission by month"

### Provider Performance
Identify top and struggling sellers:
> "Rank providers by completed transactions with average rating"

### Transaction Funnel
Analyze conversion:
> "Show transaction status breakdown—initiated vs. completed vs. canceled"

### Category Performance
Understand product mix:
> "Which categories have the highest average transaction value?"

### User Lifecycle
Track engagement over time:
> "Average transactions per user in their first 90 days"

### Marketplace Health Metrics
Monitor overall health:
> "Show buyer-to-seller ratio trend over the last 6 months"

## Marketplace-Specific Tips

### Transaction Status Tracking
Sharetribe transactions move through states:
- `pending` → waiting for payment
- `accepted` → provider confirmed
- `completed` → transaction finished
- `canceled` → transaction canceled

Track conversion rates between each state.

### Two-Sided Metrics
Always analyze both perspectives:
- **Buyer**: Repeat purchase rate, time between orders
- **Seller**: Days-on-market for listings, response time

### Commission Analysis
Understand your take rate:
- Fixed vs. percentage commission
- Commission by category
- Provider tier pricing

## Troubleshooting

### Missing Transactions
- Check date range includes all expected dates
- Verify transaction status filter isn't excluding data
- Ensure API permissions include transaction data

### Currency Mismatches
- Sharetribe handles multiple currencies
- Ensure consistent currency conversion for analysis
- Track currency in your exports

### User IDs Not Matching
- Ensure consistent ID format (UUID)
- Check that anonymous users are handled properly
- Verify buyer vs. provider ID distinction

## Related Resources

- [Snapshot Datasets](../connect-your-data/snapshot-datasets) - Track changes over time
- [Blending Datasets](../connect-your-data/blending-two-datasets) - Combine with payment data
- [Email Automated Imports](../connect-your-data/email-automated-imports)
