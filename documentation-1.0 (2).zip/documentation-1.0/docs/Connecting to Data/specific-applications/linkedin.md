---
title: LinkedIn
excerpt: Import LinkedIn campaign and marketing data for multi-channel analysis
deprecated: false
hidden: false
metadata:
  title: LinkedIn Ads Integration
  description: >-
    Import LinkedIn campaign and advertising data into Scoop. Blend with other
    marketing sources for comprehensive B2B advertising analysis.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/45621bb5f0c0164e00f61170e55594f65ecfa23c7f7b9220c9d025c0aeb44026-image.png" />

## Overview

Import LinkedIn Campaign Manager data into Scoop to analyze B2B advertising performance. Blend LinkedIn metrics with your other marketing channels, CRM data, and revenue to understand true campaign ROI.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Campaign Performance** | "Which campaigns have the lowest cost per lead?" |
| **Audience Insights** | "What job titles drive the most conversions?" |
| **Creative Analysis** | "Compare performance of video vs. image ads" |
| **Budget Optimization** | "Where should we shift budget for better ROI?" |
| **Cross-Channel** | "How does LinkedIn compare to Google Ads?" |

## Importing LinkedIn Data

### Option 1: Export from Campaign Manager

1. Log into [LinkedIn Campaign Manager](https://www.linkedin.com/campaignmanager/)
2. Navigate to **Reporting** or **Performance**
3. Select your date range and metrics
4. Click **Export** and choose CSV
5. Upload to Scoop as a new dataset

### Option 2: Scheduled Report Emails

1. Set up automated reports in Campaign Manager
2. Configure to email on a schedule
3. Forward to your Scoop ingest address

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## Key Reports to Import

### Campaign Performance
Core metrics for all campaigns:
- Impressions, clicks, CTR
- Spend and CPM/CPC
- Conversions and cost per conversion
- Lead form completions

### Audience Demographics
Understand who engages:
- Job title breakdown
- Company size distribution
- Industry performance
- Seniority level engagement

### Creative Performance
Compare ad formats:
- Single image vs. carousel
- Video completion rates
- Sponsored content vs. message ads
- A/B test results

### Conversion Tracking
Track bottom-funnel impact:
- Lead gen form completions
- Website conversions
- Sign-ups and downloads

## Available Metrics

| Category | Metrics |
|----------|---------|
| **Reach** | Impressions, Reach, Frequency |
| **Engagement** | Clicks, CTR, Social Actions, Comments, Shares |
| **Cost** | Spend, CPM, CPC, Cost per Conversion |
| **Video** | Views, Completion Rate, Watch Time |
| **Conversions** | Leads, Downloads, Sign-ups, Custom Conversions |
| **Demographics** | Job Title, Company, Industry, Seniority |

## Blending with Other Marketing Data

LinkedIn data is most powerful when combined with other sources:

| Source | Analysis Enabled |
|--------|------------------|
| **Google Ads** | Compare B2B vs. B2C channel performance |
| **Meta Ads** | Full paid social picture |
| **Google Analytics** | Post-click behavior analysis |
| **CRM (Salesforce/HubSpot)** | Lead-to-opportunity attribution |
| **Revenue Data** | True ROAS calculation |

### Example: Multi-Channel Attribution

```
Ask Scoop:
"Show cost per qualified lead by marketing channel,
including LinkedIn, Google Ads, and Meta"
```

## Best Practices

### Export Consistently
- Daily exports for active campaigns
- Weekly rollups for trend analysis
- Include all campaigns (not just top performers)

### Include Demographic Breakdowns
LinkedIn's B2B targeting is unique. Export:
- Job function performance
- Company size tiers
- Industry segments

### Track UTM Parameters
Use consistent UTMs to connect LinkedIn data to:
- Website analytics
- CRM lead sources
- Conversion tracking

## Common Use Cases

### Budget Allocation
Optimize spend across campaigns:
> "Which audience segments have the lowest cost per MQL?"

### Creative Testing
Find winning ad formats:
> "Compare video vs. static image performance by funnel stage"

### Audience Discovery
Identify best-performing targets:
> "What job titles convert at the lowest cost?"

### ROI Analysis
Connect ads to revenue:
> "Calculate pipeline generated per $1,000 LinkedIn spend by campaign"

### Cross-Channel Comparison
Benchmark against other channels:
> "Compare LinkedIn CPL to Google Ads CPL for similar audiences"

## LinkedIn-Specific Tips

### Lead Gen Forms vs. Website Conversions
- Lead gen forms typically have higher volume, lower quality
- Website conversions require more tracking but often higher intent
- Track both to understand the tradeoff

### Audience Size Matters
- Very narrow audiences (< 50K) may have high CPMs
- Very broad audiences may lack intent
- Sweet spot often 100K-500K for B2B

### Document Objective
LinkedIn optimizes based on your objective. Track:
- Which objective you used per campaign
- How objective affects downstream metrics

## Troubleshooting

### Conversions Don't Match CRM
- Check attribution window settings
- Verify LinkedIn Insight Tag is installed
- Allow for conversion delay (B2B cycles are long)

### Demographics Not Appearing
- Ensure you have sufficient scale (LinkedIn requires minimum sample)
- Check that demographic reporting is enabled
- Export at campaign level, not creative level

### Data Gaps
- LinkedIn may delay reporting by 24-48 hours
- Weekends/holidays may show incomplete data
- Re-export after a few days for final numbers

## Related Resources

- [Google Ads Integration](google-ads) - Compare to search advertising
- [Meta Ads Integration](meta-facebook-analytics) - Full paid social view
- [Blending Datasets](../connect-your-data/blending-two-datasets)
- [Email Automated Imports](../connect-your-data/email-automated-imports)
