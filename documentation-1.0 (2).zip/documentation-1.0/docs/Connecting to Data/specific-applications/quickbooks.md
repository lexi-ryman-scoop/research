---
title: QuickBooks
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: QuickBooks Integration
  description: >-
    Quickbooks can generate automated custom reports that integrate with Scoop,
    allowing users to combine financial data with other operational data for
    comprehensive business insights, including detailed analysis of financial
    statements, transaction items, and list items.
  robots: index
next:
  description: ''
---
<Image align="left" width="250px" src="https://files.readme.io/fe2d208-image.png" />

You can create automated custom reports with QuickBooks and have them automatically sent to Scoop for ingestion. This will allow you to blend your QuickBooks financial data with any other data that you have been able to bring into Scoop.

<Image align="center" width="350px" src="https://files.readme.io/d777abbcdefb6362bfb4667f9441894bad0212a01aba116c8b4d02fc80f61c2d-Quickbooks-dataset-docs.png" />

Example of typical items you might pull from QuickBooks:

* Revenue data by customer, product, etc.
* Expense data by campaign, channel, etc.
* Income statement
* Balance sheet items (e.g. like cash on hand)
* Invoicing data

This data can be extraordinarily powerful when combined with other operational data from sales, marketing, product, service, etc. such that you can gain deep visibility into costs and returns on investments in various parts of your business.

# Using Financial Statements

Financial statements are the core of an accounting system. Scoop allows you to pull financial statements from QuickBooks and analyze them. Scoop supports the following:

* Profit and Loss Detail (Income Statement) - Scoop pulls all profit and loss data by date and allows you to aggregate this data over any date period\
  For example below, if under ProfitAndLoss the metric Value is selected and the Income account is what's chosen to filter for, you can then chart income by any time period of your choice:

![](https://files.readme.io/7b945688cfb353348f6a44e2baf423d17f22ff422d85823c43c2a7778d3edb91-image.png)

![](https://files.readme.io/07b57a1488ac0641a4c5f44d7d479916a0ee6de64cbaef0ae09175d858306825-image.png)

* Balance Sheet - Scoop pulls monthly balance sheet account balances. For the balance sheet, you can similarly filter for accounts, but you can also view balance sheet items by category:

![](https://files.readme.io/45915ccee7e4adeccc0e5a69527c47e5ede3dec3adefcc06fbc6ce20397aa232-image.png)

* Cash Flow - Scoop pulls monthly cash flow reconciliations between Profit and Loss and Balance Sheet details to allow you to understand cash flows.

For financial statements you can analyze the statement value by the appropriate account. In addition, there are attributes that may be relevant for a particular statement. To analyze a particular account's value, select the value in the financial statement and then filter the account attribute for the account of interest.

* Profit and Loss: For this financial statement you can filter or group by the "ProfitAndLossDetail" account attribute to select an account that is relevant for the P\&L. In addition, you can group and filter by the "Name" attribute which may be present on individual transactions.
* Cash Flow: For Cash Flow, you can filter or group by the "CashFlow" account attribute which will select and account on the cash flow statement. You can also filter or group by "Category" for operating activities, investing activities, and financing activites.
* Balance Sheet: For Balance Sheet, you can filter or group by the "BalanceSheet" account attribute. You can also filter or group by the "Category" attribute to filter for Assets or Liabilities and Equity.

# Transaction Items

Scoop supports the following transaction items:

* Invoice Summary - one row per invoice
* Invoice Detail - one row per invoice line item. Below is an example charting invoicing volume by transaction date.

![](https://files.readme.io/3bc8f2c5720d625d72ba8a1fd5b9493c5ac517d31aebaf55e2f66ba5d9b85522-image.png)

* Purchase Order Summary - one row per purchase order
* Purchase Order Detail - one row per purchase order line item

# List Items

Scoop supports the following list items:

* Customer
* Vendor
* Employee

# Use cases for QuickBooks by blending with other data sources

* Marketing cost per campaign, lead, and customer acquisition costs by combining with marketing lead and/or sales opportunity data
* Customer value segmentation by combining Netsuite financial data with CRM customer attributes
* Product value segmentation by combining product usage data with customer financial data
* Customer success risk analysis by comparing customer activity with their financial value
