---
title: Salesforce.com
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Salesforce Integration
  description: >-
    Scoop allows users to extract, analyze, and blend Salesforce data with other
    data sources for enhanced reporting and insights, and it also supports
    writing back processed data into Salesforce.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/8fdc15f-image.png" />

Scoop is able to grab any report data from Salesforce. To do this, use the Salesforce application option in Application Report option when creating a new dataset. 

# Typical Salesforce.com Use Cases with Salesforce Only

Typical use cases for Scoop with Salesforce data only include:

* General Salesforce reporting with better visuals and analysis
* Snapshotting any/all attributes on any Salesforce object like Opportunities or Leads
* Analyzing sales and/or marketing processes to understand conversion rates and cycle times
* Combining Salesforce marketing lead data with Salesforce sales data to understand the full lifecycle and process for a customer from raw lead to closed deal.
  * Conversion rates
  * Cycle times
  * Channel efficiency

# Salesforce Instant Recipes

Scoop has several instant recipes created for Salesforce to get you started quickly. The recipes are pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from Salesforce. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

# Salesforce Snapshotting

One of the biggest uses of Scoop for Salesforce is snapshotting. Scoop can snapshot your deals automatically. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Scoop allows Salesforce users to snapshot their deals and detect, track and report on all changes, how fast those changes occur and at what rates - allowing deep insights into the sales process.

# Typical Use Cases Combining Salesforce.com with other Applications

Combining Salesforce data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance. While Salesforce allows some limited ability to bring in some outside sources, like basic financial data, the integration is much more complex and the data and analysis options are limited. Scoop opens up tremendously rich opportunities to slice and dice Salesforce data in conjunction with data from other applications.

## Uncaptured Audience or Channel Data

Because Scoop can easily handle spreadsheets, lookup tables that augment attributes for your campaign are very easy to add. It's exceptionally easy and painless to augment your marketing data with key attributes that likely are either anecdotal or captured in some sort of ad hoc way. Scoop makes it extraordinarily simple to include this data by maintaining it in a spreadsheet and being able to join that spreadsheet to your other marketing data.

## Financial Expense Data

Financial applications such as NetSuite, QuickBooks or other accounting applications can bring in expense data very easily into Scoop. This enables some powerful analysis:

* Dollar cost efficiency of marketing efforts: This analysis allows you to assess by campaign, audience, channel, message, etc. the efficiency of dollars in to dollars out of closed won deals. This use case combines snapshot lead data, snapshot sales data and financial expense data for marketing campaigns.
* Customer acquisition cost
* Cost per lead analysis

## Service Data

To understand better what audiences might be more expensive to serve, Scoop allows you to blend your marketing or sales data with data from your service desk (e.g. Zendesk)

## Product Usage Data

Understand the usage patterns of your customers based on their marketing segmentation.

## Engineering Data

Understand what types of customers cost the most in terms of engineering time by integrating with a tool like Jira.

# Connecting to Salesforce

To connect to Salesforce as a datasource, create a new dataset linked to Salesforce. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Salesforce:

<Image align="center" width="300px" src="https://files.readme.io/a84c55777bc0dea8fe7495280068897cd13488313ed64f9a7a2a56d0466faa7c-image.png" />

## Loading from a Report vs. API

With Salesforce you can select either a report data source or using the API as a data source. The advantage of using a report as a data source is that any linked fields from different objects will be properly displayed in your report and can therefore be easily loaded. With the API, often items that link to different objects do so via an ID field. This requires you to bring in both objects and then use Scoops blending capabilities to lookup the required field from the linked object. For example, on a Salesforce opportunity you have the Owner ID, but to see the owner name you need to bring in the owner object and use Scoop to blend those sources together. If you use a report, you can have those fields already filled out with no additional data work required. And, since Salesforce supports automated emails, setup is as simple as auto-forwarding (using your own auto-forward, or Scoop's Gmail/Exchange integrations) that email to Scoop. Setup can be done in minutes.

## Loading from the API

Select API Data Source:

<Image align="center" width="300px" src="https://files.readme.io/d4f078a77f616f4d58df81d740a42a66aca82869b6817fa66de780fc5ab08ebe-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" width="300px" src="https://files.readme.io/c84d085-image.png" />

After connecting to Salesforce to Scoop, select the object that you wish to extract, and the columns that you wish to extract.

<Image align="center" width="300px" src="https://files.readme.io/7726bc4523ab85605c17988802c799622e9dba4957858f7deb88601b273ced81-image.png" />

Also, select a dataset name. After you save this dialog, you can elect to have Scoop run an immediate extract (by checking the extract data now button). Scoop will automatically run this extract overnight each day after you set this up.

# Writing back to Salesforce from a Scoop dataset

With Scoop you can blend data with other datasets and create new fields with ease. Scoop's ability to use spreadsheet logic gives you that same spreadsheet flexibility to add arbitrary and powerful calculations to your dataset. It is often useful to then bring those sophisticated calculations back into your source application. Scoop's API Writeback feature allows you to take any Scoop dataset and write values back into your Salesforce application. This means that you can extract data from Salesforce (which is necessary to extract the Salesforce record ID which is required to write back into Salesforce), blend it with other data or create new calculations and then push those back into your Salesforce application.

In order to write back into Salesforce, you must first establish an API connection to Salesforce and extract records that you wish to augment (see above). The Record ID will be part of your extracted dataset. You can either create calculated columns with that dataset, or you can blend that dataset with others in Scoop to create a new dataset. Be sure to make sure that the Record ID stays with your records as you blend them together (i.e. always select that column when building a new blended dataset).

Once that is done, you can now update Salesforce whenever your dataset in question is processed. When that connection is established, the following option becomes available on the dataset menu:

<Image align="center" width="300px" src="https://files.readme.io/04a04ab-image.png" />

You can select "Setup Application Writeback" to create a writeback definition for Scoop. This definition tells Scoop what to do each time that dataset is processed. When processing is done, it will use that dataset and take the fields that you map and write them back to Salesforce using the Record IDs that you initially extracted.

<Image align="center" width="400px" src="https://files.readme.io/3b94bc6-image.png" />

The definition essentially allows you to pick fields from one table within your dataset and map those back to fields within Salesforce. 

<Image align="center" width="400px" src="https://files.readme.io/244a1d5-image.png" />

So if, for example, you wanted to map a single column in Salesforce to a Scoop dataset, you simply select from the dropdown which Scoop dataset column you want to use. Once that is done, each time that dataset is processed, Scoop will update Salesforce to ensure that that field will contain the value calculated in Scoop.
