---
title: Meta Ads
excerpt: Connect to Facebook and Instagram advertising data
deprecated: false
hidden: false
metadata:
  title: Meta Ads Integration
  description: >-
    Connect Scoop to Meta Ads (Facebook/Instagram) for campaign performance
    analysis. Extract campaigns, ad sets, ads, and insights with full metrics.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/2e7d4c18400be695a75d52fb6f5f19d9659ec94511cf8ec64e653f8714e71f1b-meta-facebook-rebranding-name-news_dezeen_2364_col_hero2.webp" />

## Overview

Scoop connects directly to Meta Ads (Facebook and Instagram) to extract campaign performance data. Combine your ad spend, impressions, and conversions with data from other sources like Google Analytics, your CRM, or sales data for comprehensive marketing analysis.

## What You Can Extract

| Data Type | Description | Use Cases |
|-----------|-------------|-----------|
| **Campaigns** | Campaign settings, budgets, objectives | Budget tracking, campaign performance |
| **Ad Sets** | Targeting, bidding, optimization | Audience analysis, bid optimization |
| **Ads** | Creative details, status | Creative performance comparison |
| **Ad Insights** | Performance metrics by date | ROI analysis, trend tracking |

## Available Fields

### Campaign Fields
- Campaign ID, Name, Status
- Objective (awareness, conversions, etc.)
- Budget (daily/lifetime)
- Start/Stop times

### Ad Set Fields
- Ad Set ID, Name, Status
- Optimization goal
- Bid strategy and amount
- Daily/lifetime budget

### Ad Fields
- Ad ID, Name, Status
- Associated Campaign and Ad Set
- Created/Updated timestamps

### Insights Metrics
| Metric | Description |
|--------|-------------|
| Impressions | Total ad views |
| Reach | Unique people reached |
| Frequency | Average views per person |
| Clicks | All clicks on ad |
| Unique Clicks | Unique people who clicked |
| Spend | Amount spent |
| CPC | Cost per click |
| CPM | Cost per 1,000 impressions |
| CTR | Click-through rate |
| Link Clicks | Clicks to destination |
| Video Views | Various video metrics |

## Connecting to Meta Ads

### Step 1: Start the Connection

1. Go to **Datasets** and click **New Dataset**
2. Select **Application Report**
3. Choose **Meta Ads** from the connector list

### Step 2: Authorize with Meta

1. Click **Connect** to open Meta's authorization page
2. Log in to your Facebook account
3. Select the ad accounts you want Scoop to access
4. Click **Allow** to grant permissions

### Step 3: Select Your Ad Account

After authorization, you'll see a list of your ad accounts. Select the account containing the data you want to analyze.

### Step 4: Choose Report Type

Select what type of data to extract:

- **Campaigns**: Campaign-level data and settings
- **Ad Sets**: Ad set configuration and targeting
- **Ads**: Individual ad details
- **Ad Insights**: Performance metrics (most common choice)

### Step 5: Select Fields

Choose which metrics and dimensions to include. For Ad Insights, common selections include:

- Date range dimensions (date_start, date_stop)
- Performance metrics (impressions, clicks, spend)
- Cost metrics (cpc, cpm, ctr)
- Conversion metrics (if configured in Meta)

### Step 6: Set Date Range

Specify the time period for your data extraction. Meta stores historical data, so you can pull several months of performance data.

### Step 7: Schedule and Finish

1. Name your dataset (e.g., "Meta Ads - Daily Performance")
2. Set a refresh schedule (daily is common for ad data)
3. Click **Create** to start the initial extraction

## Best Practices

### Combine with Other Marketing Data

Meta Ads data becomes more powerful when combined with:

- **Google Analytics**: See the full customer journey
- **CRM data**: Track leads to closed deals
- **Revenue data**: Calculate true ROAS

### Track Performance Over Time

Set up daily syncs to build a historical record. Scoop's snapshot feature lets you track changes over time:

- Campaign budget changes
- Performance trends
- Seasonal patterns

### Use Insights for Analysis

The **Ad Insights** report type is best for most analysis needs. It provides:

- Daily performance metrics
- Aggregated data across your selected dimensions
- The metrics you need for ROI calculations

## Common Use Cases

### Marketing ROI Analysis

Combine Meta spend with sales data to calculate true return on ad spend:

> "Show me cost per acquisition by campaign for last quarter"

### Campaign Comparison

Compare performance across campaigns:

> "Compare CTR and CPC across all active campaigns"

### Budget Optimization

Identify high-performing ad sets:

> "Which ad sets have the lowest CPA this month?"

### Creative Testing

Analyze ad creative performance:

> "Compare conversion rates between video and image ads"

## Troubleshooting

### No Ad Accounts Appear

**Cause**: Your Facebook account may not have access to any ad accounts.

**Solution**:
- Log into [business.facebook.com](https://business.facebook.com)
- Go to Business Settings → Ad Accounts
- Ensure you're assigned to at least one ad account

### Authorization Fails

**Cause**: Meta requires specific permissions.

**Solution**: Make sure you click "Allow" on all permission requests during the OAuth flow.

### Data Not Updating

**Cause**: Meta's API has rate limits.

**Solution**: If you're extracting large amounts of data, Scoop automatically handles rate limits. Wait a few minutes and check again.

## Related Resources

- [Google Ads Integration](google-ads) - Combine with Google advertising
- [Google Analytics Integration](google-analytics) - Add website behavior data
- [Blending Datasets](../connect-your-data/blending-two-datasets) - Combine Meta data with other sources
