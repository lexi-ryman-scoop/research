---
title: Close.com
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Close.com Integration
  description: >-
    Scoop enables data extraction and analysis from Close, offering advanced
    snapshotting and reporting capabilities, and allows users to write back
    enhanced data into Close using API connections.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/414e6063e520c0b6b3f6f6af238728bddea5b524816a87f4053abad6a21389d9-image.png" />

<br />

Scoop is able to grab your data from Close to enable analysis. 

# Typical Close.com Use Cases with Close Only

Typical use cases for Scoop with Close data only include:

* General sales reporting with better visuals and analysis
* Weekly forecasting or pipeline views that leverage snapshotting to review changes
* Snapshotting any/all attributes on any object like Opportunities
* Analyzing sales processes to understand conversion rates and cycle times

Combining Close data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance.

# Close Instant Recipes

Scoop has several instant recipes created for Close so you can get started - instantly. Pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from Close. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

# Close Snapshotting

One of the biggest uses of Scoop for Close is snapshotting. Scoop can snapshot any object, including Close sales objects. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Even Salesforce.com has limited abilities to analyze changes and whole industries have been built around that. Scoop gives greater capabilities for Close users than anything available to Salesforce customers (except those using Scoop).

# Connecting to Close

## Importing a Dataset from Close

To connect to Close as a datasource, create a new dataset linked to Close. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Close:

<Image align="center" width="300px" src="https://files.readme.io/b65c4cfed979ec5216fd998b2c1095f60b7ff706a11c78e1ced44e88e07ff186-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" width="300px" src="https://files.readme.io/c84d085-image.png" />

<br />

<br />

![](https://files.readme.io/471792d3dfb29e81de9dac218b93f4a5cec4dc2637a4872e30936dfed866624e-image.png)

Once you enter the key, you can then choose which Close object you would like to load into a Scoop dataset.

<Image align="center" width="450px" src="https://files.readme.io/1da1368ea3361a428b098d3a12d58dc33b24cff878dc3f2cbcb3ffc0ca915e54-image.png" />

Also, select a dataset name. After you save this dialog, you can elect to have Scoop run an immediate extract (by checking the extract data now button). Scoop will automatically run this extract overnight each day after you set this up.
