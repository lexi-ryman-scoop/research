---
title: Marketo
excerpt: ''
deprecated: false
hidden: true
metadata:
  title: Marketo Integration
  description: >-
    Scoop can grab report data from Marketo and allows for powerful analysis by
    combining Hubspot data with other applications such as sales, financial,
    service, product usage, and engineering data.
  robots: index
next:
  description: ''
---
<Image align="left" width="250px" src="https://files.readme.io/9f1e0d4-image.png" />

Scoop is able to grab report data from Marketo. 

# Typical Marketo Use Cases with Marketo Only

Typical use cases for Scoop with Marketo data only include:

* General Marketo reporting with better visuals and analysis
* Snapshotting any/all attributes on any Marketo object like Leads
* Analyzing marketing processes to understand conversion rates and cycle times

# Typical Use Cases Combining Hubspot with other Applications

Combining Hubspot data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance. While Hubspot allows some limited ability to bring in some outside sources, like basic financial data, the integration is much more complex and the data and analysis options are limited. Scoop opens up tremendously rich opportunities to slice and dice Hubspot data in conjunction with data from other applications.

## Combine with Sales data from Opportunity Management System

* Combining marketing lead data with sales data helps understand the full lifecycle and process for a customer from raw lead to closed deal.
  * Conversion rates
  * Cycle times
  * Channel efficiency

## Uncaptured Audience or Channel Data

Because Scoop can easily handle spreadsheets, lookup tables that augment attributes for your campaign are very easy to add. It's exceptionally easy and painless to augment your marketing data with key attributes that likely are either anecdotal or captured in some sort of ad hoc way. Scoop makes it extraordinarily simple to include this data by maintaining it in a spreadsheet and being able to join that spreadsheet to your other marketing data.

## Financial Expense Data

Financial applications such as NetSuite, QuickBooks or other accounting applications can bring in expense data very easily into Scoop. This enables some powerful analysis:

* Dollar cost efficiency of marketing efforts: This analysis allows you to assess by campaign, audience, channel, message, etc. the efficiency of dollars in to dollars out of closed won deals. This use case combines snapshot lead data, snapshot sales data and financial expense data for marketing campaigns.
* Customer acquisition cost
* Cost per lead analysis

## Service Data

To understand better what audiences might be more expensive to serve, Scoop allows you to blend your marketing or sales data with data from your service desk (e.g. Zendesk)

## Product Usage Data

Understand the usage patterns of your customers based on their marketing segmentation.

## Engineering Data

Understand what types of customers cost the most in terms of engineering time by integrating with a tool like Jira.