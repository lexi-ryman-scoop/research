---
title: Monday
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Monday.com Integration
  description: >-
    Connect Monday.com CRM data to Scoop for pipeline analysis, deal
    snapshotting, and instant recipes including waterfall reports and sales
    team performance.
  robots: index
next:
  description: ''
---
<Image align="left" width="250px" src="https://files.readme.io/e116b351bccfea419d0708ef913a59108d07ddc43c0e8da94a0b4c5612b60e0c-66f6e0085fe8c5d15fec403b_2xhH7gu1e7JDZB5RRLkeneh3itGFo8lGAOs99cnRFBk.png" />

Scoop is able to grab your data from Monday to enable sophisticated visualization and analysis. 

<br />

# Typical Use Cases with just Monday as a data source

Typical use cases for Scoop with Monday data only include:

* General sales reporting with better visuals and analysis
* Weekly forecasting or pipeline views that leverage snapshotting to review changes
* Snapshotting any/all attributes on any object like Opportunities
* Analyzing sales processes to understand conversion rates and cycle times

Combining Monday data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance.

# Monday Instant Recipes

Scoop has several instant recipes created for Monday so you can get started - instantly. Pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from Monday. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

**Note:** Our instant recipes extract data from the Deal object in your Monday CRM workspace.

# Monday Snapshotting

One of the biggest uses of Scoop for Monday is snapshotting. Scoop can snapshot your deals automatically. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Scoop allows Monday users to snapshot their deals and detect, track and report on all changes, how fast those changes occur and at what rates - allowing deep insights into the sales process.

# Connecting to Monday

To connect to Monday as a data source, create a new dataset linked to Monday. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Monday:

<Image align="center" width="300px" src="https://files.readme.io/0dd82c92a13b8f2f590c79c349ec034db0d028c7b8e1ddd50c2ffe8efd4e1c8a-image.png" />

## Selecting an Object and Fields

After selecting Monday, you can select which object you want to extract and which fields you wish to extract. Please note that Scoop will automatically snapshot your Deals object and will synchronize your Companies, People and Users.

<Image align="center" width="450px" src="https://files.readme.io/75a88a1c003e6229f200f31e407a5bfe8b27b6b6814215954222307756d672da-image.png" />
