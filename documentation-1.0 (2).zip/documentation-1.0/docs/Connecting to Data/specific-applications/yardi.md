---
title: Yardi
excerpt: Import property management data for portfolio analysis
deprecated: false
hidden: false
metadata:
  title: Yardi Integration
  description: >-
    Import Yardi property management reports into Scoop for AI-powered analysis
    of occupancy, rent rolls, maintenance, and portfolio performance.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/586d9ed89ec1c1c3e6b39e17a48833286fa5e1aab362e45644d7cc9e385de6d8-Yardi-Systems-Logo.png" />

## Overview

Yardi is the leading property management software for real estate professionals. Import your Yardi reports into Scoop to analyze occupancy trends, rent performance, maintenance efficiency, and portfolio health with AI-powered insights.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Occupancy** | "Which properties have the highest vacancy rates?" |
| **Rent Roll** | "Show units where rent is below market rate" |
| **Lease Expirations** | "What's our lease expiration exposure next quarter?" |
| **Maintenance** | "Average time to complete work orders by property?" |
| **Collections** | "Which tenants have outstanding balances over 30 days?" |
| **Portfolio** | "Compare NOI across all properties" |

## Importing Yardi Data

### Option 1: Scheduled Report Emails

The most common approach for Yardi integration:

1. In Yardi, navigate to **Reports** and select your report
2. Click **Schedule** to set up recurring delivery
3. Add your Scoop ingest email address as a recipient
4. Choose CSV or Excel format
5. Set your delivery schedule (daily, weekly, monthly)

See [Email Automated Imports](../connect-your-data/email-automated-imports) for Scoop setup.

### Option 2: Manual Export and Upload

1. Run your Yardi report
2. Click **Export** → CSV or Excel
3. Upload to Scoop as a new dataset

### Option 3: SQL Server Connection (Advanced)

If you have direct database access:
1. Connect Scoop to your Yardi SQL Server database
2. Use [Live Query](../databases/live-query) for real-time data

## Key Reports to Import

### Rent Roll
Complete tenant and lease information:
- Unit details and square footage
- Current rent and market rent
- Lease start/end dates
- Tenant information

### Occupancy Report
Track vacancy and leasing:
- Occupied vs. vacant units
- Days vacant
- Move-in/move-out dates
- Leasing activity

### Aged Receivables
Monitor collections:
- Tenant balances
- Days outstanding (0-30, 31-60, 61-90, 90+)
- Payment history
- Collection status

### Work Order Report
Maintenance performance:
- Open vs. closed work orders
- Time to completion
- Cost by category
- Vendor performance

### Financial Statements
Portfolio financials:
- Income by property
- Expenses by category
- NOI and cash flow
- Budget vs. actual

## Snapshotting for Trending

Yardi data changes constantly. Use Scoop's snapshot feature to:

- **Track occupancy trends** - Weekly snapshots show vacancy patterns
- **Monitor collections** - Daily snapshots reveal aging trends
- **Compare periods** - "How does this month compare to last year?"
- **Audit changes** - "What changed in the rent roll this week?"

See [Snapshot Datasets](../connect-your-data/snapshot-datasets) for setup.

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Market Data** | Compare rents to market benchmarks |
| **Weather Data** | Correlate maintenance with weather events |
| **CRM** | Connect prospects to lease conversions |
| **Accounting** | Full financial picture |

### Example: Portfolio Analysis

```
Ask Scoop:
"Show properties ranked by NOI with occupancy
below 90% in the last quarter"
```

## Best Practices

### Standardize Report Formats
- Use the same report template across properties
- Include property identifiers in every report
- Keep column names consistent

### Schedule Strategically
Different reports need different frequencies:
- **Rent Roll**: Weekly (or after major changes)
- **Occupancy**: Daily for active leasing periods
- **Collections**: Daily or weekly
- **Financials**: Monthly

### Include Property Identifiers
Ensure every report includes:
- Property code or ID
- Property name
- Region or portfolio grouping

## Common Use Cases

### Lease Expiration Analysis
Track and plan for renewals:
> "Show all leases expiring in the next 6 months by property"

### Delinquency Tracking
Monitor collection performance:
> "Which tenants have been late 3+ times this year?"

### Maintenance Efficiency
Optimize operations:
> "What's the average work order completion time by category?"

### Portfolio Comparison
Benchmark properties:
> "Rank properties by revenue per square foot"

### Vacancy Cost Analysis
Understand vacancy impact:
> "Calculate lost revenue from vacant units this quarter"

## Troubleshooting

### Report Doesn't Include All Properties
- Check report filters in Yardi
- Verify you have access to all properties
- Ensure the property code is included in output

### Data Not Matching Yardi Totals
- Check the as-of date for point-in-time reports
- Verify all pages/sections were exported
- Compare row counts between systems

### Column Names Changed
- Yardi reports may have different column names based on setup
- Use consistent report templates
- Map columns in Scoop if names differ

## Related Resources

- [Email Automated Imports](../connect-your-data/email-automated-imports) - Set up automated ingestion
- [Snapshot Datasets](../connect-your-data/snapshot-datasets) - Track changes over time
- [Blending Datasets](../connect-your-data/blending-two-datasets) - Combine with other sources
