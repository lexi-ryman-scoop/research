---
title: Microsoft Reporting Services (SSRS)
excerpt: Import SSRS reports to preserve legacy logic with modern analytics
deprecated: false
hidden: false
metadata:
  title: Microsoft SSRS Integration
  description: >-
    Import SQL Server Reporting Services (SSRS) reports into Scoop. Preserve
    legacy business logic while adding AI analysis and data blending.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/8aa4fbe7f6235a9f8df5ffb319e57c78ab9fed7a520f348708a34eb38bcb7f63-ssrs-logo.webp" />

## Overview

Microsoft SQL Server Reporting Services (SSRS) powers many enterprise reporting systems, especially in organizations with legacy applications. Scoop can ingest SSRS reports—including complex banded reports with subtotals—preserving your existing business logic while enabling AI-powered analysis, modern visualization, and data blending.

## Why Import SSRS Reports?

Many organizations have years of business logic embedded in SSRS reports:
- Complex calculations and aggregations
- Validated business rules
- Regulatory compliance reports
- Departmental standards

Scoop lets you **preserve this logic** while adding modern capabilities:
- AI-powered investigation ("Why did this metric change?")
- Natural language queries
- Blending with data from other systems
- Historical snapshots and trending

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Legacy Reports** | "Leverage existing SSRS calculations in Scoop" |
| **Banded Reports** | "Scoop auto-detects grouping and subtotals" |
| **Cross-System** | "Blend SSRS data with Salesforce or spreadsheets" |
| **Historical** | "Track how this report changed over 6 months" |
| **Investigation** | "Why did this metric increase this month?" |

## Importing SSRS Reports

### Option 1: Scheduled Email Delivery (Recommended)

Set up automated ingestion from SSRS subscriptions:

1. In SSRS Report Manager, open your report
2. Click **Subscribe** → **New Subscription**
3. Set delivery method to **E-Mail**
4. Add your Scoop ingest email address as recipient
5. Select **CSV** or **Excel** as the render format
6. Set your delivery schedule

Scoop automatically processes incoming reports and handles:
- Banded report detection
- Subtotal row identification
- Column type inference

See [Email Automated Imports](../connect-your-data/email-automated-imports) for Scoop setup.

### Option 2: Manual Export and Upload

1. Run your SSRS report
2. Click **Export** → CSV or Excel
3. Upload to Scoop as a new dataset

### Option 3: Direct Database Connection

For maximum flexibility, connect Scoop directly to your SQL Server database:

1. Use the same connection SSRS uses
2. Query the underlying data directly
3. Apply filters and calculations in Scoop

See [SQL Server Connection](../databases/sql-server) for setup.

## Banded Report Handling

SSRS commonly produces banded/grouped reports with subtotals. Scoop automatically:

| Capability | How It Works |
|------------|--------------|
| **Detects grouping columns** | Identifies which columns define groups |
| **Finds subtotal rows** | Recognizes "Subtotal" and "Total" patterns |
| **Validates subtotals** | Confirms subtotals sum correctly |
| **Marks row types** | Separates detail rows from summary rows |
| **Preserves hierarchy** | Maintains multi-level grouping structure |

**Example:** A sales report grouped by Region → Territory → Rep with subtotals at each level is automatically parsed into clean, analyzable data.

See [Grouped Reports](../connect-your-data/grouped-reports) for more details.

## Key Report Types to Import

### Operational Reports
Day-to-day business metrics:
- Sales summaries
- Inventory levels
- Production output
- Service metrics

### Financial Reports
Accounting and finance data:
- P&L statements
- Budget vs. actual
- AR/AP aging
- Cost center reports

### Compliance Reports
Regulatory and audit data:
- Required filings
- Audit trails
- Exception reports
- Validation reports

### Management Reports
Executive summaries:
- KPI dashboards
- Departmental rollups
- Variance analysis

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Salesforce** | CRM data + SSRS operational metrics |
| **Excel/Spreadsheets** | Budget targets + SSRS actuals |
| **ERP Systems** | Cross-system operational view |
| **Modern BI Tools** | Compare SSRS to Power BI data |

### Example: Cross-System Analysis

```
Ask Scoop:
"Compare SSRS sales report totals with
Salesforce pipeline by region"
```

## Best Practices

### Preserve Report Logic
- Import reports with their existing calculations
- Use SSRS for validated business rules
- Let Scoop handle analysis and blending

### Use CSV Format
- CSV exports are cleaner than HTML for data
- Excel works but may include formatting issues
- Avoid PDF for data analysis

### Schedule Strategically
- Daily for operational reports
- Weekly for summary reports
- Monthly for financial reports

### Include Identifiers
Ensure reports include:
- Date/period columns
- Region/territory codes
- Account/customer IDs
- Any keys needed for blending

## Common Use Cases

### Modernize Legacy Reporting
Add AI capabilities to existing reports:
> "Why did this region's numbers drop compared to last month?"

### Cross-System Reconciliation
Compare SSRS data with other sources:
> "Do SSRS totals match our Salesforce pipeline by rep?"

### Historical Trending
Track report changes over time:
> "Show how this monthly report has trended over the past year"

### Self-Service Analysis
Let business users explore SSRS data:
> "Break down this report by customer segment and product line"

## SSRS vs. Scoop: Complementary Tools

| Use SSRS For | Use Scoop For |
|--------------|---------------|
| Validated business logic | Ad-hoc investigation |
| Scheduled report delivery | Natural language queries |
| Paginated print reports | Interactive exploration |
| Enterprise standards | Multi-source blending |
| Regulatory compliance | AI-powered insights |

**Best approach:** Keep SSRS for your validated, standard reports. Use Scoop to investigate, explore, and blend that data.

## Troubleshooting

### Subtotals Not Detected
- Ensure subtotal rows contain "Subtotal" or "Total" text
- Check that subtotals are in consistent positions
- Very complex nested reports may need manual review

### Column Alignment Issues
- CSV exports from SSRS are usually clean
- If columns misalign, check for embedded commas in data
- Try Excel format if CSV has issues

### Missing Data
- Check SSRS report parameters match expected date range
- Verify subscription schedule is running
- Ensure report hasn't errored in SSRS

### Formatting in Data
- SSRS may embed formatting (currency symbols, percentages)
- Scoop auto-strips common formatting
- Verify numeric columns are detected correctly

## Related Resources

- [Grouped Reports](../connect-your-data/grouped-reports) - Banded report handling
- [SQL Server Connection](../databases/sql-server) - Direct database access
- [Email Automated Imports](../connect-your-data/email-automated-imports) - Subscription setup
- [Power BI Integration](microsoft-power-bi) - Modern BI comparison
- [Crystal Reports Integration](crystal-reports) - Another legacy BI tool
