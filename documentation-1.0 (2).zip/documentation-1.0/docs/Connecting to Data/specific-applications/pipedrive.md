---
title: Pipedrive
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Pipedrive Integration
  description: >-
    Scoop enhances Pipedrive by enabling advanced sales reporting, snapshotting,
    and data analysis, and allows users to extract, blend, and write back data
    to Pipedrive for optimized performance.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/fbf20c3c3b9188b0f48eabcb73565094f7011c1a3badb97e16d7cfba98ac62a3-image.png" />

<br />

Scoop is able to grab your data from Pipedrive to enable sophisticated visualization and analysis. 

# Typical Pipedrive Use Cases with Pipedrive Only

Typical use cases for Scoop with Pipedrive data only include:

* General sales reporting with better visuals and analysis
* Weekly forecasting or pipeline views that leverage snapshotting to review changes
* Snapshotting any/all attributes on any object like Opportunities
* Analyzing sales processes to understand conversion rates and cycle times

Combining PipeDrive data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance.

# Pipedrive Instant Recipes

Scoop has several instant recipes created for Pipedrive to get you started quickly. The recipes are pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from Pipedrive. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

# Pipedrive Snapshotting

One of the biggest uses of Scoop for Pipedrive is snapshotting. Scoop can snapshot any object, including Pipedrive sales objects. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Even Salesforce.com has limited abilities to analyze changes and whole industries have been built around that. Scoop gives greater capabilities for Pipedrive users than anything available to Salesforce customers (except those using Scoop).

# Connecting to Pipedrive

To connect to Pipedrive as a datasource, create a new dataset linked to Pipedrive. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Pipedrive:

<Image align="center" width="300px" src="https://files.readme.io/a84c55777bc0dea8fe7495280068897cd13488313ed64f9a7a2a56d0466faa7c-image.png" />

## Loading from a Report vs. API

With Pipedrive you can select either a report data source or using the API as a data source. The advantage of using a report as a data source is that any linked fields from different objects will be properly displayed in your report and can therefore be easily loaded. With the API, often items that link to different objects do so via an ID field. This requires you to bring in both objects and then use Scoops blending capabilities to lookup the required field from the linked object.

## Loading from the API

Select API Data Source:

<Image align="center" width="300px" src="https://files.readme.io/76fbc5ec4c537869b07efa36db8ae43aff98b4fe0337e08b35ac7d987e58d8c9-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" width="300px" src="https://files.readme.io/c84d085-image.png" />

After connecting to Pipedrive to Scoop, select the object that you wish to extract, and the columns that you wish to extract.

<Image align="center" width="300px" src="https://files.readme.io/d061f6be25fbf1fd1fdfbd803fcb5f65934db7c89fceb96a4c106ab1b431762f-image.png" />

Also, select a dataset name. After you save this dialog, you can elect to have Scoop run an immediate extract (by checking the extract data now button). Scoop will automatically run this extract overnight each day after you set this up.

# Writing back to Pipedrive from a Scoop dataset

With Scoop you can blend data with other datasets and create new fields with ease. Scoop's ability to use spreadsheet logic gives you that same spreadsheet flexibility to add arbitrary and powerful calculations to your dataset. It is often useful to then bring those sophisticated calculations back into your source application. Scoop's API Writeback feature allows you to take any Scoop dataset and write values back into your Pipedrive application. This means that you can extract data from Pipedrive (which is necessary to extract the Pipedrive record ID which is required to write back into Pipedrive), blend it with other data or create new calculations and then push those back into your Pipedrive application.

In order to write back into Pipedrive, you must first establish an API connection to Pipedrive and extract records that you wish to augment (see above). The Record ID will be part of your extracted dataset. You can either create calculated columns with that dataset, or you can blend that dataset with others in Scoop to create a new dataset. Be sure to make sure that the Record ID stays with your records as you blend them together (i.e. always select that column when building a new blended dataset).

Once that is done, you can now update Pipedrive whenever your dataset in question is processed. When that connection is established, the following option becomes available on the dataset menu:

<Image align="center" width="300px" src="https://files.readme.io/04a04ab-image.png" />

You can select "Setup Application Writeback" to create a writeback definition for Scoop. This definition tells Scoop what to do each time that dataset is processed. When processing is done, it will use that dataset and take the fields that you map and write them back to Pipedrive using the Record IDs that you initially extracted.

<Image align="center" width="400px" src="https://files.readme.io/3b94bc6-image.png" />

The definition essentially allows you to pick fields from one table within your dataset and map those back to fields within Pipedrive. 

<Image align="center" width="400px" src="https://files.readme.io/244a1d5-image.png" />

So if, for example, you wanted to map a single column in Pipedrive to a Scoop dataset, you simply select from the dropdown which Scoop dataset column you want to use. Once that is done, each time that dataset is processed, Scoop will update Pipedrive to ensure that that field will contain the value calculated in Scoop.
