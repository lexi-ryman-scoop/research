---
title: Oracle BI
excerpt: Import Oracle BI reports into Scoop for AI-powered analysis
deprecated: false
hidden: false
metadata:
  title: Oracle BI Integration
  description: >-
    Import Oracle BI Publisher and Oracle Reports exports into Scoop. Export as
    HTML or CSV and upload directly or via email automation.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/32701ae7727db457aa7ed073990cc86211ebe4645ec5a7560ec457c81babd51f-oracle.png" />

## Overview

Oracle BI (including Oracle BI Publisher, Oracle Analytics, and Oracle Reports) can export data that Scoop imports directly. While there's no native API connector, Scoop's file import capabilities make it easy to analyze Oracle BI data.

## Connection Methods

### Method 1: HTML Export (Recommended)

Oracle BI can export reports as HTML, which Scoop imports with full table structure preserved.

1. Run your report in Oracle BI
2. Export as HTML format
3. Upload to Scoop or forward via email

See [Importing HTML Reports](../connect-your-data/importing-html-reports) for detailed steps.

### Method 2: CSV/Excel Export

For simpler data:

1. Export your Oracle BI report as CSV or Excel
2. Upload directly to Scoop

### Method 3: Email Automation

Set up scheduled Oracle BI reports to email automatically:

1. Configure Oracle BI to email reports on a schedule
2. Forward emails to your Scoop ingest address
3. Scoop processes attachments automatically

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## What You Can Analyze

| Data Type | Recommended Export | Notes |
|-----------|-------------------|-------|
| Financial Reports | HTML or Excel | Preserves formatting |
| Operational Dashboards | CSV | Clean tabular data |
| Banded/Grouped Reports | HTML or Excel | Scoop auto-detects subtotals |
| Ad-hoc Queries | CSV | Direct data export |

## Best Practices

1. **Use HTML for complex reports** - Tables, grouping, and formatting preserved
2. **Use CSV for simple data** - Fastest processing
3. **Include headers** - Helps Scoop identify columns
4. **Set up email automation** - For recurring reports

## Handling Grouped Reports

Oracle Reports often include subtotals and group breaks. Scoop automatically:
- Detects grouping levels
- Removes subtotal rows
- Preserves data for analysis

See [Grouped Reports](../connect-your-data/grouped-reports) for details.

## Related Resources

- [Importing HTML Reports](../connect-your-data/importing-html-reports)
- [Email Automated Imports](../connect-your-data/email-automated-imports)
- [Grouped Reports](../connect-your-data/grouped-reports)
