---
title: Copper CRM
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Copper CRM Integration
  description: >-
    Scoop enables data extraction from Copper for advanced visualization and
    analysis, with features like snapshotting to track changes in sales
    processes, and supports integration with other data sources for enhanced
    marketing insights.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/19cd2d459cc09bb86532a2e5728da688174dcb3bd8f322dda10ee69455ccbd63-image.png" />

Scoop is able to grab your data from Copper to enable sophisticated visualization and analysis.

# Copper Objects

Scoop allows you to extract all main objects in Copper:

* Leads
* People
* Companies
* Opportunities
* Projects
* Tasks
* Activities
* Users

# Typical Use Cases with Copper Only

Typical use cases for Scoop with Copper data only include:

* General sales reporting with better visuals and analysis
* Weekly forecasting or pipeline views that leverage snapshotting to review changes
* Snapshotting any/all attributes on any object like Opportunities
* Analyzing sales processes to understand conversion rates and cycle times

Combining Copper data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance.

# Copper Instant Recipes

Scoop has several instant recipes created for Copper to get you started quickly. The recipes are pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from Copper. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

# Copper Snapshotting

One of the biggest uses of Scoop for Copper is snapshotting. Scoop can snapshot your deals automatically. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Scoop allows Copper users to snapshot their deals and detect, track and report on all changes, how fast those changes occur and at what rates - allowing deep insights into the sales process.

# Connecting to Copper

To connect to Copper as a data source, create a new dataset linked to Copper. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select Copper:

<Image align="center" width="300px" src="https://files.readme.io/6f95d41733d0f58f6a9452532a55c1970944a2e03c0c2f39455c3c14830347ca-image.png" />

## Selecting an Object and Fields

After selecting Copper, you can select which object you want to extract and which fields you wish to extract. Please note that Scoop will automatically snapshot your Opportunities object and will synchronize your other objects.

<Image align="center" width="500px" src="https://files.readme.io/2eeedf775230bc45c7d604594e127ad620cdfc206f752f712347540091a1a386-image.png" />
