---
title: Crystal Reports
excerpt: Import Crystal Reports into Scoop for AI-powered analysis
deprecated: false
hidden: false
metadata:
  title: Crystal Reports Integration
  description: >-
    Import SAP Crystal Reports into Scoop. Export as HTML to preserve banded
    report structure, or CSV for simple data. Scoop auto-detects subtotals.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/f51b80625422af572cdfa2a31aabad61d3f7bc972d6c56dc09fba2004cddb188-sap-logo.jpg" />

## Overview

Scoop integrates seamlessly with SAP Crystal Reports. Export your reports as HTML or CSV, and Scoop imports them directly - preserving any legacy logic you rely on while enabling AI-powered analysis and data blending.

## Why Crystal Reports + Scoop?

- **Preserve legacy investment** - Keep using reports you've built over years
- **Add AI analysis** - Ask questions about your Crystal Reports data in natural language
- **Blend with other data** - Combine Crystal Reports with CRM, ERP, and other sources
- **Automate ingestion** - Set up scheduled email imports

## Connection Methods

### Method 1: HTML Export (Recommended for Banded Reports)

Crystal Reports' banded/grouped reports export beautifully to HTML, and Scoop handles them automatically:

1. Open your Crystal Report
2. **File** > **Export** > **HTML 4.0**
3. Upload the HTML file to Scoop

Scoop automatically:
- Extracts all tables from the HTML
- Detects grouping levels and subtotals
- Separates summary rows from detail data
- Preserves your data for clean analysis

See [Importing HTML Reports](../connect-your-data/importing-html-reports) for detailed steps.

### Method 2: CSV/Excel Export

For simpler tabular data:

1. Open your Crystal Report
2. **File** > **Export** > **CSV** or **Excel**
3. Upload directly to Scoop

### Method 3: Email Automation

Automate recurring Crystal Reports:

1. Configure Crystal Reports to email on a schedule
2. Forward emails to your Scoop ingest address (e.g., `yourteam@ingest.scoopanalytics.com`)
3. Scoop processes attachments automatically

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## Handling Banded Reports

Crystal Reports is famous for banded/grouped reports with subtotals. Scoop's `BandedReportValidator` automatically:

| Detection | What Scoop Does |
|-----------|-----------------|
| **Grouping columns** | Identifies which columns define groups |
| **Subtotal rows** | Detects rows containing "Subtotal" or "Total" |
| **Aggregation rules** | Determines SUM, AVG, COUNT per column |
| **Grand totals** | Finds and validates report totals |

**Result:** Clean detail rows for analysis, with grouping metadata preserved for drill-down.

See [Grouped Reports](../connect-your-data/grouped-reports) for the full guide.

## What You Can Analyze

| Crystal Report Type | Best Export | Notes |
|--------------------|-------------|-------|
| Summary Reports | HTML | Subtotals auto-detected |
| Detail Reports | CSV or HTML | Clean tabular data |
| Cross-Tab Reports | HTML | Matrix structure preserved |
| Subreports | HTML | Each subreport as separate table |
| Charts (data only) | CSV | Export underlying data |

## Best Practices

1. **Use HTML for grouped reports** - Preserves structure, Scoop handles subtotals
2. **Use CSV for simple lists** - Fastest processing
3. **Include column headers** - Helps Scoop identify fields
4. **Export "Details" for clean data** - Avoid pre-summarized exports when possible
5. **Set up email automation** - For recurring reports

## Common Use Cases

### Financial Reporting
Import monthly financial reports, preserve grouping structure, blend with budget data from other systems.

### Sales Analysis
Combine Crystal Reports sales data with CRM data from Salesforce or HubSpot.

### Operations Dashboards
Import operational Crystal Reports, blend with real-time data, create unified dashboards.

### Legacy System Integration
Keep using Crystal Reports for data extraction while modernizing analysis with Scoop AI.

## Troubleshooting

### Subtotals Not Detected

**Problem:** Scoop includes subtotal rows in the data.

**Solution:** Ensure your report uses standard labels like "Subtotal" or "Total". See [Grouped Reports](../connect-your-data/grouped-reports) for troubleshooting.

### Missing Data in Export

**Problem:** Some sections missing from HTML export.

**Solution:** Try exporting with different HTML options, or export specific sections separately.

### Date Formatting Issues

**Problem:** Dates don't parse correctly.

**Solution:** Configure date formats in your Crystal Report before export, or adjust column types in Scoop.

## Related Resources

- [Importing HTML Reports](../connect-your-data/importing-html-reports)
- [Grouped Reports](../connect-your-data/grouped-reports)
- [Email Automated Imports](../connect-your-data/email-automated-imports)
- [Best Practices for Source Reports](../connect-your-data/best-practices-in-selecting-creating-source-reports)
