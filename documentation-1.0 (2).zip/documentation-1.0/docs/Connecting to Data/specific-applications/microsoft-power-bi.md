---
title: Microsoft Power BI
excerpt: Import Power BI reports for AI-powered analysis and data blending
deprecated: false
hidden: false
metadata:
  title: Microsoft Power BI Integration
  description: >-
    Import Power BI reports into Scoop for AI-powered analysis. Connect to the
    same data sources with better exploration and blend with other data.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/e51a4d913d31751f6b2b94e2edcb1d4dc33325e800ab719e8c217ab2faff7492-PowerBI.webp" />

## Overview

Microsoft Power BI is one of the most popular business intelligence tools. Scoop can import your Power BI reports to enable AI-powered analysis, natural language queries, and blending with data from other sources. Better yet, Scoop can connect directly to the same data sources Power BI uses—giving you enhanced investigation capabilities on your existing data infrastructure.

## Two Ways to Work with Power BI Data

### Option 1: Connect to the Same Data Sources (Recommended)

Instead of importing Power BI reports, connect Scoop directly to your underlying databases:

**Why this is better:**
- Access the same governed data Power BI uses
- No export/import cycle needed
- Real-time data access
- Leverage your existing data warehouse investments

**Supported connections:**
- Azure SQL Database
- Azure Synapse Analytics
- SQL Server
- Snowflake
- PostgreSQL
- And [many more databases](../databases/index)

See [Connecting to Databases](../databases/index) for setup instructions.

### Option 2: Import Power BI Report Exports

For cases where you need the specific transformations in Power BI:

1. In Power BI, open your report
2. Click **Export** → **Export to CSV** or **Export to Excel**
3. Upload to Scoop as a new dataset

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Transformed Data** | "Leverage Power BI's DAX calculations in Scoop" |
| **Cross-Source** | "Blend Power BI exports with other data sources" |
| **Historical Trends** | "Track how metrics change over time with snapshots" |
| **AI Investigation** | "Why did revenue drop last month?" |

## When to Use Each Approach

| Scenario | Recommended Approach |
|----------|---------------------|
| You have a data warehouse | Connect Scoop directly to the warehouse |
| Power BI connects to cloud databases | Connect Scoop to the same databases |
| You need specific DAX calculations | Export and import those specific reports |
| You want ad-hoc AI investigation | Direct database connection |
| You need to blend Power BI with other tools | Either approach works |

## Importing Power BI Reports

### Export from Power BI Service

1. Open your report in Power BI Service
2. Select the visual or table you want to export
3. Click **More options (...)** → **Export data**
4. Choose **Summarized data** or **Underlying data**
5. Select CSV or Excel format
6. Upload to Scoop

### Export from Power BI Desktop

1. Open your report in Power BI Desktop
2. Right-click on the visual
3. Select **Export data**
4. Save as CSV
5. Upload to Scoop

### Automated Exports via Email

1. In Power BI Service, subscribe to report emails
2. Forward to your Scoop ingest email address
3. Scoop processes attachments automatically

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## Key Benefits of Adding Scoop

| Power BI Capability | Scoop Enhancement |
|--------------------|-------------------|
| Static dashboards | AI-driven investigation |
| Scheduled refresh | On-demand exploration |
| Pre-built visuals | Natural language queries |
| Single-source analysis | Multi-source blending |
| Point-in-time views | Historical snapshots |

### Example: Investigative Analysis

In Power BI, you see revenue dropped. In Scoop, ask:

```
Ask Scoop:
"Why did revenue decrease this month compared to last month?
Break down by region, product, and customer segment."
```

Scoop investigates the underlying data and surfaces the key drivers.

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Salesforce** | CRM data + Power BI metrics |
| **Google Analytics** | Web traffic + business metrics |
| **Spreadsheets** | Budget targets + actuals |
| **Other BI Tools** | Cross-tool comparison |

## Best Practices

### For Direct Database Connections
- Use the same connection credentials as Power BI
- Leverage existing data governance
- Schedule syncs to match Power BI refresh times

### For Report Imports
- Export underlying data, not summarized
- Include all relevant dimensions
- Use consistent date ranges

### For Snapshots
Power BI shows current state. Use Scoop to:
- Track KPI changes over time
- Compare periods
- Audit data changes

## Common Use Cases

### Extend Power BI with AI
Use AI to investigate patterns:
> "What factors correlate with our highest-performing regions?"

### Blend with Non-Microsoft Data
Combine Power BI insights with other sources:
> "Show Power BI sales metrics alongside Google Analytics traffic"

### Historical Analysis
Track changes over time:
> "How has this dashboard's key metric changed over the past 6 months?"

### Self-Service Investigation
Empower business users:
> "Let me explore this data without waiting for IT to build a new report"

## Power BI vs. Scoop: Complementary Tools

| Use Power BI For | Use Scoop For |
|------------------|---------------|
| Enterprise dashboards | Ad-hoc investigation |
| DAX calculations | Natural language queries |
| Scheduled reports | On-demand exploration |
| Governed datasets | Multi-source blending |
| Microsoft ecosystem | Cross-platform analysis |

**They work best together:** Power BI for your standard reporting, Scoop for investigation and exploration.

## Troubleshooting

### Export Doesn't Include All Data
- Power BI may limit export rows (30K for visuals)
- Try exporting underlying data instead of summarized
- Use Power BI's "Analyze in Excel" for larger exports

### Data Types Changed After Import
- Numbers may export as text in some formats
- Scoop auto-detects types but verify after import
- Date formats may need adjustment

### Can't Connect to Same Data Source
- Verify firewall allows Scoop's IP: `44.231.97.118`
- Check credentials have read access
- Ensure database allows external connections

## Related Resources

- [Database Connections](../databases/index) - Connect to underlying data
- [Importing HTML Reports](../connect-your-data/importing-html-reports) - For HTML exports
- [Tableau Integration](tableau) - Similar BI tool integration
- [Snowflake Integration](snowflake) - Common Power BI data source
- [Email Automated Imports](../connect-your-data/email-automated-imports)
