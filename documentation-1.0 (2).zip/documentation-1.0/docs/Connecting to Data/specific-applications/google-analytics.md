---
title: Google Analytics
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Google Analytics Integration
  description: >-
    Import Google Analytics web traffic and engagement data into Scoop for
    cross-channel marketing analysis.
  robots: index
next:
  description: ''
---
<Image align="left" border={false} width="200px" src="https://files.readme.io/bbf3a2bc39d4cf5893af4bd01ca2a49537f60df6f78c616e5c86a9b8e62aa2b4-image.png" />

Google Analytics is a web analytics tool that helps people track and analyze website or app performance

<br />

# GA Data Storage

With the upgrade to GA4, Google has limited data storage for both User-Level data and Other Event data to a period of 2 to 14 months, depending on your settings.

Scoop has the ability to store data from Google Analytics for an unlimited time period.

# Connecting to Google Analytics

To connect to Google Analytics as a data source, create a new dataset linked to Google Analytics. First, on the datasets page, select applications as a source:

<Image align="center" border={false} width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select google analytics:

<Image border={false} src="https://files.readme.io/72a0f786d3b9b728c720e656f41d43b44c6616c45db22ed12fa2972ee4f13381-image.png" />

## Selecting an Object and Fields

After selecting Google Analytics, you can select which object you want to extract and which fields you wish to extract.

<Image border={false} src="https://files.readme.io/b2d6ee5e3d7e30cc9284cfe8ac13d16fc2e4bd4433526ad865488e857c37da98-image.png" />

<br />

The most common use case for Google Analytics is website analytics data. Scoop pulls daily web traffic data and pulls it into a database. Unlike the recent up to GA4, which eliminates access to data greater than 14 months, Scoop will store the Google Analytics data for as long as your company needs.

Typical dimensions include event name, full page URL, date, first user campaign, City ID, first user source, date of week, page title, and session medium.

Typical metrics include user engagement, sessions per users, views per session, views, ad source, and date. Be aware that Google Analytics does not support all combinations of dimensions and metrics. The same ones that you can access withing Google Analytics can be extracted into Scoop and blended with other data.

# Google Analytics Dataset Configuration Guide

## Choosing the Right Properties for Your GA4 Dataset

Google Analytics 4 has specific requirements about which properties can be combined in a single query, making it challenging to know which properties to select when creating your dataset. This guide provides a simple approach to overcome this challenge.

### The Challenge

GA4 organizes data into different scopes and categories that don't always play well together. Selecting incompatible properties will result in errors or incomplete data. Rather than guessing which properties work together, you can use AI to help you make informed choices.

### Quick Solution: Use AI to Select Compatible Properties

Here's a simple hack to get the right properties for your analysis goals:

#### Step 1: Define Your Analysis Goal

Start by clearly stating what you want to analyze. For example:

* "I want to analyze campaign data and traffic sources"
* "I need to understand user behavior and engagement metrics"
* "I want to track conversion paths and goal completions"
* "I need to analyze page performance and user interactions"

#### Step 2: Ask AI for Property Recommendations

Use Claude, ChatGPT, or another AI assistant with this prompt:

```
I'm creating a Google Analytics dataset in Scoop. My goal is to [insert your analysis goal here]. 

Based on Google Analytics 4 best practices for property pairing and compatibility, please recommend up to 15 GA4 properties that will help me achieve this goal. Make sure to:
- Follow GA4's dimensional compatibility rules
- Avoid mixing incompatible scopes (user vs session vs event)
- Ensure the properties can be queried together without errors
- Prioritize the most relevant metrics and dimensions for my analysis goal

Here's the list of available properties:
[Copy and paste the full list of available properties from below]
```

#### Step 3: Apply the Recommendations

Take the 15 properties suggested by the AI and check them off in your Scoop dataset configuration. This ensures you have a focused, compatible set of properties that align with your analysis goals.

### Available GA4 Properties

Here's the complete list of properties you can choose from when creating your dataset:

```
- achievementId
- adClickAdsense
- adDestinationUrl
- adUnitNameAdsense
- adFormatAdsense
- adGroup
- adSourceNameAdsense
- adUnitNameAdsense
- adsenseRevenue
- adsQuery
- age
- appVersion
- audienceId
- audienceName
- bounceRate
- bounces
- brandingInterest
- browser
- browserVersion
- campaign
- campaignId
- channelGroup
- character
- city
- cityId
- cm360AccountId
- cm360AccountName
- cm360AdvertiserId
- cm360AdvertiserName
- cm360CampaignId
- cm360CampaignName
- cm360CreativeFormat
- cm360CreativeId
- cm360CreativeName
- cm360CreativeType
- cm360CreativeTypeId
- cm360CreativeVersion
- cm360Medium
- cm360PlacementCostStructure
- cm360PlacementId
- cm360PlacementName
- cm360RenderingId
- cm360SiteId
- cm360SiteName
- cm360Source
- cm360SourceMedium
- cohort
- cohortActiveUsers
- cohortTotalUsers
- contentGroup
- contentId
- contentType
- continent
- continentId
- conversions
- country
- countryId
- currencyCode
- customEvent
- dataSource
- date
- dateHour
- dateHourMinute
- day
- dayOfWeek
- defaultChannelGroup
- deviceCategory
- deviceModel
- eventCount
- eventName
- eventValue
- exitRate
- exits
- fileExtension
- fileName
- firebaseAppId
- firstSessionDate
- firstUserDefaultChannelGroup
- firstUserMedium
- firstUserSource
- fullPageUrl
- gender
- googleAdsAccountName
- googleAdsAdGroupId
- googleAdsAdGroupName
- googleAdsAdNetworkType
- googleAdsCampaignId
- googleAdsCampaignName
- googleAdsCampaignType
- googleAdsCreativeId
- googleAdsCustomerId
- googleAdsKeyword
- googleAdsQuery
- groupId
- hostName
- hour
- interests
- isConversionEvent
- isoWeek
- isoYear
- isoYearIsoWeek
- itemAffiliation
- itemBrand
- itemCategory
- itemCategory2
- itemCategory3
- itemCategory4
- itemCategory5
- itemId
- itemListId
- itemListName
- itemListPosition
- itemLocationID
- itemName
- itemPromotionCreativeName
- itemPromotionCreativeSlot
- itemPromotionId
- itemPromotionName
- itemVariant
- itemsAddedToCart
- itemsCheckedOut
- itemsClickedInList
- itemsClickedInPromotion
- itemsPurchased
- itemsViewed
- itemsViewedInList
- itemsViewedInPromotion
- landingPage
- language
- languageCode
- level
- linkClasses
- linkDomain
- linkId
- linkText
- linkUrl
- manualAdContent
- manualTerm
- medium
- method
- metro
- metroId
- minute
- mobileDeviceBranding
- mobileDeviceMarketingName
- mobileDeviceModel
- month
- newUsers
- operatingSystem
- operatingSystemVersion
- operatingSystemWithVersion
- orderCoupon
- organicGoogleSearchAvgPos
- organicGoogleSearchClickThroughRate
- organicGoogleSearchClicks
- organicGoogleSearchImpressions
- organicGoogleSearchQuery
- outboundClick
- pageLocation
- pagePath
- pagePathPlusQueryString
- pageReferrer
- pageTitle
- pageviews
- percentScrolled
- platform
- platformDeviceCategory
- publisherAdClicks
- publisherAdImpressions
- quarter
- region
- screenResolution
- scrolledUsers
- searchTerm
- sessionCampaign
- sessionDefaultChannelGroup
- sessionDuration
- sessionEngagedDuration
- sessionMedium
- sessionSource
- sessionSourcePlatform
- sessions
- sessionsPerUser
- source
- sourceMedium
- sourcePlatform
- streamId
- streamName
- testDataFilterId
- testDataFilterName
- totalAdRevenue
- totalRevenue
- totalUsers
- transactionId
- transactions
- unifiedPageScreen
- unifiedScreenClass
- unifiedScreenName
- userAgeBracket
- userEngagement
- userEngagementDuration
- userGender
- users
- videoProvider
- videoTitle
- videoUrl
- virtualCurrencyName
- virtualItemName
- week
- year
- yearWeek
```

### Important Notes

* **You don't have to use this method** - If you're familiar with GA4's data model, you can select properties manually
* **This is a helpful shortcut** - Especially useful when you're unsure which properties to choose or want to ensure compatibility
* **Start focused** - It's better to start with fewer, relevant properties than to select everything
* **Iterate as needed** - You can always create additional datasets with different property combinations for different analysis needs

### Common Property Combinations

Here are some tested combinations that work well together:

**Traffic Analysis**

* source, medium, campaign, channelGroup, sessions, users, newUsers, bounceRate, sessionDuration, pageviews

**Content Performance**

* pagePath, pageTitle, pageviews, users, avgTimeOnPage, bounceRate, exitRate, entrances

**E-commerce Analysis**

* itemName, itemCategory, itemBrand, itemsViewed, itemsAddedToCart, itemsPurchased, itemRevenue, transactionId

**User Behavior**

* deviceCategory, browser, operatingSystem, country, city, language, userEngagementDuration, sessionsPerUser

Remember: The key is aligning your property selection with your specific analysis goals. When in doubt, use AI assistance to ensure you're choosing compatible properties that will give you the insights you need.
