---
title: NetSuite
excerpt: 'Analyze ERP financial, inventory, and operational data'
deprecated: false
hidden: false
metadata:
  title: NetSuite Integration
  description: >-
    This document outlines the use cases for Netsuite as a single data source,
    including better analysis and visualization of data, presenting live data,
    and customer lifetime value analysis. It also discusses blending Netsuite
    data with other sources for purposes such as marketing cost analysis,
    customer value segmentation, product value segmentation, and customer
    success risk analysis.
  robots: index
next:
  description: ''
---
<Image align="left" width="250px" src="https://files.readme.io/4b268ba-image.png" />

<br />

<br />

<br />

Connect NetSuite to Scoop to analyze your ERP data—financials, inventory, orders, and customer transactions. Go beyond NetSuite's built-in reporting with enhanced visualization, snapshot process analysis, and the ability to blend operational data with CRM, marketing, and product metrics.

# What You Can Analyze

| Domain | Analysis Types |
|--------|---------------|
| **Financial** | Revenue trends, expense tracking, profitability |
| **Orders** | Order pipeline, fulfillment cycles, backlog aging |
| **Inventory** | Stock levels, turnover, demand patterns |
| **Customers** | Lifetime value, payment patterns, segmentation |
| **Vendors** | Spend analysis, performance, payment cycles |

# Connecting NetSuite to Scoop

## Automated Email Reports

NetSuite saved searches can be scheduled to email to Scoop:

1. Create or select a Saved Search in NetSuite
2. Schedule the search for email delivery
3. Add your Scoop dataset email as recipient
4. Choose frequency (daily, weekly, monthly)

## Report Format Support

Scoop handles multiple NetSuite export formats:

| Format | Best For |
|--------|----------|
| **CSV** | Transaction data, detailed reports |
| **Excel** | Financial statements, formatted exports |
| **PDF** | Not recommended (use CSV/Excel instead) |

## Manual Upload

For one-time or ad-hoc analysis:

1. Export data from NetSuite
2. Upload to Scoop via file upload or Google Drive
3. Configure dataset settings
4. Process and analyze

# Recommended Data Extracts

## Financial Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **P&L** | Account, Period, Amount | Profitability trends |
| **Balance Sheet** | Account, Date, Balance | Financial position |
| **Revenue by Customer** | Customer, Amount, Date | Revenue analysis |
| **Expenses** | Account, Department, Amount | Cost management |

## Order Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **Sales Orders** | Order ID, Customer, Amount, Status | Pipeline tracking |
| **Purchase Orders** | PO ID, Vendor, Amount, Status | Procurement analysis |
| **Invoices** | Invoice ID, Customer, Amount, Due Date | AR management |
| **Fulfillments** | Order ID, Ship Date, Carrier | Delivery performance |

## Inventory Data

| Report Type | Key Fields | Analysis Use |
|-------------|------------|--------------|
| **Stock Levels** | Item, Location, Quantity | Inventory health |
| **Item Receipts** | Item, Date, Quantity | Replenishment tracking |
| **Item Fulfillments** | Item, Date, Quantity | Demand patterns |

# Use Cases: NetSuite Only

## Financial Analysis

Enhanced reporting beyond NetSuite's capabilities:

- **Revenue trends**: Track by customer, product, region
- **Margin analysis**: Profitability by segment
- **Cash flow patterns**: AR/AP aging and trends
- **Budget vs. actual**: Variance with drill-down

## Order Process Analysis

Snapshot orders to analyze fulfillment cycles:

- **Order aging**: Time from order to fulfillment
- **Stage progression**: How orders move through statuses
- **Bottleneck identification**: Where orders get stuck
- **Backlog trends**: Growing or shrinking pipeline

## Inventory Intelligence

Track inventory patterns over time:

- **Stock trends**: Levels by location and item
- **Turnover analysis**: Fast vs. slow moving items
- **Reorder patterns**: Timing and quantity trends

# Use Cases: Blending with Other Sources

## NetSuite + CRM

**Goal**: Connect financial outcomes to sales activities

| NetSuite Data | CRM Data | Combined Insight |
|---------------|----------|------------------|
| Revenue by customer | Account details | Revenue by segment/industry |
| Order history | Opportunity data | Win rate by segment |
| Collections | Customer health score | Credit risk analysis |

## NetSuite + Marketing

**Goal**: Calculate full-funnel ROI

- Marketing spend per campaign
- Revenue attributed to marketing
- Customer acquisition cost
- Marketing-influenced pipeline

## NetSuite + Product Usage

**Goal**: Correlate usage with revenue outcomes

- Revenue per active user
- Feature adoption vs. expansion
- Usage patterns of churned customers

## NetSuite + Support

**Goal**: Calculate true customer profitability

- Revenue per customer
- Support tickets and costs
- Net profitability ranking

# Setting Up Snapshot Analysis

For order and inventory process analysis, configure as **Snapshot** dataset:

## Order Snapshot

Include orders that are open or recently completed:

```
Status is not Closed OR Closed Date is within last 7 days
```

## Inventory Snapshot

Daily snapshots of stock levels enable trend analysis:
- Track inventory build-up or depletion
- Identify seasonal patterns
- Monitor days of supply

# Best Practices

## Saved Search Design

- Include unique identifiers (Transaction ID, Item ID)
- Add all date fields needed for analysis
- Use consistent naming conventions
- Include classification fields for segmentation

## Update Frequency

| Data Type | Recommended Frequency |
|-----------|----------------------|
| Financial summaries | Weekly or monthly |
| Order data | Daily |
| Inventory levels | Daily |
| Customer data | Weekly |

## Data Quality

- Ensure customer/item records are linked properly
- Validate currency conversions if multi-currency
- Check that classifications are consistently applied

# Troubleshooting

## Report Format Issues

- Use CSV or Excel format (avoid PDF)
- Check for special characters in data
- Ensure column headers in first row

## Missing Transactions

- Verify Saved Search filters
- Check subsidiary and date filters
- Confirm user permissions

## Data Not Syncing

- Confirm scheduled search is running
- Check email delivery to Scoop address
- Verify dataset email configuration

# Related Topics

- [Blending Datasets](../../Preparing%20Datasets/blending-two-datasets) - Combine NetSuite with other sources
- [Snapshot Datasets](../../Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets) - Track order/inventory changes
- [Adding Calculated Columns](../../Preparing%20Datasets/adding-calculated-columns) - Create derived metrics
- [Email Data Ingestion](../connect-your-data/data-email-ingestion) - Set up automated loading
