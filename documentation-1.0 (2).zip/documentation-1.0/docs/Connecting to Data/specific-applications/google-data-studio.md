---
title: Google Data Studio (Looker Studio)
excerpt: Import Looker Studio reports for multi-source analysis
deprecated: false
hidden: false
metadata:
  title: Google Data Studio (Looker Studio) Integration
  description: >-
    Import Google Data Studio (Looker Studio) reports into Scoop for AI-powered
    analysis. Combine visualizations from Looker Studio with other data sources.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/111388a-image.png" />

## Overview

Google Data Studio (now Looker Studio) is Google's free business intelligence and data visualization tool. Import your Looker Studio reports into Scoop to combine them with other data sources, apply AI-powered analysis, and build dynamic presentations.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Marketing Performance** | "Which campaigns drove the most conversions?" |
| **Website Analytics** | "How does traffic compare to last month?" |
| **Multi-Source Data** | "Combine GA4 and Google Ads data with CRM" |
| **Cross-Platform** | "Compare Looker Studio metrics with other BI tools" |
| **Historical Trends** | "Track KPIs over time with snapshots" |

## Importing Data from Looker Studio

### Option 1: Export and Upload

1. Open your Looker Studio report
2. Click **File** → **Download** → **CSV**
3. Select the date range and components to export
4. Upload the CSV to Scoop as a new dataset

### Option 2: Scheduled Email Reports

1. In Looker Studio, click **File** → **Schedule email delivery**
2. Set your delivery schedule (daily, weekly, monthly)
3. Under "Recipients," add your Scoop ingest email address
4. Select CSV as the attachment format
5. Click **Schedule**

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

### Option 3: Google Sheets Connection

For live data access:
1. In Looker Studio, connect your data to a Google Sheet
2. Use Scoop's [Google Sheets Snapshot](../connect-your-data/automated-snapshotting-of-google-sheets-data) feature
3. Data updates automatically on your schedule

## Key Reports to Import

### Marketing Dashboard
Track campaign performance across channels:
- Impressions and reach
- Click-through rates
- Conversion metrics
- Cost per acquisition

### Website Analytics
Monitor site performance:
- Sessions and users
- Page views and engagement
- Traffic sources
- Goal completions

### Combined Reports
Looker Studio can blend multiple data sources:
- GA4 + Google Ads data
- Search Console metrics
- BigQuery datasets
- Third-party connectors

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Salesforce** | Connect marketing to revenue |
| **HubSpot** | Lead source attribution |
| **Google Analytics** | Compare processed vs. raw data |
| **Spreadsheets** | Add budget or target data |

### Example: Attribution Analysis

```
Ask Scoop:
"Show revenue by marketing channel, combining
Looker Studio attribution with CRM closed deals"
```

## Best Practices

### Export Consistently
- Use the same date range format
- Include all relevant dimensions
- Export on a regular schedule for trending

### Leverage Blended Data
If your Looker Studio report already blends sources:
- Export the blended view
- Compare blended vs. individual source data
- Use Scoop for additional blending beyond Looker Studio's capabilities

### Snapshot for History
Looker Studio shows point-in-time data. Use Scoop's snapshots to:
- Track changes over time
- Compare current vs. historical performance
- Maintain audit trails

## When to Use Looker Studio vs. Scoop

| Use Looker Studio For | Use Scoop For |
|----------------------|---------------|
| Google-native dashboards | AI-powered investigation |
| Real-time Google data | Historical snapshots |
| Simple visualizations | Multi-source blending |
| Sharing with Google accounts | Ad-hoc analysis |
| Data Studio API integrations | Natural language queries |

## Troubleshooting

### Export Doesn't Include All Data
- Check table pagination settings
- Try exporting individual components separately
- Verify date range includes expected data

### Scheduled Emails Not Arriving
- Verify the Scoop ingest email address is correct
- Check spam/junk folders for the first delivery
- Ensure the schedule is set to your timezone

### Data Types Changed
- Looker Studio may format numbers as text in exports
- Scoop automatically detects and converts types
- Verify column types after import if needed

## Related Resources

- [Google Analytics Integration](google-analytics-4) - Import GA4 directly
- [Google Ads Integration](google-ads) - Import advertising data
- [Automated Snapshotting](../connect-your-data/automated-snapshotting-of-google-sheets-data)
- [Blending Datasets](../connect-your-data/blending-two-datasets)
