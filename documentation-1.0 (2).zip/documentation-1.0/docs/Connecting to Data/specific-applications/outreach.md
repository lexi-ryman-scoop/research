---
title: Outreach
excerpt: Import sales engagement data for pipeline and activity analysis
deprecated: false
hidden: false
metadata:
  title: Outreach Integration
  description: >-
    Import Outreach data into Scoop for sales engagement analysis. Combine
    sequence performance, activities, and prospects with your CRM data.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/58be7e896b7bea5c8aa4a6768a336929ae49718030652951cc643b01f544d558-outreach-logo.webp" />

## Overview

Outreach is a leading sales engagement platform that helps sales teams automate outreach, track activities, and manage prospects. Import your Outreach data into Scoop to analyze sequence performance, rep activity, and blend engagement data with your CRM and revenue data.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Sequence Performance** | "Which sequences have the highest reply rates?" |
| **Activity Metrics** | "How many touchpoints before conversion?" |
| **Rep Productivity** | "Compare email volume and quality by rep" |
| **Prospect Engagement** | "Which prospects have opened but not replied?" |
| **Pipeline Impact** | "What's our activity-to-opportunity ratio?" |
| **Timing Analysis** | "What send times get the best engagement?" |

## Importing Outreach Data

### Option 1: Export Reports from Outreach

1. In Outreach, navigate to **Analytics** or **Reports**
2. Select your report type (Team, Sequence, Individual)
3. Set your date range and filters
4. Click **Export** and choose CSV format
5. Upload to Scoop as a new dataset

### Option 2: Scheduled Email Reports

1. In Outreach, configure report scheduling
2. Add your Scoop ingest email address as a recipient
3. Select CSV format for attachments
4. Set your delivery frequency

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

### Option 3: API Export (Advanced)

For teams with Outreach API access:
1. Export data via Outreach's REST API
2. Save as CSV
3. Upload to Scoop or automate via script

## Key Reports to Import

### Team Activity Report
Track daily engagement across the team:
- Emails sent, opened, clicked, replied
- Calls made, connected, voicemails
- Tasks completed
- Meetings scheduled

### Sequence Performance Report
Analyze your automated sequences:
- Step-by-step conversion rates
- Reply rates by sequence
- Opt-out and bounce rates
- A/B test results

### Prospect Report
Understand your prospect pipeline:
- Prospect status and stage
- Last touch date
- Engagement score
- Account information

### Pipeline Report
Connect activities to revenue:
- Activities per opportunity
- Conversion rates by sequence
- Time-to-conversion metrics

## Blending with Other Data

| Source | Analysis Enabled |
|--------|------------------|
| **Salesforce/CRM** | Full pipeline attribution |
| **Marketing Automation** | Lead source to engagement analysis |
| **Revenue Data** | True ROI by sequence |
| **Conversation Intelligence** | Quality + quantity analysis |

### Example: Activity-to-Revenue Analysis

```
Ask Scoop:
"Show revenue generated per 1000 emails
by sequence and rep"
```

## Best Practices

### Export Consistently
- Daily exports for activity tracking
- Weekly exports for trend analysis
- Include all team members for benchmarking

### Include Key Identifiers
Ensure exports include:
- Prospect email address (for matching)
- Account name or ID
- Rep name or ID
- Sequence name

### Snapshot for Trending
Use Scoop's snapshot feature to track:
- Sequence performance over time
- Rep improvement trends
- Seasonal engagement patterns

## Common Use Cases

### Sequence Optimization
Find the best performing sequences:
> "Which sequences have the highest meeting conversion rate?"

### Rep Coaching
Identify coaching opportunities:
> "Show reps with below-average reply rates but above-average volume"

### Timing Analysis
Optimize send times:
> "What day and time combination gets the highest open rates?"

### Activity Benchmarking
Set and track standards:
> "Compare activities per rep to team average by week"

### Pipeline Attribution
Connect engagement to outcomes:
> "Average touchpoints before meeting booked by lead source"

## Outreach vs. Salesloft

Both are sales engagement platforms. Key differences:

| Feature | Outreach | Salesloft |
|---------|----------|-----------|
| Primary Focus | Enterprise sales | SMB to Enterprise |
| Sequences | Called "Sequences" | Called "Cadences" |
| Analytics | Detailed reports | Similar depth |
| Import Method | Export/Email | Export/Email |

See also: [Salesloft Integration](salesloft)

## Troubleshooting

### Report Doesn't Include All Reps
- Check your Outreach permissions
- Verify the date range includes all activity
- Ensure you have access to team-level reports

### Metrics Don't Match Outreach Dashboard
- Check time zones between systems
- Verify date ranges are identical
- Some metrics may be calculated differently (unique vs. total)

### Prospect Data Missing
- Ensure prospect export includes all required fields
- Check that prospects aren't filtered by status
- Verify API rate limits if using programmatic export

## Related Resources

- [Salesloft Integration](salesloft) - Alternative sales engagement platform
- [Salesforce Integration](salesforce) - Combine with CRM data
- [Gong Integration](gong) - Add conversation intelligence
- [Email Automated Imports](../connect-your-data/email-automated-imports)
