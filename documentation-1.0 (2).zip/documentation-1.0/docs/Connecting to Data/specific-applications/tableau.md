---
title: Tableau
excerpt: Import Tableau data into Scoop for AI-powered analysis
deprecated: false
hidden: false
metadata:
  title: Tableau Integration
  description: >-
    Import Tableau worksheets and dashboards into Scoop. Export as HTML or CSV,
    blend with other data sources, and add AI-powered natural language analysis.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/c616618cf36d2d83898534af9c293ef32cf43636964d5329bc34571d0721129b-Tableau.png" />

## Overview

Scoop imports Tableau worksheets and dashboards, preserving your carefully crafted logic while adding AI-powered analysis and data blending capabilities. Export from Tableau as HTML or CSV, and Scoop handles the rest.

## Why Tableau + Scoop?

- **Preserve Tableau investment** - Keep using dashboards you've built
- **Add AI analysis** - Ask questions about Tableau data in natural language
- **Blend with other sources** - Combine Tableau data with CRM, ERP, spreadsheets
- **Extend beyond visualization** - Get insights Tableau alone can't provide

## Connection Methods

### Method 1: HTML Export (Recommended)

Tableau exports worksheets as HTML with table structure preserved:

1. Open your Tableau worksheet
2. **Worksheet** > **Export** > **HTML**
3. Upload the HTML file to Scoop

Scoop automatically:
- Extracts all tables from the HTML
- Preserves column types and formatting
- Handles complex layouts

See [Importing HTML Reports](../connect-your-data/importing-html-reports) for detailed steps.

### Method 2: CSV Export

For clean tabular data:

1. Open your Tableau worksheet
2. **Worksheet** > **Export** > **Data**
3. Choose CSV format
4. Upload to Scoop

### Method 3: Tableau Server/Cloud Export

From Tableau Server or Cloud:

1. Navigate to your view
2. Click **Download** > **Data** or **Crosstab**
3. Choose CSV or Excel
4. Upload to Scoop

### Method 4: Email Automation

Automate recurring Tableau exports:

1. Set up Tableau Server subscriptions
2. Configure to email as attachment
3. Forward to your Scoop ingest address
4. Scoop processes automatically

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## What You Can Analyze

| Tableau Content | Best Export | Notes |
|-----------------|-------------|-------|
| Worksheets | HTML or CSV | Full data export |
| Dashboards | CSV (per sheet) | Export each sheet |
| Crosstabs | CSV | Tabular format |
| Data Extracts | CSV | Underlying data |
| Calculated Fields | Included | Values calculated |

## Best Practices

1. **Export underlying data** - Gets the full dataset, not just visible rows
2. **Use HTML for complex layouts** - Preserves table structure
3. **Use CSV for simple data** - Fastest processing
4. **Include headers** - Column names help Scoop
5. **Export from worksheets** - Not screenshots or images

## Common Use Cases

### Cross-Platform Analysis
Blend Tableau sales data with HubSpot marketing data in Scoop.

### Historical Snapshots
Import weekly Tableau exports to track changes over time.

### Executive Reporting
Combine Tableau visuals with AI-generated insights.

### Data Quality Checks
Use Scoop's AI to validate Tableau calculations against source data.

## Comparison: Tableau vs Scoop

| Capability | Tableau | Scoop |
|------------|---------|-------|
| **Visualization** | Excellent | Good |
| **Natural Language Query** | Limited | AI-native |
| **Data Blending** | Good | Excellent |
| **Ad-hoc Investigation** | Manual | AI-driven |
| **Snapshot Analysis** | Limited | Built-in |

**Best Together:** Use Tableau for visualization, Scoop for AI analysis and investigation.

## Troubleshooting

### Empty Export

**Problem:** HTML or CSV export is empty.

**Solution:** Ensure filters aren't excluding all data. Try removing filters before export.

### Missing Columns

**Problem:** Some columns not appearing in export.

**Solution:** Make sure columns are visible in the view. Hidden columns may not export.

### Calculated Field Issues

**Problem:** Calculated values missing or incorrect.

**Solution:** Calculated fields export as values, not formulas. Verify the source data.

## Related Resources

- [Importing HTML Reports](../connect-your-data/importing-html-reports)
- [Email Automated Imports](../connect-your-data/email-automated-imports)
- [Best Practices for Source Reports](../connect-your-data/best-practices-in-selecting-creating-source-reports)
