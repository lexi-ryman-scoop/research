---
title: Sprout Social
excerpt: Import social media analytics for cross-channel marketing insights
deprecated: false
hidden: false
metadata:
  title: Sprout Social Integration
  description: >-
    Import Sprout Social data into Scoop for social media analytics. Combine
    engagement metrics with other marketing channels for unified reporting.
  robots: index
---

<Image align="left" width="200px" src="https://files.readme.io/095f261106ba2072aba9921655f784746156c06c322351de7ee56f8dcc824c30-sprout-social-inc-logo-vector.png" />

## Overview

Sprout Social is a comprehensive social media management platform that provides publishing, engagement, and analytics across social channels. Import your Sprout Social data into Scoop to combine social metrics with other marketing data sources for unified cross-channel analysis.

## What You Can Analyze

| Data Type | Example Questions |
|-----------|-------------------|
| **Engagement** | "Which content types drive the most engagement?" |
| **Reach** | "How has our audience reach grown month-over-month?" |
| **Cross-Channel** | "Compare social engagement to email and web traffic" |
| **Publishing** | "What posting times get the best engagement?" |
| **Sentiment** | "Track brand sentiment trends over time" |
| **Team Performance** | "Response time by team member" |

## Importing Sprout Social Data

### Option 1: Export Reports

1. In Sprout Social, navigate to **Reports**
2. Select your report type (Profile, Post, Tag, etc.)
3. Set your date range and profiles
4. Click **Export** → CSV or Excel
5. Upload to Scoop as a new dataset

### Option 2: Scheduled Report Emails

1. In Sprout Social Reports, click **Schedule**
2. Set the delivery frequency (daily, weekly, monthly)
3. Add your Scoop ingest email address
4. Select CSV attachment format

See [Email Automated Imports](../connect-your-data/email-automated-imports) for setup.

## Key Reports to Import

### Profile Performance Report
Overall social presence metrics:
- Impressions and reach
- Engagements (likes, comments, shares)
- Follower growth
- Post frequency

### Post Performance Report
Individual content analysis:
- Post text and type (image, video, link)
- Engagement metrics per post
- Publishing time
- Platform breakdown

### Engagement Report
Interaction analysis:
- Messages received and sent
- Response time
- Engagement by type
- Sentiment analysis

### Tag Performance Report
Campaign tracking:
- Performance by tag/campaign
- Content category effectiveness
- Hashtag performance

### Team Performance Report
For teams using Sprout for publishing:
- Posts by team member
- Average response time
- Engagement by author

## Available Metrics

| Category | Metrics |
|----------|---------|
| **Reach** | Impressions, Reach, Audience Growth |
| **Engagement** | Likes, Comments, Shares, Clicks, Saves |
| **Video** | Views, Watch Time, Completion Rate |
| **Publishing** | Posts Published, Post Types, Best Times |
| **Community** | Followers, Following, Messages |
| **Sentiment** | Positive, Neutral, Negative sentiment |

## Blending with Other Marketing Data

Social media data is most powerful when combined:

| Source | Analysis Enabled |
|--------|------------------|
| **Google Analytics** | Social traffic to conversion analysis |
| **Meta Ads** | Paid vs. organic social comparison |
| **HubSpot/CRM** | Social engagement to leads |
| **Email Marketing** | Cross-channel campaign performance |
| **Revenue Data** | Social media ROI attribution |

### Example: Cross-Channel Analysis

```
Ask Scoop:
"Compare cost per engagement across
Facebook organic, Facebook paid, and Instagram"
```

## Best Practices

### Export Consistently
- Weekly exports for trend analysis
- Daily exports if tracking real-time campaigns
- Include all managed profiles

### Use Tags for Campaigns
Leverage Sprout's tagging for:
- Campaign tracking
- Content category analysis
- A/B test grouping

### Include All Platforms
Export data for all social platforms:
- Facebook (organic and paid)
- Instagram
- Twitter/X
- LinkedIn
- Pinterest
- TikTok

## Common Use Cases

### Content Strategy
Find what resonates:
> "Which content types have the highest engagement rate by platform?"

### Posting Optimization
Identify best times:
> "Show average engagement by day of week and hour"

### Campaign Analysis
Track campaign performance:
> "Compare engagement rates across our Q4 campaigns"

### Platform Comparison
Benchmark platforms:
> "Which platform has the best reach-to-engagement ratio?"

### Growth Tracking
Monitor audience growth:
> "Show follower growth rate by platform over the last 6 months"

### Team Performance
Track team output:
> "Average response time to messages by team member"

## Social Media vs. Other Marketing

Understanding where social fits:

| Metric | Social Strength | Limitation |
|--------|-----------------|------------|
| Engagement | Direct measurement | Not revenue |
| Reach | Brand awareness | Quality varies |
| Sentiment | Real-time feedback | Sample bias |
| Cost | Low per impression | Attribution hard |

Use Scoop to connect social metrics to business outcomes by blending with revenue and conversion data.

## Troubleshooting

### Metrics Don't Match Sprout Dashboard
- Check date ranges are identical
- Verify timezone settings
- Some dashboard metrics may be aggregated differently

### Missing Platform Data
- Ensure all profiles are included in the report
- Check that platform is connected in Sprout
- Verify API permissions haven't expired

### Engagement Counts Off
- Sprout may count total vs. unique differently
- Check metric definitions in your export
- Organic vs. paid engagement may be separate

## Related Resources

- [Meta (Facebook) Analytics](meta-facebook-analytics) - Facebook/Instagram direct
- [LinkedIn Integration](linkedin) - B2B social analytics
- [Google Analytics](google-analytics-4) - Web traffic analysis
- [Blending Datasets](../connect-your-data/blending-two-datasets) - Combine with other sources
- [Email Automated Imports](../connect-your-data/email-automated-imports)
