---
title: Hubspot
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: HubSpot Integration
  description: >-
    Scoop allows users to extract, analyze, and enhance HubSpot data, combining
    it with other data sources for advanced insights, and supports writing back
    enriched data to HubSpot.
  robots: index
next:
  description: ''
---
<Image align="left" width="200px" src="https://files.readme.io/6c02b95-image.png" />

Scoop is able to grab any report data from HubSpot. To do this, use the HubSpot application option in Application Report option when creating a new dataset. 

# Typical HubSpot Use Cases with HubSpot Only

Typical use cases for Scoop with HubSpot data only include:

* General HubSpot reporting with better visuals and analysis
* Weekly forecasting or pipeline views that leverage snapshotting to review changes
* Snapshotting any/all attributes on any HubSpot object like Opportunities or Leads
* Analyzing sales and/or marketing processes to understand conversion rates and cycle times
* Combining HubSpot marketing lead data with HubSpot sales data to understand the full lifecycle and process for a customer from raw lead to closed deal.
  * Conversion rates
  * Cycle times
  * Channel efficiency

# HubSpot Instant Recipes

Scoop has several instant recipes created for HubSpot to get you started quickly. The recipes are pipeline waterfall, sales operations, sales team performance, and deal distribution. 

* Pipeline waterfall: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales operations: Gain powerful insights into every shift in your sales pipeline with advanced waterfall analysis. Track what’s been added, removed, won, lost, or resized across your entire pipeline, broken down by individual deal owner and deal type. Dive deeper into specific deals to take immediate action and drive results
* Sales team performance: Access real-time sales metrics like pipeline performance, deal velocity, and forecasting directly from HubSpot. This recipe consolidates key data to offer immediate insights, helping you track trends and optimize your sales operations​
* Deal distribution: Understand which types of deals are being done and who is doing them. With deal distribution analysis you can see at a glance where your business is coming from​

# HubSpot Snapshotting

One of the biggest uses of Scoop for HubSpot is snapshotting. Scoop can snapshot your deals automatically. This allows for critical analysis of fundamental sales processes by understanding how things change in a sales process and why. Scoop allows HubSpot users to snapshot their deals and detect, track and report on all changes, how fast those changes occur and at what rates - allowing deep insights into the sales process.

# Typical Use Cases Combining HubSpot with other Applications

Combining HubSpot data with other types of data opens up very powerful analysis options that can really help a marketer optimize their performance. While HubSpot allows some limited ability to bring in some outside sources, like basic financial data, the integration is much more complex and the data and analysis options are limited. Scoop opens up tremendously rich opportunities to slice and dice HubSpot data in conjunction with data from other applications.

## Uncaptured Audience or Channel Data

Because Scoop can easily handle spreadsheets, lookup tables that augment attributes for your campaign are very easy to add. It's exceptionally easy and painless to augment your marketing data with key attributes that likely are either anecdotal or captured in some sort of ad hoc way. Scoop makes it extraordinarily simple to include this data by maintaining it in a spreadsheet and being able to join that spreadsheet to your other marketing data.

## Financial Expense Data

Financial applications such as NetSuite, QuickBooks or other accounting applications can bring in expense data very easily into Scoop. This enables some powerful analysis:

* Dollar cost efficiency of marketing efforts: This analysis allows you to assess by campaign, audience, channel, message, etc. the efficiency of dollars in to dollars out of closed won deals. This use case combines snapshot lead data, snapshot sales data and financial expense data for marketing campaigns.
* Customer acquisition cost
* Cost per lead analysis

## Service Data

To understand better what audiences might be more expensive to serve, Scoop allows you to blend your marketing or sales data with data from your service desk (e.g. Zendesk)

## Product Usage Data

Understand the usage patterns of your customers based on their marketing segmentation.

## Engineering Data

Understand what types of customers cost the most in terms of engineering time by integrating with a tool like Jira.

# Connecting to HubSpot

To connect to HubSpot as a data source, create a new dataset linked to HubSpot. First, on the datasets page, select applications as a source:

<Image align="center" width="300px" src="https://files.readme.io/7a41aa7-image.png" />

Next, select HubSpot:

<Image align="center" width="300px" src="https://files.readme.io/d32794f-image.png" />

Select API Data Source:

<Image align="center" width="300px" src="https://files.readme.io/d6d3fc7-image.png" />

Select whether you are selecting an object that you want to snapshot daily, or an object which is transactional (e.g. an activities object).

<Image align="center" width="300px" src="https://files.readme.io/c84d085-image.png" />

After connecting to HubSpot to Scoop, select the object that you wish to extract, and the columns that you wish to extract.

<Image align="center" width="300px" src="https://files.readme.io/6cb4596-image.png" />

Also, select a dataset name. If you like, certain columns support filtering and you can filter them for specific values. After you save this dialog, you can elect to have Scoop run an immediate extract (by checking the extract data now button). Scoop will automatically run this extract overnight each day after you set this up.

# Writing back to HubSpot from a Scoop dataset

With Scoop you can blend data with other datasets and create new fields with ease. Scoop's ability to use spreadsheet logic gives you that same spreadsheet flexibility to add arbitrary and powerful calculations to your dataset. It is often useful to then bring those sophisticated calculations back into your source application. Scoop's API Writeback feature allows you to take any Scoop dataset and write values back into your HubSpot application. This means that you can extract data from HubSpot (which is necessary to extract the HubSpot record ID which is required to write back into HubSpot), blend it with other data or create new calculations and then push those back into your HubSpot application.

In order to write back into HubSpot, you must first establish an API connection to HubSpot and extract records that you wish to augment (see above). The Record ID will be part of your extracted dataset. You can either create calculated columns with that dataset, or you can blend that dataset with others in Scoop to create a new dataset. Be sure to make sure that the Record ID stays with your records as you blend them together (i.e. always select that column when building a new blended dataset).

Once that is done, you can now update HubSpot whenever your dataset in question is processed. When that connection is established, the following option becomes available on the dataset menu:

<Image align="center" width="300px" src="https://files.readme.io/04a04ab-image.png" />

You can select "Setup Application Writeback" to create a writeback definition for Scoop. This definition tells Scoop what to do each time that dataset is processed. When processing is done, it will use that dataset and take the fields that you map and write them back to HubSpot using the Record IDs that you initially extracted.

<Image align="center" width="400px" src="https://files.readme.io/3b94bc6-image.png" />

The definition essentially allows you to pick fields from one table within your dataset and map those back to fields within HubSpot. 

<Image align="center" width="400px" src="https://files.readme.io/244a1d5-image.png" />

So if, for example, you wanted to map a single column in HubSpot to a Scoop dataset, you simply select from the dropdown which Scoop dataset column you want to use. Once that is done, each time that dataset is processed, Scoop will update HubSpot to ensure that that field will contain the value calculated in Scoop.
