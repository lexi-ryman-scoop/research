---
title: Upload a File or Spreadsheet
deprecated: false
hidden: false
metadata:
  robots: index
---
Uploading files into Scoop Analytics is the fastest way to get started exploring your data. Whether your information is stored in CSV, Excel, or a similar spreadsheet format, Scoop makes it easy to preview, clean, and ingest data right from your browser—no technical skills required!

## 1. Drag-and-Drop File Upload

Simply open the **Datasets** page and click the **New Dataset** button. You'll see the option to upload a file. To begin:

1. **Drag and drop** your file (CSV, XLS, or XLSX) into the upload area, or use the **Browse** button to select it from your computer.
2. Scoop will automatically scan your file and display a preview of your data, highlighting rows and column headers as it detects them.

<Image align="center" width="300px" src="https://files.readme.io/55b0539e0c38f49900537a686d35b88893bd9524aebf79915d009cd63b1c2d22-image.png" />

**Tip:** You can upload spreadsheets up to 50 MB. If your file is larger, consider splitting it first.

> **Tip:** If Scoop highlights a date column in orange, it may be ambiguous. Click the column type dropdown and pick the right format.

## 2. Confirm and Import

Once your preview looks correct:

1. Give your dataset a **clear name** that you'll recognize later.
2. Click **Confirm Upload**. Scoop will process your file, scan for issues, and load all valid rows.
3. You'll be taken to the data explorer, where you can start analyzing or transforming your new dataset right away.

## 3) Advanced Tips

* **Large Files:** Files up to 50 MB or 200,000 rows are typically supported. For larger datasets, remove unused columns or split into smaller files.
* **Date Parsing:** Scoop scans every date column for regional format differences.
* **Multiple Sheets:** Import only the tabs (sheets) you need. If your workbook contains summary or chart sheets, ignore those and focus on raw data tabs.
* **Special Characters:** Non-ASCII (e.g., emojis, special symbols) are supported, but check your headers and sample rows for clean display.

> **Tip:** Files exported from third-party tools (e.g., financial systems) sometimes include trailing notes or hidden rows. In preview, scroll through the bottom rows to ensure only data is imported.

## 4. Common Troubleshooting

* **File Won’t Upload:**
  * Check file size (max 50 MB for browser upload).
  * Ensure file extension is .csv, .xls, or .xlsx.
  * Remove any unusual file encryption or password protection.
* **Wrong Header Row Detected:**
  * Use the preview option to pick the correct header row.
* **Garbled Characters:**
  * Re-save your CSV with UTF-8 encoding.
* **Date Columns Not Detected:**
  * Double-check for mixed date formats or extra spaces before/after dates.
* **Blank Rows/Columns Imported:**
  * Uncheck unnecessary or empty columns in preview, and skip entirely blank rows.
* **Multi-Sheet Workbook Not Supported:**
  * If you don't see all your tabs, save each sheet as a separate file and upload one at a time.

If you ever get stuck, check the [Scoop Quickstart Guide](https://docs.scoopanalytics.com/docs/scoop-quickstart-guide) or contact support through the in-app help.

***

With Scoop’s upload and smart preview, your spreadsheet data is ready for instant analytics—with zero technical setup.