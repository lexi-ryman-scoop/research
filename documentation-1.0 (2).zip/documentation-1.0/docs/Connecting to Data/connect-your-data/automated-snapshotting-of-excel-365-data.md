---
title: Automated Snapshotting of Excel 365 Data
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Automated Snapshotting of Excel 365 Data
  description: >-
    Scoop allows users to connect to Microsoft Office 365 Excel to extract data
    from sheets or named ranges, enabling effective use of Excel as a database
    for time series analysis and change analysis.
  robots: index
next:
  description: ''
---
Scoop Analytics empowers business users to unlock rapid, repeatable insights from Excel 365 files stored on OneDrive and SharePoint. With Scoop, you can easily connect to Excel workbooks—whether personal or on a shared drive—automate data snapshotting, and analyze changes over time, all without writing a single line of code.

## Why Automate Snapshots from Excel 365?

Many organizations store critical operational and analytical data in Excel files on OneDrive or SharePoint. By connecting these files to Scoop, you can:

- **Automate daily or periodic data collection**: No more manual exports or version confusion.
- **Historically track and analyze changes**: Understand what changed in your data over any time window.
- **Enable powerful time series analysis and trend detection**: Reveal insights you wouldn’t see in a simple static sheet.

## How Scoop Connects to Your Excel 365 Files

Scoop connects directly to Excel 365 workbooks via Microsoft’s secure API, supporting both OneDrive (personal & business) and SharePoint shared drives. You can extract:

- All data from an entire worksheet (tab)
- Data from a named range for more focused analysis

### Step-by-Step: Connecting an Excel File

1. **Navigate to Data Sources** in the Scoop UI and select "Add New Source."
2. Choose **Microsoft Excel 365** as the source type.
3. **Authorize your account**: Scoop will prompt you to log in with your Microsoft credentials. All authentication is handled securely using Microsoft’s official OAuth.
4. **Pick your file**:
    - Browse your OneDrive or shared folders.
    - Locate the Excel workbook to connect.
5. **Select a worksheet or named range** for extraction.
    - You can snapshot a whole sheet or just the area you care about.

> **Tip:** For large workbooks, use named ranges to limit what Scoop loads and speed up snapshots.

## Automating Snapshots and Scheduling
Once set up, Scoop will automatically extract a fresh snapshot of your Excel data on your chosen schedule (e.g., daily, weekly). Each snapshot:

- Captures a full copy of the relevant sheet/range
- Stores it as a new version in your secure Scoop workspace
- Enables detailed comparison between any two points in time

> **Tip:** By default, Scoop snapshots are retained indefinitely, so you always have a historical record of every change.

## Working with Shared Drives & Permissions

- **Personal vs. Shared Files:** You can connect to Excel files in your own OneDrive, or from SharePoint shared drives and shared folders with colleagues.
- **Permissions:** To access a file, your Microsoft account must have at least View permission. For shared files:
    - Ensure you are granted direct access ➔ in SharePoint/OneDrive, verify you are listed as a recipient or are part of the relevant team.
    - If automation fails, check with your IT admin for organization-level sharing restrictions or multifactor requirements.

> **Tip:** Files on shared drives often have organization-wide access settings. If you’re having trouble connecting, ask the file owner to share the file directly with your user email, or check with your Microsoft 365 admin.

## Using Excel Files as Live Databases

Scoop treats your chosen worksheet or named range as a database table. Once data is ingested, you can:

- Build dashboards and visualizations
- Run time series analysis (e.g., see growth or change by week/month)
- Automatically generate before-vs-after change reports
- Compare current vs. historical values for audit or reporting

> **Tip:** Scoop adds snapshotting and historical context to Excel files in a way not possible within Excel alone. Your source file remains editable and collaborative—Scoop simply records its state at every sync for later analysis.

## Downloading Historical Snapshots

Every snapshot Scoop takes is retained (unless deleted by a workspace admin). You can download any snapshot at any time for reconciliation or backup.

1. Go to your connected Excel data source
2. View the list of snapshots (time-stamped, one per extraction)
3. Download the one you need as an Excel file for local inspection

## Next Steps: Making the Most of Your Excel Data

Once your Excel 365 data is being automatically snapshotted:

- **Transform it using Scoop’s spreadsheet-style tools**: Blend with other sources, make calculations, or define business logic.
- **Set up visualizations and reports**: Slice by time, category, or business metric.
- **Leverage Scoop’s change analysis and process tracking**: See what’s changed or why, historically.

With Scoop, Excel files aren’t just static spreadsheets—they become dynamic, enriched datasets ready for deep business analysis. Get started in just a few minutes, and unlock the real story behind your numbers.
