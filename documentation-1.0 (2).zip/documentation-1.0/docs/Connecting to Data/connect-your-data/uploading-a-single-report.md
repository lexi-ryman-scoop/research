---
title: Uploading a Single Report
deprecated: false
hidden: false
metadata:
  robots: index
---
If you've just exported a CSV, Excel, or PDF report from your SaaS tool and want quick, actionable insights—you're in the right place. Scoop Analytics makes it easy for anyone, even without technical expertise, to upload a single data file and start exploring immediately. This guide walks you step-by-step through the process and shares practical tips for a smooth experience, from file preparation to your first discoveries.

---

## Step 1: Start a New Dataset

From the Scoop dashboard, click the **New Dataset** button. Select **Data File** when prompted. This opens a simple upload dialog where you'll add your source report.

> **Tip:** If your data updates regularly, consider setting up an automated integration later. For now, a single upload is perfect for quick analyses or testing.

---

## Step 2: Choose and Upload Your File

You can either drag and drop your file into Scoop or click to open a file selector window. Scoop supports a wide range of formats: CSV, Excel (xlsx), delimited text (txt), HTML tables, ZIP files containing tabular data, and more. 

**Supported Formats:**
- CSV, TSV, pipe- or tab-delimited files
- Excel spreadsheets (.xlsx)
- HTML tables
- ZIP files containing any of the above
- PDF (extracts table data if possible)

### Common File Issues & Solutions
- **Delimiter Problems:** Scoop automatically scans your file to detect commas, tabs, semicolons, or pipes as delimiters, so you don’t need to worry about guessing. Rare cases (like files with inconsistent delimiters) may need cleanup first.
- **Encoding Issues:** Most modern exports use UTF-8, which Scoop handles by default. If you see strange characters (� or incorrect symbols), try re-saving your file using UTF-8 encoding in Excel, Numbers, or Google Sheets.
- **Merged Headers & Subtotals:** Scoop scans for extra header rows, footer notes, subtotals, and other noise, stripping them out so you start with clean rows and columns.
- **Special Characters:** Scoop supports files with international/Unicode characters, accents, and emojis—but double-check your data preview screen to confirm everything imported as expected.

---

## Step 3: Name and Describe Your Dataset

Enter a meaningful name for your dataset—something that matches the report’s purpose or time period (e.g., "Q2 Marketing Leads" or "May 2024 Sales Pipeline"). Optionally, add a longer description to clarify details about the report source or content.

> **Tip:** You can always add more files to the same dataset later (e.g., uploading last quarter’s data next month).

---

## Step 4: Upload and Let Scoop Analyze

Click the **Upload** button. Behind the scenes, Scoop will:
- **Scan your file structure,** detecting columns, data types, dates, and possible totals or notes.
- **Identify field types** (number, text, date, currency, etc.).
- **Handle row-by-row cleanup,** removing empty rows or columns and deduplicating if needed.
- **Extract any embedded dates** for time-based analysis.

You’ll see a success message when your data is loaded. Within seconds, you're ready to start working with your new dataset.

---

## Step 5: Your First Insights – Getting Started

After upload, Scoop generates a semantic profile of your data. It automatically:
- “Understands” what each column means, highlights probable ID fields, categories, dates, and key metrics.
- Calculates summary statistics (e.g., top values, min/max, averages) for each column.
- Surfaces instant questions and suggested visualizations to get you exploring right away.

**Try these quick actions:**
- Click a column header for a preview distribution or breakdown.
- Use the "Explorer" feature to instantly create charts, tables, or KPIs—no formulas required.
- Ask natural language questions (e.g., "Show total revenue by month" or "Which region closed the most deals?").

> **Tip:** Scoop will recommend fields to visualize and even suggest calculated columns (like buckets/ranges for ages or sales amounts)—great for making sense of unfamiliar exports.

---

## Troubleshooting & Best Practices

- **File not recognized/loads incorrectly?** Double-check your source file for hidden columns, blank rows at the top, or strange header formatting. Sometimes re-saving your export as CSV (with UTF-8 encoding) solves tricky issues.
- **Data looks wrong?** Use Scoop’s data preview and cleaning features. You can always re-upload a fixed file or add another version to your dataset.
- **Complex PDFs:** If your data is buried in non-tabular PDF layouts (multi-row headers, page breaks), try exporting as Excel/CSV from your source system if possible, as this usually gives the cleanest result.

---

## Beyond Single Uploads: Automation & Repeatability

One-off uploads are fast—but if you find yourself exporting the same report each week or month, Scoop can fully automate the process. For example:
- **Email Integration:** Scoop can auto-ingest emailed reports from apps that support scheduled exports. Just forward the report to your Scoop-generated inbox. 
- **API Connectors:** Scoop links to over 100 SaaS APIs for seamless, scheduled sync with Salesforce, Hubspot, NetSuite, Zendesk, and more.

> **Tip:** Start with a manual upload to explore Scoop, then scale up to automation as you see value!

---

## Recap

Uploading a single report to Scoop is just a few clicks: choose your file, name it, upload, and start analyzing right away. Scoop takes care of delimiter headaches, sniffing out encoding or data type issues, and even suggests the first set of insights. Whether you’re answering one question or evaluating Scoop for bigger projects, you’ll be up and running in minutes.

---

Need help? Reach out to Scoop support anytime—and happy exploring!