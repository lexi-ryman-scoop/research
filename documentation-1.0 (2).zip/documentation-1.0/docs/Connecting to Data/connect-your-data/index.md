---
title: Connect Your Data
deprecated: false
hidden: false
metadata:
  robots: index
---
Welcome to **Scoop Analytics**! Before you can explore insights, visualize trends, or build presentations, you'll want to connect and upload your data. Scoop supports a wide variety of data ingestion methods designed to get your information in quickly, cleanly, and with minimal hassle—no technical background required.

## Ways to Bring Data into Scoop

Scoop lets you connect almost any business data source, from simple spreadsheets to live feeds from cloud services. Below is a quick summary of each supported path, and how to choose which one fits your needs:

- **File Upload:** Fastest way to bring in standalone data—csv, XLSX, tab-delimited, or exported reports.
- **API Connectors:** Set up scheduled, automatic data pulls from over 100 SaaS and cloud apps (like Salesforce, HubSpot, Google Sheets, and more).
- **Database Connections:** Link to SQL databases securely for ongoing or on-demand imports.
- **Other Sources:** Advanced paths for PDF, HTML, custom integrations.

No matter how you start, Scoop will scan your data, auto-detect formats, suggest schema, and recommend additional steps if clean-up or transformation is needed. Let's dive into the options:

## Which Ingest Method Should I Choose?

Use this table to pick the path that fits your data type, update needs, and experience level:

| Your goal or data type                          | Recommended Method     | When to use this                                                      |
|------------------------------------------------|-----------------------|----------------------------------------------------------------------|
| Upload a one-off spreadsheet or report          | **File Upload**       | For CSV, Excel, or tab-delimited files. Quickest for one-time loads.   |
| Keep dashboards current with SaaS/cloud apps    | **API Connectors**    | For live data, regular refreshes, or recurring updates.               |
| Periodically import new rows from a database    | **Database Connection**| For custom data warehouses or internal SQL/Cloud DBs.                 |
| Extract table data from PDFs or HTML reports    | **Other Sources**     | When you have legacy reports or web data and need conversion.         |

> **Tip:** Scoop can handle both structured and semi-structured data. If your data source is new or unusual, start with File Upload—you'll receive specific guidance for next steps.

## Quick Links to Detailed Guides

- [Uploading Files](uploading-files.md):
    Step-by-step for CSV, Excel, tsv, and more.
- [Connecting SaaS API Sources](connect-saas-api.md):
    Comprehensive walkthrough for connecting Salesforce, QuickBooks, Google Analytics, etc. - 
[Database Connections](database-connections.md):
    How to link to SQL/Cloud databases securely. 
- [Other Data Sources](other-sources.md):
    Importing data from PDF, HTML, Zapier, and advanced integrations.

## What Happens Next?

Once your data is connected, Scoop automatically:
- Scans your data structure: columns, types, dates, hierarchies
- Checks for subtotals/totals and hidden rows
- Suggests data prep steps if needed (all with spreadsheet-like logic)
- Lets you preview and transform data before it’s imported

You'll see instant feedback if any values are ambiguous, and can always adjust mappings and types with just a few clicks.

> **Tip:** Not sure how to prep your data for analysis? Scoop uses built-in AI to recommend transformations, groupings, and even flags potential issues automatically.

---

You’re just a few clicks from actionable analytics. [Choose your method](#which-ingest-method-should-i-choose), follow the linked guide, and start discovering insights in minutes!