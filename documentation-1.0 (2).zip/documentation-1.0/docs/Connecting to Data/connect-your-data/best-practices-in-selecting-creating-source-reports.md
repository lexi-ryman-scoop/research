---
title: Best Practices in Selecting & Creating Source Reports
deprecated: false
hidden: false
metadata:
  robots: index
---
Designing clean, well-structured reports up front makes all the difference for fast, accurate, and pain-free analytics in Scoop. As a business or data analyst, following these best practices will ensure your exported files are immediately ready for upload, automatic parsing, and advanced analysis, with zero cleanup or manual fixes needed.

## Why Source Report Structure Matters

When you upload a report to Scoop, our intelligent engine scans and interprets every row and column — inferring data types, finding totals, and managing complex formats for you. But the quality of that automation (and of the analytics you can run) depends on how predictable and unambiguous your exported data is. Clean design up front means:

- No rows or columns missed
- Instant snapshotting and change tracking
- Correct calculation of metrics (sum, count, average)
- Seamless charting, visualization, and ML analysis

> **Tip:** Even if you only plan to load a file once, investing in a good report layout now avoids surprises later — especially if you automate daily or weekly snapshots for tracking trends.

## Key Design Rules for Building Scoop-Ready Reports

### 1. Include a Unique Identifier
Each row should represent a single business entity (like a deal, lead, case, or ticket) and have a column with a unique, stable ID (such as an Opportunity ID or Ticket Number). This ID enables Scoop to compare entity history across time and track changes.

- If possible, use system-generated unique IDs (not just names or descriptions).
- Never reuse or recycle IDs for different entities.

### 2. Add Timestamps or Date Columns
Include at least one date or timestamp column indicating when an action occurred (e.g., Created Date, Close Date, Status Change Date).

- These are essential for time-series analysis, trend tracking, and period comparisons.
- For recurring or status-based entities, include multiple date columns if available (e.g., both Created and Closed dates).

### 3. Avoid Subtotals, Totals, or Merged Header Rows
Format your exported file so that each row is a single data record:

- Remove summary rows (subtotals, grand totals, etc.).
- Do not merge cells, split data across extra header rows, or include report titles in the data grid.
- Place column headers in the **first row** only.

> **Tip:** If your system insists on adding totals, try exporting in raw data or table mode, or delete those lines before uploading to Scoop.

### 4. Use Clear, Stable Column Names
Name columns clearly and avoid duplicating names.

- Prefer names like `OpportunityID`, `CloseDate`, `Stage`, `Owner`, `Amount`.
- Don’t use vague names (like 'Column1'), or repeat the same label for different data.
- Ensure column names won't change over time — consistency allows automated parsing.

### 5. Prefer One Row Per Entity Per Date
For snapshot tracking, design reports where each row equals one entity as it existed on the export date. This makes it simple to analyze changes and status over time.

### 6. Choose the Right Export Format
CSV, Excel (XLSX), and unadorned HTML table exports work best. Avoid PDFs or image-based exports, as these are harder to parse programmatically.

### 7. Keep Data Types Consistent
Stick to the same data type in each column:

- Dates always as dates
- Amount fields as numbers — no currency symbols or mixed text
- IDs as text (never store as numbers if they can contain leading zeros)

### 8. Reduce Manual Edits
Automate your report export processes where possible, so every file is predictably formatted — minimizing manual tweaks or accidental data changes.

> **Tip:** In tools like Salesforce, Hubspot, or ServiceNow, set a recurring report schedule (daily or weekly) and email the files directly to your Scoop workspace for fully automated ingestion.

## Report Checklist: Ready-to-Upload Criteria

| Criteria                                         | Description/Example                                 | Required/Recommended |
|--------------------------------------------------|-----------------------------------------------------|----------------------|
| Unique ID column                                 | `OpportunityID` or `TicketNumber`                   | Required             |
| At least one Date or Timestamp column            | `CreatedDate`, `ClosedDate`, `StatusChangeDate`     | Required             |
| Clear, unchanging column headers (row 1)         | No duplicates, easy to interpret                    | Required             |
| No total/subtotal or non-data rows               | Raw data only, no sums or group summaries           | Required             |
| One row = one entity snapshot                    | Each row reflects a unique item on that day         | Required             |
| Standard export format (CSV, XLSX, HTML table)   | No PDFs, images, or prints                          | Required             |
| Consistent data types per column                 | No mixed text/numbers, correct date fields          | Required             |
| No merged cells, multi-line headers, or titles   | Data grid starts at row 1, column 1                 | Recommended          |
| Descriptive but concise column naming            | `Amount`, `SalesRep`, `ProductName`                 | Recommended          |
| Automated or scriptable export                   | Scheduled email, SFTP, or API                       | Recommended          |

## What a Good Source Report Looks Like

A best-practice source report will open directly in Scoop, be recognized instantly, and enable automatic profile and analysis. You’ll see every column typed correctly (dates, numbers, IDs, categories), and enjoy instant access to summary profiles, automated transformations, and trend detection — all without any manual corrections.

For more help:

- See [Connecting to a Business Application](doc:connecting-to-a-business-application) for automating daily report loads
- Explore [Understanding Snapshots & Concepts](doc:concepts) for details on how Scoop tracks entity changes over time.

> **Tip:** Reviewing the data after first upload in Scoop is a great way to spot minor fixes (like data types or extra header rows) that prevent future issues once your report is automated.

Apply these practices, and you’ll set up your team for reliable, future-proof analytics!