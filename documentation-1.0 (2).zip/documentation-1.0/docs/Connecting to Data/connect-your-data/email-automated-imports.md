---
title: Email & Automated Imports
deprecated: false
hidden: false
metadata:
  robots: index
---
Boost your analytic agility by letting Scoop automatically collect data from emails and attachments — without any IT help or complex integrations! With Scoop’s Email & Automated Imports feature, you can securely forward, filter, and capture data files from your inbox straight into datasets, turning recurring reports and auto-generated files into live, analysis-ready information in minutes.

## How Does Scoop’s Email Ingestion Work?
Scoop provides a unique, secure email ingest address (e.g., `yourteam@ingest.scoopanalytics.com`). Once you configure your data sources — CRM exports, financial system reports, vendor files, scheduled emails, etc. — to send data to this address, Scoop monitors every incoming message, automatically parsing attached files and turning them into new or updated datasets.

### Supported Attachment Types

| Format | Extension | Notes |
|--------|-----------|-------|
| Excel | .xlsx, .xls | Multi-sheet support, formula evaluation |
| CSV/TSV | .csv, .tsv, .txt | Standard delimited files |
| HTML | .html, .htm | Tables extracted from HTML body or attachments |
| PDF | .pdf | Table extraction with capture configuration |
| ZIP | .zip | Automatically extracts and processes CSV files inside |
| JSON | .json | JSONPath-based field mapping |

**Bonus:** Scoop can also extract tables directly from the **HTML email body** - perfect for BI tools that embed reports inline rather than as attachments.

You'll never have to hunt for files, copy-paste, or chase down IT again: Scoop automates data collection and transforms recurring inbox clutter into up-to-date, blended dashboards.

---

## Step 1: Configure Subject & Attachment Filters

Scoop lets you fine-tune exactly **which emails and attachments** are imported by setting up filters on:

### Email Subject
- Use keywords or exact matches to include/exclude specific recurring reports (e.g., “Monthly Sales Report”, “Export - QuickBooks”).
- This keeps Scoop from pulling in unrelated emails or accidental misdirected messages.

### Attachment Types
- Limit imports to certain file types or attachment names. For instance, you may want only files named like `sales-export-*.csv` or restrict to `.xlsx` files.
- You can also ignore emails without attachments, or only import attachments and skip email bodies.

### Common Use Cases
- Forward all Salesforce scheduled reports automatically.
- Capture daily QuickBooks or Xero financial reports.
- Aggregate ad platform exports (Google Ads, Facebook Ads).
- Collect regular vendor statements, invoices, or service logs.

> **Tip:** Setting clear subject or filename patterns is the best way to prevent duplicates and ensure you're only ingesting trusted data.

### Override the Data Date with SCOOP_DATE()

By default, Scoop uses the email's sent date as the data timestamp. You can override this by including a `SCOOP_DATE()` command in the subject line:

```
Weekly Sales Report SCOOP_DATE(2024-01-15)
```

Or with flexible date formats:
```
Monthly Summary SCOOP_DATE(January 15, 2024)
```

This is useful when:
- The report covers a different date than when it was sent
- You're backfilling historical data
- You want precise control over snapshot dates

---

## Step 2: Parsing Attachments & Mapping Data

Once Scoop receives a matching email, it:
1. **Scans all attachments** for supported report/file types.
2. **Automatically parses file structure** — extracting tables, headers, types, and values.
3. **Creates a new dataset or updates an existing one**, based on your import settings.
4. **Shows a preview** so you can validate the data and adjust field mapping if needed.

You can set Scoop to import files as they arrive, or review and approve each one before adding to your workspace.

> **Tip:** If your attachment contains multiple tabs or tables, Scoop will let you select which ones to use and how to map columns. You can also merge with other imported data for multi-source reporting.

---

## Step 3: Confirmation Emails

On successful first-time ingestion, Scoop sends a confirmation email back to the sender with:

- **Row count** - How many rows were imported
- **Column count** - How many columns were detected
- **Unique key detection** - Whether Scoop identified a unique identifier
- **Status indicator** - Success (green), Warning (yellow), or Error (red)

This feedback loop helps you verify that your email automation is working correctly before relying on it for ongoing data collection.

### What the Status Means

| Status | Meaning |
|--------|---------|
| **Success** | Data imported correctly, unique keys detected |
| **Warning** | Data imported but potential issues (e.g., no unique key found) |
| **Error** | Import failed - check format or configuration |

---

## Step 4: Handling Errors

If an email fails to process:

1. **Error emails are forwarded** to your configured admin email address
2. **Detailed error messages** explain what went wrong
3. **Event logs** capture full details for debugging

Common error causes:
- Unsupported attachment format
- Empty or malformed files
- Missing required fields
- Permission issues

---

## Security & Privacy Considerations

Protecting sensitive information, especially Personally Identifiable Information (PII), is critical!
- **Access Controls:** Only authorized users with dataset permissions can view or manage imported data.
- **Data at Rest & in Transit:** All email and file data is encrypted.
- **Automated Scanning:** Scoop flags potentially sensitive fields (names, emails, IDs, etc.) and lets you control access or apply redactions.
- **Audit Logs:** Every import is logged for compliance tracking.

> **Tip:** Before configuring automatic imports, review the contents of your source files and verify you’re not forwarding unwanted or unredacted PII. Use Scoop’s field masking or role-based access controls for sensitive columns.

---

## Troubleshooting & Best Practices
- If expected emails aren't ingested, check your email service’s spam/junk filters and sender whitelist settings.
- Use distinctive subject lines and attachment naming conventions to prevent accidental imports/duplicates.
- Regularly review imported datasets to validate data quality.
- For high-security environments, coordinate with IT to monitor inbound email flow and restrict sender sources.

---

## Next Steps
Ready to turn inbox chaos into business insight?  
Head to **Datasets > Add New > Email Source** to start configuring your first automated import.  
If you need help or have unique source requirements, contact Scoop support — our team is glad to walk you through best practices and controls.
