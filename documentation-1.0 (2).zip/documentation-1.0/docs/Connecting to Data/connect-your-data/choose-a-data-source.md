---
title: Choose a Data Source
deprecated: false
hidden: false
metadata:
  robots: index
---
# Choosing a Source — Overview

Scoop Analytics makes it easy for you to connect and analyze all kinds of data—whether it lives in spreadsheets, automated email reports, cloud apps (SaaS), or directly in databases. Picking the right data source type is important for downstream automation, live updates, blending, and collaboration. Below you'll find a quick decision matrix to help you choose the best connector based on your specific goal.

> **Tip:** Still unsure? Start with the simplest connection that serves your business objective. You can always upgrade to a live or scheduled feed later—Scoop makes it easy to switch connectors or blend multiple sources in one analysis workspace.

## Source Type Decision Matrix

| Your Goal                                      | Typical Example                            | Recommended Scoop Connector      | Key Characteristics                                       |
|------------------------------------------------|---------------------------------------------|----------------------------------|-----------------------------------------------------------|
| Analyze a one-off file                         | "Upload my Excel or CSV once"              | File Upload / Local File         | Quick, manual, no ongoing updates                         |
| Automate with scheduled emailed reports        | "Send me my CRM/Netsuite report weekly"    | Data Email                       | Scoop ingests from a dedicated email address; supports csv, xlsx, and pdf attachments. Optionally schedules reprocessing as new emails arrive. |
| Connect to a live SaaS platform                | "Sync Salesforce, Google Ads, Shopify"     | SaaS Connector (API sync)        | Real-time or scheduled sync; easy OAuth setup; supports over 100+ popular apps. |
| Direct database connection for live querying   | "Tap into Postgres, MySQL, Redshift"       | Database Connector (JDBC, cloud) | Live connection; advanced users can query or schedule extracts. Supports both cloud and on-prem databases. |
| Blend or combine multiple datasets             | "Combine finance + CRM + product data"     | Blended Dataset                  | Use Scoop’s visual blending tools to merge data from any sources above—even different types. Refresh automatically when any source updates. |

### Key Takeaways
- Use **File Upload** for quick, exploratory analysis with spreadsheets or CSVs.
- Use **Data Email** to automate recurring, scheduled reports (e.g., weekly/monthly downloads from CRM, ERP, or marketing tools).
- Use a **SaaS Connector** to bring in live data directly from supported cloud applications—great for dashboards and near-real-time analysis.
- Use a **Database Connector** if you need direct access to business databases and want more advanced querying or regular scheduled refreshes.
- Whenever you want to consolidate data from multiple systems (e.g., for blended analytics or distributed reporting), Scoop’s **Blended Dataset** tools help you visually define relationships and automate data preparation.

> **Tip:** Datasets created by syncing with SaaS or databases can be scheduled for daily (or more frequent) refresh, ensuring your analytics and dashboards always reflect the latest numbers.

