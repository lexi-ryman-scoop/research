---
title: Best Practices in Selecting/Creating Source Reports
excerpt: ''
deprecated: false
hidden: true
metadata:
  title: Best Practices for Source Reports
  description: >-
    Guidelines for selecting and creating source reports that work best with
    Scoop Analytics for automated data ingestion. (Coming soon)
  robots: index
next:
  description: ''
---