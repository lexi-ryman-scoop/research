---
title: Connecting to a Business Application
excerpt: 'Set up automated data ingestion from your business applications'
deprecated: false
hidden: false
metadata:
  title: Connecting to Business Applications
  description: >-
    Connect Scoop to CRM, marketing, finance, and other business applications.
    Native API integrations, automated report capture, and scheduled data sync.
  robots: index
next:
  description: ''
---

Scoop connects to your business applications to automatically pull data for analysis. Whether you use Salesforce, HubSpot, QuickBooks, or dozens of other applications, Scoop provides multiple ways to get your data flowing.

# Connection Methods

Scoop offers three primary ways to connect to applications:

| Method | How It Works | Best For |
|--------|--------------|----------|
| **Native API** | Direct OAuth connection, automatic daily sync | CRMs, marketing platforms, project tools |
| **Robot Capture** | Automated browser-based report extraction | Apps without API access |
| **Email Forward** | Auto-ingest emailed reports | Scheduled reports, legacy systems |

# Setting Up a Connection

## Step 1: Start the New Dataset Wizard

From your Datasets page, click **New Dataset** and select **Application Report**:

<Image align="center" width="500px" src="https://files.readme.io/a66855e-image.png" />

## Step 2: Select Your Application

Browse or search for your application:

<Image align="center" width="500px" src="https://files.readme.io/8232cc8-image.png" />

Scoop supports 30+ applications with dedicated connectors. If you don't see your app, see [Generic Connection Options](#generic-connection-options) below.

## Step 3: Authorize the Connection

For **Native API** connections:
1. Click **Connect** to initiate OAuth
2. Log in to your application
3. Authorize Scoop to access your data
4. Return to Scoop to complete setup

For **Robot Capture** connections:
1. Scoop opens a secure browser session
2. Log in to your application
3. Navigate to the report you want
4. Scoop records the steps for automation

## Step 4: Select Data to Extract

Choose what data to pull:

| Option | Description |
|--------|-------------|
| **Object** | Standard objects like Deals, Contacts, Leads, Invoices |
| **Report** | Existing reports you've built in the application |
| **Custom** | Specific fields and filters for your needs |

## Step 5: Configure Snapshotting

For data that changes over time (like pipeline or inventory), enable snapshotting:

| Mode | Description | Use Case |
|------|-------------|----------|
| **Snapshot** | Captures daily state, tracks changes | Deals, opportunities, projects |
| **Transactional** | Appends new records only | Activities, events, logs |

## Step 6: Set Schedule

Choose when Scoop should sync data:

- **Daily:** Most common, runs overnight
- **Hourly:** For time-sensitive data (available on some plans)
- **On-demand:** Manual trigger only

# Native API Connections

Native API connections provide the best experience:

**Advantages:**
- One-click OAuth setup
- Automatic field discovery
- Real-time schema updates
- Direct access to all objects
- No report configuration needed

**Supported Apps with Native API:**
- Salesforce, HubSpot, Pipedrive, Copper, Close, Attio
- Google Analytics, Meta Ads
- Jira, Monday, Airtable
- Apollo.io
- [See full list](specific-applications/)

**How It Works:**
1. You authorize Scoop via OAuth
2. Scoop connects directly to the application's API
3. Daily sync pulls new/changed data
4. Data flows into your Scoop dataset automatically

# Robot Capture Connections

For applications without API access, Scoop's Robot Capture automates browser-based extraction:

**Advantages:**
- Works with any web application
- Captures exactly what you see in reports
- Handles complex login flows
- Supports multi-step navigation

**How It Works:**
1. Scoop opens a secure browser session
2. You log in and navigate to your report
3. Scoop records your actions
4. The robot replays these steps on schedule
5. Report data is captured and ingested

**Best Practices:**
- Use stable report URLs when possible
- Create dedicated service accounts for automation
- Set reports to consistent date ranges (e.g., "Last 30 Days")
- Test the robot capture before relying on it

# Email Forward Connections

Many applications can email reports on schedule. Scoop ingests these automatically:

**Advantages:**
- Works with any application that emails reports
- No API or browser automation needed
- Uses existing report schedules
- Handles CSV, Excel, PDF, and HTML attachments

**Setup Process:**
1. Configure your application to email reports
2. Forward those emails to your Scoop inbox address
3. Scoop automatically extracts and processes the data

**Supported Formats:**
- CSV attachments (most reliable)
- Excel files (.xlsx, .xls)
- HTML tables in email body
- PDF reports (with capture configuration)

See [Email Automated Imports](connect-your-data/email-automated-imports) for detailed setup instructions.

# Generic Connection Options

If your application isn't in Scoop's connector list, you have several options:

## Option 1: Email Reports
If your app can schedule email reports:
1. Set up automated report emails
2. Forward to your Scoop inbox
3. Configure ingestion rules

## Option 2: Manual Export
For periodic analysis:
1. Export data to CSV or Excel
2. Upload to Scoop directly
3. Scoop handles the rest

## Option 3: Database Connection
If you have database access:
1. Connect Scoop to your database directly
2. Query the underlying data
3. See [Database Connections](connect-your-data/connecting-to-a-database)

## Option 4: Custom Integration
For enterprise needs:
- Contact us about custom connector development
- API-first architecture enables rapid integration

# What Happens After Connection

Once connected, Scoop:

1. **Initial Sync:** Pulls historical data (varies by application)
2. **Daily Sync:** Automatically updates data overnight
3. **Processing:** Applies your calculated columns and blends
4. **Ready for Analysis:** Data appears in Explorer and AI Chat

You can monitor sync status on the Datasets page:
- **Green:** Sync successful
- **Yellow:** Sync completed with warnings
- **Red:** Sync failed (check configuration)

# Managing Connections

## Viewing Connection Status
From your dataset, click **Settings** → **Connection** to see:
- Last sync time
- Records synced
- Any error messages
- Connection credentials

## Updating Credentials
If your password changes or OAuth expires:
1. Go to dataset Settings → Connection
2. Click **Reconnect**
3. Re-authorize with updated credentials

## Changing What's Extracted
To modify fields or filters:
1. Go to dataset Settings → Source
2. Adjust field selection
3. Save and optionally reprocess

## Disconnecting
To remove a connection:
1. Delete the dataset, or
2. Disable sync in Settings (keeps historical data)

# Troubleshooting

## Connection Fails

- **OAuth expired:** Reconnect and re-authorize
- **Credentials changed:** Update login information
- **API limits:** Some apps have rate limits; contact support
- **Firewall:** Ensure Scoop IPs are whitelisted (see below)

## No Data Syncing

- Check that the object/report has data
- Verify date range settings
- Look for filter conditions that exclude data
- Check application permissions

## Partial Data

- API may have field-level permissions
- Some fields require elevated access
- Check if new fields need to be selected

# IP Whitelisting

If your application requires IP whitelisting, add Scoop's IP:

```
44.231.97.118
```

This is required for some database connections and firewall-protected applications.

# Related Topics

- [Specific Applications](specific-applications/) - Application-specific setup guides
- [Email Automated Imports](connect-your-data/email-automated-imports) - Email-based ingestion
- [Database Connections](connect-your-data/connecting-to-a-database) - Direct database access
- [Upload a File](connect-your-data/upload-a-file-or-spreadsheet) - Manual file upload
