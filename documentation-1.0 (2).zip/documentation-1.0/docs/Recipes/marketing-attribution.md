---
title: Marketing Attribution Investigation
excerpt: Discover which campaigns and channels drive quality leads
deprecated: false
hidden: false
metadata:
  title: Marketing Attribution Investigation - Scoop Recipe
  description: Use Scoop's AI to investigate marketing attribution - discover which campaigns drive quality leads, optimize spend, and improve ROI.
  robots: index
---

# Marketing Attribution Investigation

Discover which marketing campaigns and channels drive the highest quality leads and best ROI.

---

## The Question

> **"Which campaigns drive quality leads?"**

Or variations:
- "What's our most effective marketing channel?"
- "Which campaigns have the best ROI?"
- "What marketing is actually working?"
- "Why is lead quality declining?"

---

## What Scoop Investigates

When you ask about marketing attribution, Scoop runs a multi-probe investigation:

```
Investigation Plan:
├── Probe 1: Lead volume by source
│   └── How many leads from each campaign/channel?
├── Probe 2: Lead quality by source
│   └── Which sources produce leads that convert?
├── Probe 3: Revenue attribution
│   └── How much revenue traces to each source?
├── Probe 4: Cost efficiency
│   └── What's the cost per qualified lead by channel?
├── Probe 5: Pattern analysis
│   └── What characteristics predict high-value leads?
└── Synthesis: Attribution insights and recommendations
```

---

## Example Output

```
Investigation Results: Marketing Attribution Analysis

FINDING 1: Lead Volume by Channel
├── Paid Search: 2,450 leads (35%)
├── LinkedIn Ads: 1,820 leads (26%)
├── Organic Search: 1,540 leads (22%)
├── Email Campaigns: 840 leads (12%)
└── Events/Webinars: 350 leads (5%)

FINDING 2: Lead Quality (Conversion to Opportunity)
├── Events/Webinars: 42% convert (highest quality)
├── LinkedIn Ads: 28% convert
├── Organic Search: 22% convert
├── Email Campaigns: 18% convert
└── Paid Search: 8% convert (lowest quality)

FINDING 3: Revenue Attribution (Last 6 months)
├── LinkedIn Ads: $1.8M (32%)
├── Events/Webinars: $1.2M (21%)
├── Organic Search: $1.1M (19%)
├── Paid Search: $980K (17%)
└── Email Campaigns: $620K (11%)

FINDING 4: Cost Efficiency
├── Organic Search: $45 per qualified lead
├── Events/Webinars: $180 per qualified lead
├── LinkedIn Ads: $220 per qualified lead
├── Email Campaigns: $85 per qualified lead
└── Paid Search: $340 per qualified lead

FINDING 5: High-Value Lead Patterns
├── Job title contains "VP" or "Director": 3.2x more likely to close
├── Company size 200-1000 employees: highest conversion rate
├── Multiple touches before form fill: 2.5x higher deal size
└── Downloaded technical content: 40% faster time to close

RECOMMENDED ACTIONS:
1. Shift $50K/month from Paid Search to Events/Webinars
2. Create more technical content (predicts faster close)
3. Build retargeting sequences before form fill
4. Focus LinkedIn targeting on VP/Director titles at 200-1000 employee companies
```

---

## Sample Prompts

### Basic Attribution
```
"Which marketing channels work best?"
```

### Quality Focus
```
"Which campaigns produce leads that actually close?"
```

### ROI Analysis
```
"What's the ROI of our LinkedIn ads vs Google ads?"
```

### Trend Analysis
```
"How has lead quality changed by source this year?"
```

### Predictive
```
"What predicts whether a marketing lead will become a customer?"
```

---

## Follow-Up Questions

After the initial investigation, dig deeper:

| Follow-Up | What It Reveals |
|-----------|-----------------|
| "What predicts a lead will close?" | ML analysis of conversion patterns |
| "Compare leads from webinars vs paid search" | Side-by-side quality comparison |
| "Why is paid search conversion declining?" | Root cause analysis |
| "Show me the customer journey for our best customers" | Multi-touch attribution |
| "Which content pieces generate the most pipeline?" | Content effectiveness |

---

## Data Requirements

For best attribution analysis, your data should include:

| Field | Purpose |
|-------|---------|
| Lead ID | Unique identifier |
| Lead Source | Original acquisition channel |
| Campaign | Specific campaign name |
| Created Date | When lead was acquired |
| Converted | Whether lead became opportunity |
| Opportunity Amount | Revenue potential |
| Close Date | When deal closed (if won) |
| Won/Lost | Deal outcome |
| Marketing Spend | Campaign costs (for ROI) |
| Lead Score | Quality assessment |
| Company Size | Firmographic segmentation |
| Job Title | Contact role |

---

## Tips for Better Results

1. **Track the full journey** - Connect leads to opportunities to revenue
2. **Include costs** - Enables true ROI calculation
3. **Capture touch points** - Multi-touch attribution needs interaction data
4. **Tag campaigns consistently** - Clean naming enables accurate grouping
5. **Include lost deals** - Understanding what doesn't work is valuable

---

## Related Patterns

- [Pipeline Investigation](pipeline-investigation.md) - Analyze pipeline health
- [Customer Churn Analysis](churn-investigation.md) - Predict and prevent churn
- [Period Comparison](period-comparison.md) - Compare marketing performance over time
