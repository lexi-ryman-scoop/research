---
title: Team Performance Investigation
excerpt: Discover what differentiates top performers from the rest
deprecated: false
hidden: false
metadata:
  title: Team Performance Investigation - Scoop Recipe
  description: Use Scoop's AI to investigate team performance - find what differentiates top performers and create actionable playbooks.
  robots: index
---

# Team Performance Investigation

Discover what differentiates top performers and create data-driven playbooks for the whole team.

---

## The Question

> **"What differentiates top performers?"**

Or variations:
- "Why do some reps consistently hit quota?"
- "What makes our best salespeople successful?"
- "What separates high performers from low performers?"
- "How can we replicate top performer behavior?"

---

## What Scoop Investigates

When you ask about performance differences, Scoop runs a multi-probe investigation:

```
Investigation Plan:
├── Probe 1: Quantify the gap
│   └── How much do top performers outperform?
├── Probe 2: Activity patterns
│   └── What do top performers do differently?
├── Probe 3: Deal patterns
│   └── What types of deals do top performers win?
├── Probe 4: Behavioral differences
│   └── How do work patterns differ?
├── Probe 5: Predictive factors
│   └── What predicts high performance?
└── Synthesis: Actionable playbook recommendations
```

---

## Example Output

```
Investigation Results: Sales Team Performance Analysis

FINDING 1: Performance Gap
├── Top quartile (5 reps): $2.8M average revenue
├── Middle 50% (10 reps): $1.4M average revenue
├── Bottom quartile (5 reps): $680K average revenue
└── Top performers: 2x average, 4x bottom performers

FINDING 2: Activity Differences
├── Calls per week:
│   ├── Top: 45 calls/week
│   └── Bottom: 62 calls/week (more calls, worse results)
├── Discovery calls:
│   ├── Top: 35 min average duration
│   └── Bottom: 18 min average duration
├── Follow-up speed:
│   ├── Top: 2.4 hours average response
│   └── Bottom: 18 hours average response
└── Multi-threading:
    ├── Top: 3.2 contacts per deal
    └── Bottom: 1.4 contacts per deal

FINDING 3: Deal Selection Patterns
├── Top performers deal size: $85K average
├── Bottom performers deal size: $42K average
├── Top performers target: 200-1000 employee companies
├── Bottom performers spread across all segments
└── Top performers: 60% in 3 industries vs. 15% for bottom

FINDING 4: Win Rate Analysis
├── Overall win rate: Top 42%, Bottom 18%
├── Win rate by stage:
│   ├── Discovery → Qualified: Top 75%, Bottom 45%
│   ├── Qualified → Proposal: Top 68%, Bottom 52%
│   └── Proposal → Close: Top 82%, Bottom 68%
└── Key gap: Top performers qualify better upfront

FINDING 5: Predictive Patterns (ML Analysis)
├── Strongest predictors of rep success:
│   ├── Discovery call duration (35+ min)
│   ├── Multi-threading (3+ contacts)
│   ├── Industry focus (specialist vs. generalist)
│   └── Follow-up response time (<4 hours)
└── Activity volume NOT correlated with success

RECOMMENDED PLAYBOOK:
1. Quality over quantity: Fewer, longer discovery calls
2. Multi-thread early: Target 3+ contacts per account
3. Specialize: Assign reps to 2-3 industries
4. Response SLA: Implement 4-hour follow-up standard
5. Qualification rigor: Use top performer criteria
6. Deal size discipline: Minimum $50K opportunities
```

---

## Sample Prompts

### Basic Comparison
```
"What makes our top salespeople different?"
```

### Specific Metric
```
"Why do some reps have higher win rates?"
```

### Activity Focus
```
"What activities predict sales success?"
```

### New Rep Coaching
```
"What should new reps learn from top performers?"
```

### Segment Focus
```
"What differentiates top performers in enterprise sales?"
```

---

## Follow-Up Questions

After the initial investigation, dig deeper:

| Follow-Up | What It Reveals |
|-----------|-----------------|
| "What predicts whether a rep will hit quota?" | ML model of success factors |
| "Compare discovery call patterns of top vs bottom reps" | Specific behavioral differences |
| "How do top performers qualify deals differently?" | Qualification methodology |
| "Show me the deal pipeline of our top 3 reps" | Example patterns to follow |
| "What do struggling reps have in common?" | Common failure patterns |

---

## Data Requirements

For best performance analysis, your data should include:

| Field | Purpose |
|-------|---------|
| Rep/Owner | Sales rep identifier |
| Revenue/Quota | Performance metrics |
| Deal Details | Amount, stage, outcome |
| Activity Data | Calls, emails, meetings |
| Call Duration | Engagement quality |
| Response Times | Speed-to-lead metrics |
| Contact Count | Multi-threading data |
| Industry/Segment | Deal characteristics |
| Deal Age | Cycle time analysis |
| Win/Loss Reason | Outcome drivers |

---

## Tips for Better Results

1. **Include activity data** - Behaviors matter as much as outcomes
2. **Track call quality** - Duration often matters more than quantity
3. **Capture contacts per deal** - Multi-threading is key
4. **Include tenure** - Control for experience differences
5. **Track time metrics** - Response times and cycle lengths
6. **Log deal characteristics** - Size, segment, complexity

---

## Use Cases

### Sales Team Optimization
Identify winning behaviors and create training programs.

### Territory Design
Understand what makes certain territories more productive.

### Hiring Profiles
Find traits that predict success for recruiting.

### Coaching Plans
Create personalized development plans based on data.

### Quota Setting
Use actual performance data to set realistic targets.

---

## Related Patterns

- [Pipeline Investigation](pipeline-investigation.md) - Team pipeline health
- [Period Comparison](period-comparison.md) - Performance trends over time
- [Customer Churn Analysis](churn-investigation.md) - Customer retention patterns
