---
title: Understanding Recipes
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Understanding Recipes
  description: >-
    Pre-built, customizable data workflows for common analytics tasks like sales
    forecasting and marketing analysis.
  robots: index
next:
  description: ''
---
# What are Recipes?

Recipes in Scoop Analytics are pre-defined, customizable data transformation and analysis workflows. They allow users to process, clean, and analyze their data without the need for extensive coding or manual data manipulation. Each recipe is designed to perform a specific set of tasks, from simple data cleansing operations to complex analytical computations, making data preparation and analysis more accessible and efficient.

![](https://files.readme.io/151ab9654175c74967a55de879e76b4ca5d3390b68c068d3268d2b24b6fa9ec4-image.png)

<br />

***

# Why are Recipes Valuable?

1. Efficiency and Time-Saving\
   Recipes streamline data preparation processes, significantly reducing the time required to clean, transform, and analyze data. By automating repetitive tasks, users can focus on more strategic activities.
2. Consistency and Accuracy\
   Automated recipes ensure that data transformations and analyses are performed consistently every time, reducing the risk of human error. This consistency leads to more accurate and reliable data insights.
3. Ease of Use\
   Recipes are designed with user-friendliness in mind. Even users with limited technical skills can utilize recipes to perform complex data operations, thanks to intuitive interfaces and pre-built workflows.
4. Customizability\
   While recipes come with predefined steps, they are fully customizable to fit the specific needs of the user. Users can adjust parameters, add or remove steps, and tailor the workflows to their unique data and analysis requirements.
5. Reusability\
   Once created, recipes can be saved and reused across different datasets and projects. This reusability ensures that best practices are easily replicated, saving time and promoting standardization across the organization.
6. Scalability\
   Recipes can handle varying volumes of data, making them suitable for both small-scale analyses and large, enterprise-level data projects. This scalability ensures that as data needs grow, the tools used remain effective and efficient.
7. Integration with Other Tools\
   Recipes in Scoop Analytics can be integrated with other data sources and tools, allowing seamless data import and export. This integration facilitates a more comprehensive data ecosystem, enabling richer insights and more informed decision-making.
8. Collaboration and Sharing\
   Recipes can be shared among team members, fostering collaboration and ensuring that everyone is on the same page. Shared recipes promote knowledge transfer and encourage best practices across the organization.

By leveraging the power of recipes in Scoop Analytics, users can transform their data workflows, enhance productivity, and derive more meaningful insights with greater ease and efficiency.

# Example Recipes

* Sales forecasting
* Product usage analysis and customer value
* Marketing cost per lead

Each recipe typically relies on one or maybe two source reports and requires that those source reports have certain fields. In the case of sales forecasting for example, a single source report from your CRM is all that is required. That source report should list all currently open sales opportunities and include the following necessary fields:

* OpportunityID (a unique identifier so that this list can be snapshotted)
* Opportunity Name (something human readable)
* Opportunity Amount (some amount indicating value)
* Sales Stage (the deal status, with one potential value being closed won or success)
* Owner
* Expected close date
* Created date
* Any additional status or attribute fields that may be useful for analysis later

Your CRM may not use these exact names or perhaps you've configured it to use different names. However, as long as you can make the names you use to the ones expected by the recipe, Scoop can automatically setup a forecasting canvas for you that includes numerous best practice analysis and all the process and forecast accuracy insight you might need. In minutes you can have a fully functioning, best practice data application setup and running without the need for any configuration. And, since the underlying Scoop components are the ones mentioned above, if you want to make changes or add more analysis to what is out of the box, you can freely do so. You are not bound to a one size fits all approach that packaged applications provide. Morover, should you like to extend this use case to include other data, like sales or financial data, you are free to do that as well.
