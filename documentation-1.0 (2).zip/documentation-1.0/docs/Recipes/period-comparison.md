---
title: Period Comparison Investigation
excerpt: Discover what changed between time periods and why
deprecated: false
hidden: false
metadata:
  title: Period Comparison Investigation - Scoop Recipe
  description: Use Scoop's AI to compare time periods, find what changed, and understand why metrics improved or declined.
  robots: index
---

# Period Comparison Investigation

Compare any two time periods to understand what changed and why.

---

## The Question

> **"What changed this quarter compared to last quarter?"**

Or variations:
- "Compare Q3 to Q2"
- "What's different about this month vs last month?"
- "How did performance change year over year?"
- "What improved and what declined?"

---

## What Scoop Investigates

Scoop performs a comprehensive comparison:

```
Investigation Plan:
├── Probe 1: Identify all metrics
│   └── What metrics exist in the data?
├── Probe 2: Calculate changes
│   └── How did each metric change?
├── Probe 3: Find significant changes
│   └── Which changes are statistically meaningful?
├── Probe 4: Analyze by dimension
│   └── Break down changes by segment, region, etc.
├── Probe 5: Identify drivers
│   └── ML analysis: What factors drove the changes?
└── Synthesis: Executive summary
```

---

## Example Output

```
Investigation Results: Q3 vs Q2 Comparison

SUMMARY:
Overall performance improved with revenue up 12%,
but customer acquisition costs increased 23%.

KEY IMPROVEMENTS:
├── Revenue: +12% ($4.2M → $4.7M)
├── Win Rate: +8 points (32% → 40%)
├── Customer Satisfaction: +0.4 points (8.1 → 8.5)
├── Deal Size (avg): +15% ($24K → $28K)
└── Time to Close: -5 days (45 → 40 days)

KEY DECLINES:
├── Customer Acquisition Cost: +23% ($850 → $1,045)
├── Lead Volume: -18% (1,200 → 984)
├── Trial Conversion: -3 points (28% → 25%)
└── Support Response Time: +2 hours (4h → 6h)

BREAKDOWN BY SEGMENT:
├── Enterprise: Revenue +24%, Win Rate +12 pts
├── Mid-Market: Revenue +8%, Win Rate +2 pts
└── SMB: Revenue -3%, Win Rate -1 pt

ROOT CAUSE ANALYSIS:
├── Revenue increase driven by 3 large enterprise deals
├── Win rate improvement correlated with new demo process
├── CAC increase due to 40% higher ad spend (CPL up 35%)
├── Lead volume decline from paused content marketing
└── Support slowdown linked to 2 team departures

RECOMMENDED FOCUS AREAS:
1. Investigate high CAC - ROI may not justify spend
2. Resume content marketing for lead volume
3. Address support capacity before it impacts CSAT
4. Document enterprise success factors to replicate
```

---

## Sample Prompts

### Basic Comparison
```
"What changed this quarter vs last quarter?"
```

### Specific Metrics
```
"How did revenue and costs change month over month?"
```

### With Focus Area
```
"What changed in our enterprise segment this quarter?"
```

### Year Over Year
```
"Compare this Q3 to Q3 last year"
```

### Root Cause Focus
```
"Why did performance change between Q2 and Q3?"
```

---

## Follow-Up Questions

| Follow-Up | What It Reveals |
|-----------|-----------------|
| "Why did CAC increase?" | Deep dive on specific metric |
| "What drove the enterprise improvement?" | Success factor analysis |
| "Show me the weekly trend" | More granular timing |
| "Which team members improved most?" | Individual performance |
| "What predicts these improvements?" | ML pattern analysis |

---

## Data Requirements

Any dataset with:

| Field | Purpose |
|-------|---------|
| Date Field | For period grouping |
| Numeric Metrics | What to compare |
| Dimensions | For breakdown analysis (segment, region, etc.) |

The more metrics and dimensions, the richer the comparison.

---

## Types of Comparisons

### Sequential Periods
- This month vs last month
- This quarter vs last quarter
- This week vs last week

### Year-Over-Year
- Q3 2025 vs Q3 2024
- This month vs same month last year
- Rolling 12 months vs prior 12

### Custom Ranges
- Before vs after product launch
- Pre-campaign vs post-campaign
- First half vs second half

---

## Understanding the Analysis

### Significant vs Noise
Scoop identifies which changes are meaningful:
- Statistical significance testing
- Filters out random variation
- Highlights changes worth investigating

### Dimension Breakdowns
Shows WHERE changes happened:
- By customer segment
- By product line
- By region/territory
- By team member

### Root Cause Analysis
Uses ML to find WHY changes happened:
- Correlation analysis
- Factor importance
- Pattern detection

---

## Tips for Better Comparisons

1. **Ensure date coverage** - Both periods need sufficient data
2. **Include dimensions** - Enables breakdown analysis
3. **Add context fields** - Campaign, rep, source for richer analysis
4. **Consistent definitions** - Same metrics calculated the same way

---

## Related Patterns

- [Pipeline Investigation](pipeline-investigation.md) - Pipeline-specific comparison
- [Revenue Investigation](revenue-investigation.md) - Revenue-focused analysis
- [Churn Investigation](churn-investigation.md) - Compare churned vs retained
