---
title: Pipeline Health Investigation
excerpt: Discover why your sales pipeline changed and what to do about it
deprecated: false
hidden: false
metadata:
  title: Pipeline Health Investigation - Scoop Recipe
  description: Use Scoop's AI to investigate pipeline health - find out why pipeline shrunk, which stages are bottlenecks, and what actions to take.
  robots: index
---

# Pipeline Health Investigation

Investigate why your sales pipeline changed and get actionable recommendations.

---

## The Question

> **"Why did pipeline shrink this quarter?"**

Or variations:
- "Why is our pipeline down?"
- "What happened to our Q3 pipeline?"
- "Investigate pipeline health"

---

## What Scoop Investigates

When you ask about pipeline health, Scoop runs a multi-probe investigation:

```
Investigation Plan:
├── Probe 1: Quantify the change
│   └── How much did pipeline change? ($ and %)
├── Probe 2: Analyze by stage
│   └── Which stages lost the most value?
├── Probe 3: Analyze by segment
│   └── Which customer segments are affected?
├── Probe 4: Investigate timing
│   └── When did the decline start?
├── Probe 5: Find root causes
│   └── What factors correlate with lost pipeline?
└── Synthesis: Actionable summary
```

---

## Example Output

```
Investigation Results: Pipeline Decline Analysis

FINDING 1: Pipeline Value
├── Current quarter: $4.2M
├── Previous quarter: $5.8M
└── Change: -$1.6M (-28%)

FINDING 2: Stage Analysis
├── Discovery: -$300K (leads not converting to qualified)
├── Qualified: -$450K (stuck deals timing out)
├── Proposal: -$850K (largest loss - deals going dark)
└── Negotiation: No significant change

FINDING 3: Segment Breakdown
├── Enterprise: -$1.2M (75% of total loss)
├── Mid-Market: -$250K
└── SMB: -$150K

FINDING 4: Root Cause Analysis
├── Enterprise deals averaging 45+ days in Proposal stage
├── 8 enterprise deals lost to competitor X (new entrant)
├── Average response time to RFPs increased from 5 to 12 days
└── 3 reps carried 80% of lost pipeline (team capacity issue)

RECOMMENDED ACTIONS:
1. Implement 48-hour RFP response SLA
2. Create competitive battle card for competitor X
3. Review rep workload distribution
4. Add proposal stage follow-up automation
```

---

## Sample Prompts

### Basic Investigation
```
"Why did pipeline shrink?"
```

### With Time Context
```
"Why did pipeline drop in Q3 compared to Q2?"
```

### With Segment Focus
```
"Why is enterprise pipeline down this quarter?"
```

### With Stage Focus
```
"Why are deals getting stuck in proposal stage?"
```

---

## Follow-Up Questions

After the initial investigation, dig deeper:

| Follow-Up | What It Reveals |
|-----------|-----------------|
| "What predicts deals getting stuck in proposal?" | ML analysis of stuck deal patterns |
| "Compare won vs lost enterprise deals" | Key differentiators for winning |
| "Show me the deals lost to competitor X" | Specific competitive losses |
| "What changed about our win rate over time?" | Trend analysis |

---

## Data Requirements

For best results, your pipeline data should include:

| Field | Purpose |
|-------|---------|
| Deal/Opportunity ID | Unique identifier for tracking |
| Deal Name | Human-readable reference |
| Amount | Pipeline value |
| Stage | Current deal stage |
| Owner | Sales rep assignment |
| Created Date | When deal entered pipeline |
| Close Date | Expected close |
| Last Activity | Engagement tracking |
| Segment/Industry | For segmentation analysis |
| Loss Reason | For root cause analysis |

---

## Tips for Better Results

1. **Include historical data** - Scoop needs comparison points
2. **Track stage changes** - Snapshot data enables stage transition analysis
3. **Capture loss reasons** - Helps identify patterns in lost deals
4. **Add competitor field** - Enables competitive analysis

---

## Related Patterns

- [Win/Loss Analysis](win-loss-investigation.md) - What predicts deal success
- [Revenue Changes](revenue-investigation.md) - Investigate closed revenue
- [Period Comparison](period-comparison.md) - General before/after analysis
