---
title: Recipes & Investigation Patterns
excerpt: Ready-to-use analysis patterns for common business questions
deprecated: false
hidden: false
metadata:
  title: Scoop Recipes & Investigation Patterns
  description: Pre-built investigation patterns and analysis recipes for common business scenarios - sales, marketing, customer success, and operations.
  robots: index
---

# Recipes & Investigation Patterns

This section provides ready-to-use analysis patterns for common business questions. Each recipe shows you:
- The question to ask
- What Scoop investigates
- Example findings
- Follow-up questions to go deeper

---

## What Are Recipes?

**Recipes** are pre-defined analysis workflows that Scoop can run on your data. They automate common analytical tasks like:
- Sales forecasting from pipeline data
- Customer segmentation
- Marketing attribution

[Learn more about Recipes](understanding-recipes.md)

---

## Investigation Patterns

These patterns show how to use Scoop's AI to investigate specific business questions. Unlike traditional reports, these trigger **multi-probe investigations** that find root causes.

### Sales & Revenue

| Pattern | Question to Ask | What You'll Learn |
|---------|-----------------|-------------------|
| [Pipeline Health](pipeline-investigation.md) | "Why did pipeline shrink this quarter?" | Which stages lost deals, why, and what to fix |
| [Team Performance](team-performance-comparison.md) | "What differentiates top performers?" | Behaviors and patterns that predict success |

### Customer Success

| Pattern | Question to Ask | What You'll Learn |
|---------|-----------------|-------------------|
| [Churn Analysis](churn-investigation.md) | "What predicts customer churn?" | Early warning signs and intervention opportunities |

### Marketing

| Pattern | Question to Ask | What You'll Learn |
|---------|-----------------|-------------------|
| [Campaign Attribution](marketing-attribution.md) | "Which campaigns drive quality leads?" | True campaign effectiveness beyond vanity metrics |

### Operations

| Pattern | Question to Ask | What You'll Learn |
|---------|-----------------|-------------------|
| [Period Comparison](period-comparison.md) | "What changed this quarter vs last?" | Comprehensive view of what improved or declined |

---

## How to Use These Patterns

1. **Load your data** - Upload or connect the relevant dataset
2. **Ask the question** - Use the suggested prompt (or your own variation)
3. **Review the investigation** - Watch Scoop's multi-probe analysis
4. **Ask follow-ups** - Dig deeper based on initial findings
5. **Export or share** - Generate a presentation or share insights

> **Tip**: These prompts are starting points. Scoop understands natural language, so feel free to ask in your own words.

---

## Creating Your Own Recipes

You can save any analysis workflow as a reusable recipe:

1. Run an investigation that produces valuable results
2. Save the queries and filters used
3. Share with your team for consistent analysis

This turns your best analytical practices into repeatable patterns that anyone can use.
