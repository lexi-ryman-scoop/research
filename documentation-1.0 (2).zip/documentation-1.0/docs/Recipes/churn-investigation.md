---
title: Customer Churn Investigation
excerpt: Discover what predicts churn and identify at-risk customers before it's too late
deprecated: false
hidden: false
metadata:
  title: Customer Churn Investigation - Scoop Recipe
  description: Use Scoop's AI and ML to predict customer churn, find early warning signs, and identify intervention opportunities.
  robots: index
---

# Customer Churn Investigation

Discover what predicts customer churn and identify at-risk customers before they leave.

---

## The Question

> **"What predicts customer churn?"**

Or variations:
- "Why are customers churning?"
- "Which customers are likely to churn?"
- "What factors drive customer retention?"

---

## What Scoop Investigates

Scoop uses machine learning to find churn predictors:

```
Investigation Plan:
├── Probe 1: Quantify churn rate
│   └── What's the current churn rate and trend?
├── Probe 2: Build predictive model
│   └── ML analysis: What factors predict churn?
├── Probe 3: Segment churned customers
│   └── What patterns exist in churned customers?
├── Probe 4: Time-based analysis
│   └── When in the lifecycle does churn happen?
├── Probe 5: Identify at-risk customers
│   └── Apply model to current customers
└── Synthesis: Actionable predictions
```

---

## Example Output

```
Investigation Results: Customer Churn Prediction

MODEL ACCURACY: 84%

PREDICTIVE RULES DISCOVERED:

Rule 1 (Confidence: 89%):
IF last_login > 21 days
   AND support_tickets >= 3
   AND plan = "Basic"
THEN churn_risk = HIGH

Rule 2 (Confidence: 85%):
IF usage_trend = "Declining"
   AND contract_renewal < 60 days
   AND NPS_score < 7
THEN churn_risk = HIGH

Rule 3 (Confidence: 81%):
IF onboarding_incomplete = TRUE
   AND days_since_signup > 30
THEN churn_risk = MEDIUM

TOP CHURN PREDICTORS (by importance):
1. Days since last login (34% impact)
2. Usage trend last 30 days (28% impact)
3. Support ticket sentiment (18% impact)
4. Contract type (12% impact)
5. Feature adoption score (8% impact)

AT-RISK CUSTOMERS (applying model):
├── High Risk: 47 customers ($892K ARR)
├── Medium Risk: 123 customers ($1.4M ARR)
└── Low Risk: 1,847 customers ($18.2M ARR)

RECOMMENDED ACTIONS:
1. Immediate outreach to 47 high-risk accounts
2. Re-engagement campaign for users inactive >14 days
3. Onboarding completion program for incomplete users
4. Basic plan upgrade incentives before renewal
```

---

## Sample Prompts

### Prediction Focus
```
"What predicts customer churn?"
```

### Root Cause Focus
```
"Why are customers churning?"
```

### Segment Focus
```
"What predicts churn for enterprise customers?"
```

### Action Focus
```
"Which customers should we reach out to before they churn?"
```

### Comparison Focus
```
"What differentiates customers who churn from those who stay?"
```

---

## Follow-Up Questions

| Follow-Up | What It Reveals |
|-----------|-----------------|
| "Show me the high-risk customers" | List with churn scores |
| "What do retained customers have in common?" | Success patterns |
| "Compare churned vs retained in the last 6 months" | Specific differentiators |
| "What's the typical churn timeline?" | When customers leave |
| "How does churn vary by segment?" | Segment-specific patterns |

---

## Data Requirements

For best churn prediction results:

| Field | Purpose |
|-------|---------|
| Customer ID | Unique identifier |
| Churned (Y/N) | Target variable for ML |
| Churn Date | Timing analysis |
| Login/Usage Data | Engagement signals |
| Support Tickets | Satisfaction signals |
| Contract Details | Renewal timing |
| NPS/CSAT Scores | Satisfaction metrics |
| Feature Usage | Adoption signals |
| Tenure | Lifecycle analysis |
| Plan/Tier | Segmentation |

---

## Understanding the ML Results

### Predictive Rules
Scoop presents ML findings as human-readable IF-THEN rules:
- Easy to understand and act on
- Confidence percentage shows reliability
- Can be directly translated to alerts/triggers

### Feature Importance
Shows which factors matter most:
- Higher percentage = stronger predictor
- Focus interventions on top factors
- Deprioritize factors with low impact

### Model Accuracy
- 80%+ = Highly actionable
- 70-80% = Good for prioritization
- <70% = May need more/better data

---

## Tips for Better Predictions

1. **Include behavioral data** - Login frequency, feature usage
2. **Add engagement signals** - Email opens, support interactions
3. **Capture the outcome** - Make sure you have churned/retained labels
4. **Historical depth** - 6+ months of data improves accuracy
5. **Include negatives** - Support issues, payment failures

---

## Related Patterns

- [Customer Segmentation](segmentation-investigation.md) - Group customers by behavior
- [Win/Loss Analysis](win-loss-investigation.md) - Similar predictive approach for deals
- [Period Comparison](period-comparison.md) - How churn changed over time
