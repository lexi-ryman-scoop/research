---
title: Scoop in Canva
excerpt: >-
  User can integrate Scoop Analytics objects (with live data)such as charts,
  graphs and tables into Canva presentations.
deprecated: false
hidden: false
metadata:
  title: Scoop in Canva
  description: >-
    Integrate live Scoop charts, graphs and tables into Canva presentations
    for dynamic, always-updated visual content.
  robots: index
next:
  description: ''
---
## Steps to Embed Scoop Analytics Visuals in Canva

### Step 1: Log into Your Accounts

<br />

1. Log into Canva: Open Canva and log into your account.
2. Access Scoop Analytics app: From the left hand panel at Canva homepage, click on apps and search for Scoop.

<Image align="center" className="border" border={true} src="https://files.readme.io/88bbc6dc88bb70a8e54d5363804cc846681b9531da6302e09e35cbe34f648ecb-ScoopAppSearch.JPG" />

### Step 2: Open or Create a Presentation in Canva

<Image align="center" className="border" border={true} src="https://files.readme.io/276a835164d97ab5f67ebc884abaade5be76bf1fc27dd91a2f3e877007cd8a35-ScoopPopUp.JPG" />

From the **prompt**,\
click on **Use in existing design** to choose existing Canva presentation you wish to leverage Scoop. or\
Choose **Use in new design** to leverage Scoop in a new presentation.

<br />

### Step 3: Access the Scoop App within Canva

<br />

1. If this is your first time using Scoop within Canva, you will be prompted to connect Scoop Analytics where users can enter their email and an account will be created.
2. Follow the on-screen instructions to log in to Scoop and authorize the integration.

<Image align="center" className="border" border={true} src="https://files.readme.io/6abe714080e2c6e1a23b95d431e9b8778ea22a24326dcce94d4a466c5d0ae542-ScoopLogin.JPG" />

### Step 5: Select and Insert Data Visuals

<br />

1. Once connected, select the Scoop workspace and you will see a list of available Scoop Analytics objects such as charts, graphs, and KPIs. 

*(Canva Tour is a sample workspace which is prebuilt and a first time user can try that out. )*

<Image align="center" className="border" border={true} src="https://files.readme.io/c168581fba157630becbf22d557ddd5b26f79b9bf07a2afdff583ce0e26c5d07-ScoopSelectWorkspace.JPG" />

<br />

2. Browse through the available objects and select the data visual you want to embed into your presentation.
3. Single Click to select the object.

<Image align="center" className="border" border={true} src="https://files.readme.io/19d66cca8a9e1c49b3cfe48243fa7054436a401debb8466d0c9d64814c075f67-ScoopChartEmbed1.JPG" />

<br />

### Step 6: Customize the Visual in Canva

<br />

1. After the object is embedded into your presentation, you can customize its appearance within Canva. You can resize, move, or add additional design elements to suit your presentation style.
2. Canva will maintain the live data connection, so any updates made to the data object in Scoop will be reflected in your presentation.
3. You can add filters to the design using the prompts section under scoop.

<br />

### Step 7: Presentation mode

<br />

1. Once you have completed the design and added all necessary data visuals, click on Present to have an interactive presentation mode. Scoop objects are fully interactive and drillable even in presentation mode.

<Image align="center" className="border" border={true} src="https://files.readme.io/9968d814ef27381ce17cdce9e736c9af6c2a541a51a18d67326269390b15a4d7-Presentation.jpg" />

<br />

2. Filters added to the presentation are dynamic and can be applied in the presentation mode.

<Image align="center" className="border" border={true} src="https://files.readme.io/172bb03077fff82c2a2a983de3447dd4a4155748fbbe26d49b6b9337d927d1bc-Filters.jpg" />

<br />

3. You can download this or also share the presentation directly with others via a link or collaborate in real-time with team members.

# Adding Custom Data Visuals to Canva Presentations

To include your own custom datasets and visuals in their Canva presentation, you can use the 'Create Canvas' feature within the Scoop app integration. This functionality allows users to design unique visuals in Scoop and seamlessly incorporate them into Canva presentations.

## Steps to Create and Add Custom Visuals:

<br />

1. **Access the "Create Canvas" Feature:**\
   o	Open the Scoop app plugin within Canva.\
   o	Locate the button labeled "Create Canvas" in the Scoop app interface.

<Image align="center" className="border" border={true} src="https://files.readme.io/125e35fab2fb484eb1a4e5f0af55b72624aa942ea23e48de30ed74d406087719-CreateCanvas.JPG" />

<br />

<br />

2. **Design Custom Visuals in Scoop Analytics:**
   * Clicking on the "Create Canvas" button will redirect you to the Scoop Analytics platform where a user has been already created for you.

<Image align="center" className="border" border={true} src="https://files.readme.io/d6bc8aa4a8deac78e446a1efbc411f1e7f236c54c9cd3202142d78e24c1761d7-OpenCanva.JPG" />

Within Scoop Analytics, user can:

* Add custom datasets

<Image align="center" className="border" border={true} src="https://files.readme.io/2f18348fc098a3c63ef89c5b97c5e8e1a4c809a1b16a88d3a81271733c76cf53-Scoop_Data.JPG" />

* Create various visualizations such as charts, graphs, or tables.

<Image align="center" className="border" border={true} src="https://files.readme.io/5e8745b861cd9fbea6e67c8e445b831068ce6dffd34cfa86b6b5dddfeb6c79f4-Scoop_Explorer_1.JPG" />

* Save these visualizations as a Scoop Summary.

For more information on how to start using Scoop follow [Scoop Quickstart Guide](https://docs.scoopanalytics.com/docs/scoop-quickstart-guide)

* User can then create a Scoop Canvas utilizing all the visuals created using custom datasets. canvas is fully interactive, drillable and is always updated with the latest data.

For more information on Canvas : [Scoop Canvas](https://docs.scoopanalytics.com/docs/what-is-a-canvas-and-what-can-it-do)

<br />

<br />

3. Share Custom Canvases to Canva:

* Once your Canvas is ready, it can be access directly back to the Canva app.
* The custom visuals will now be available for embedding into your presentation, just like the pre-existing Scoop Analytics objects.

3. Customize in Canva:

* Once imported, these visuals can be resized, styled, and integrated with other design elements in Canva.

<br />

By leveraging this feature, you can ensure that your presentations include tailored and interactive data insights that cater to specific business needs.

By embedding live Scoop Analytics visuals directly into Canva presentations, you can ensure that your business presentations are always up-to-date with the latest data insights. This seamless integration between Scoop and Canva makes it easier for users to create professional, data-driven presentations without leaving the Canva platform.
