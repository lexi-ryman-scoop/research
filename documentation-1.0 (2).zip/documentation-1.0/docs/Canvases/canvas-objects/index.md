---
title: Canvas Objects
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Canvas Objects
  description: >-
    This document explains how to use the toolbar in Scoop canvas edit mode to
    add different elements such as data charts, sheetlets, process diagrams,
    frames, visual objects like rich text boxes, arrows, images, and videos. It
    also allows for editing frames and wrappers, capturing thumbnails, changing
    background colors, and managing frames for the canvas.
  robots: index
next:
  description: ''
---
To add different elements to a Scoop canvas, you use the toolbar that appears on the left in canvas edit mode:

<Image align="center" width="50px" src="https://files.readme.io/ed454a7-image.png" />

<br />

The following are the different types of objects that can be placed onto a Scoop canvas in the order that they appear in the toolbar:

* Scoop Summary (data charts or tables)\
  These objects are created with Scoop Explorer, where you can create great chart or table visualizations and summaries of datasets
* Sheetlets\
  These elements display open windows into Scoop LiveSheets. You can name a range in your spreadsheet and then display that on a canvas. The sheetlet is bi-directional. If you change a value in a cell in a sheetlet, it is updated in the underlying LiveSheet. That means any calculations based on that LiveSheet will automatically be recalculated allowing for very rich and interactive calculations.
* Process Diagram
* Frame
* Visual Object
  * Rich text box: A powerful rich text editor that allows you to edit/format text objects. You can, among other things:
    * Change font style (bold, italic, underline, font size, color, background and many other items
    * Justify text (left, center, or right)
    * Change line spacing and indentation and other paragraph options
    * Insert hyperlinks, images or tables
  * Arrows: You can draw arrows on your canvas to highlight specific elements as part of your story
  * Images: You can embed images into your canvas
  * Videos: You can embed videos into your canvas

In addition, the toolbar allows you to do the following:

* Edit the frame and wrapper of either individual objects or all of them to apply things like background colors and borders.
* Turn snap to grid on or off
* Capture a thumbnail based on the current view of the canvas (you can also select a single frame and make it a thumbnail)
* Change the background color of the entire canvas
* Manage the current frames for the canvas
  * Change their presentation order
  * If they were created from a slide import, you can edit the slide in Google slides and update your frame with any changes made either on a single slide or all of your slides. This allows you to continue to use Google Slides as a slide editor for your frame backround.
