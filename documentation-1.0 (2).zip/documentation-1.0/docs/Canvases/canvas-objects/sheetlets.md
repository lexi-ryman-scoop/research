---
title: Sheetlets
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Sheetlets
  description: >-
    Sheetlets are interactive objects that display and allow live editing of
    worksheet data on a canvas, updating all related elements in real-time and
    enabling dynamic, visually compelling presentations.
  robots: index
next:
  description: ''
---
Sheetlets are objects that you can place on a canvas that open up a window into one of your worksheets. Essentially you can provide a named range in your worksheet, or a worksheet, and make that visible and editable live on your canvas. Any calculations including any charts or other sheetlets that are based on that worksheet will automatically update in realtime when you make changes. This gives you essentially an infinite spreadsheet to work with with portals into it anywhere you like on your canvas.

![](https://files.readme.io/7a12323-image.png)

So, if the chart in this example is based on the revenue and expense lines in the worksheet, if I change my margin say from 80% above, to 60% (simply by clicking on the cell and changing the value just like a spreadsheet), then all the other canvas elements update immediately.

![](https://files.readme.io/3474da2-image.png)Sheetlets have extensive formatting options including transparent backgrounds allowing you to create extremely compelling interactive presentations.![](https://files.readme.io/b712c5f-image.png)

# Sheetlet Capabilities

Sheetlets are a full portal into your underlying Live Worksheet. You can take any named range from a Live Worksheet and display it on a canvas. When you click into it, the cells are editable, including formulas. Behind the scenes Scoop maintains a complete instance of your Live Worksheet in memory while you are using it. When you change a value, it is immediately relayed to Scoop in the cloud and the underlying values are updated and any changes are relayed to any other Canvas objects that may rely on that Scoop Live Sheet. In effect, Scoop frees you from using your worksheet only in your spreadsheet tool (although you can still edit your Livesheets there), and allows you to leverage windows into it anywhere you might need them. Scoop therefore allows you to build live, interactive spreadsheet applications that are driven by live application data.
