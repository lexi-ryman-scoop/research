---
title: Prompts
excerpt: 'Add dynamic filter controls to your canvas'
deprecated: false
hidden: false
metadata:
  title: Prompts
  description: >-
    Add prompt controls to your Scoop canvas for dynamic filtering. Users select
    values to filter charts, tables, and KPIs. Enable personalized dashboards.
  robots: index
next:
  description: ''
---

Prompts add filter controls to your canvas, letting users dynamically change what data they see. Instead of creating separate dashboards for each region, product, or time period, create one canvas with prompts that adapt to each user's needs.

![](https://files.readme.io/ef8e20279635ad07c6faa6cf68aded064d1cb5b915743b66789e84f509f6f562-image.png)

# Types of Prompts

| Prompt Type | Description | Use Case |
|-------------|-------------|----------|
| **Single Select** | Choose one value from a list | Region, Product Line, Manager |
| **Multi-Select** | Choose multiple values | Select multiple regions or products |
| **Date Picker** | Select a date or date range | Time period filtering |
| **Text Input** | Enter a search value | Customer name, ID lookup |

# Adding a Prompt

1. Open your canvas in edit mode
2. Click **+ Add** from the left toolbar
3. Select **Prompt**
4. Click where you want to place the prompt
5. Configure the prompt settings

# Configuring Prompts

## Setting the Data Source

Prompts can pull their values from:

| Source | Description | Best For |
|--------|-------------|----------|
| **Scoop Dataset** | Values from a column in your data | Dynamic, auto-updating lists |
| **Named Range** | Values from a spreadsheet range | Static lists, custom ordering |

**From a Dataset:**
1. Select the dataset containing your filter values
2. Choose the column to use for prompt options
3. Values automatically update as your data changes

**From a Named Range:**
1. Select a Live Worksheet
2. Choose the named range with your values
3. Edit the spreadsheet to add/remove options

## Linking Elements to Prompts

After configuring the prompt, link it to canvas elements:

1. Select an element (chart, table, KPI) on your canvas
2. Click the **Link** icon (chain) in the element's toolbar
3. Connect the element to the prompt
4. Specify which column the prompt should filter

**Example:**
- Prompt: Region selector
- Chart: Revenue by Product
- Link: Filter chart's "Region" column by prompt selection

## Multiple Linked Elements

A single prompt can control multiple elements:

```
┌─────────────────────────────────────────┐
│  [Region Prompt: ▼ West              ]  │
├───────────────────┬─────────────────────┤
│ Revenue by Month  │  Pipeline by Stage  │
│   (filtered)      │    (filtered)       │
├───────────────────┼─────────────────────┤
│ Rep Performance   │   Deal List         │
│   (filtered)      │    (filtered)       │
└───────────────────┴─────────────────────┘
```

All four elements update when the user changes the region.

# Prompt Interactions

## User Experience

When viewing a canvas with prompts:

1. Click the prompt dropdown or selector
2. Choose one or more values
3. All linked elements instantly update
4. Selection persists while viewing the canvas

## Default Values

Set a default selection for prompts:

- **No default:** User must make a selection
- **Specific value:** Pre-select a common choice
- **All values:** Start with complete data

## Prompt Dependencies

Create cascading prompts where one affects another:

**Example:**
- First prompt: Region
- Second prompt: Shows only reps in selected region

This prevents invalid combinations and improves UX.

# Common Prompt Patterns

## Executive Dashboard

```
Prompts: [Quarter ▼] [Region ▼] [Product Line ▼]

KPIs:     Revenue    Pipeline    Win Rate    Deals
Charts:   Trend      Funnel      Comparison
Tables:   Top Deals  Rep Leaderboard
```

## Sales Manager View

```
Prompts: [My Team ▼] [Date Range ▼]

KPIs:     Team Revenue  Quota Attainment
Charts:   Rep Performance  Pipeline Coverage
Tables:   Deals to Close This Month
```

## Customer Success

```
Prompts: [Customer Segment ▼] [Health Score ▼]

KPIs:     Active Customers  Churn Risk  Expansion
Charts:   Engagement Trend  Feature Usage
Tables:   At-Risk Accounts
```

# Sharing with Preset Prompts

When sharing a canvas with specific users, you can preset their prompt values:

## Personalized Access

1. Share the canvas with "Invitation Only"
2. Enable "Restrict Access with Prompts"
3. For each invitee, set their prompt values
4. They see only their filtered data

<Image align="center" width="400px" src="https://files.readme.io/2cb54bd-image.png" />

**Example:**
- Share with West region manager → Region prompt locked to "West"
- Share with East region manager → Region prompt locked to "East"
- Both see the same canvas, different data

## Security Implications

Preset prompts provide:
- Data isolation between users
- No ability to see other regions/segments
- Single canvas serves multiple audiences

See [Sharing a Presentation](../sharing-a-canvas) for complete sharing options.

# Best Practices

## Prompt Placement

- Position prompts at the top of your canvas
- Group related prompts together
- Make prompts visible without scrolling

## Naming

- Use clear, descriptive labels
- Match terminology to your organization
- Add helper text if needed

## Performance

- Limit the number of linked elements
- Use indexed columns for filtering
- Consider default filters to reduce initial load

## Mobile Considerations

- Prompts work on mobile devices
- Use single-select for touch interfaces
- Test prompt interactions on smaller screens

# Troubleshooting

## Prompt Shows No Values

- Verify the source dataset has synced
- Check that the source column contains data
- Confirm the named range reference is correct

## Element Doesn't Filter

- Verify the element is linked to the prompt
- Check that the link specifies the correct column
- Ensure column names match between prompt and element

## Wrong Values Displayed

- Check if other prompts are also filtering
- Verify the filter logic (AND vs OR)
- Look for case sensitivity issues

## Prompt Resets Unexpectedly

- Check for canvas reload/refresh
- Verify sharing settings
- Look for conflicting prompt defaults

# Related Topics

- [Interactive Charts and Tables](interactive-charts-and-tables) - Elements that prompts control
- [Sheetlets](sheetlets) - Spreadsheet data on canvas
- [Sharing a Presentation](../sharing-a-canvas) - Preset prompts for users
- [Presenting a Canvas](../presenting-a-canvas) - Live presentations with prompts
