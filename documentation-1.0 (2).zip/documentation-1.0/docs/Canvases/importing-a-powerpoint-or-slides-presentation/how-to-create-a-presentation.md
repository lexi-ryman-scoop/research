---
title: How to Create a Presentation
excerpt: Build live data presentations that update automatically
deprecated: false
hidden: false
metadata:
  title: How to Create a Presentation
  description: >-
    Learn how to create presentations in Scoop Analytics. Build slide decks with
    live data that update automatically when your underlying data refreshes.
  robots: index
next:
  description: ''
---

<Embed url="https://www.youtube.com/watch?v=So_OhGtdtc0" title="How to create a presentation" favicon="https://www.youtube.com/favicon.ico" image="https://i.ytimg.com/vi/So_OhGtdtc0/hqdefault.jpg" provider="youtube.com" href="https://www.youtube.com/watch?v=So_OhGtdtc0" typeOfEmbed="youtube" html="%3Ciframe%20class%3D%22embedly-embed%22%20src%3D%22%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Fsrc%3Dhttps%253A%252F%252Fwww.youtube.com%252Fembed%252FSo_OhGtdtc0%253Ffeature%253Doembed%26display_name%3DYouTube%26url%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253DSo_OhGtdtc0%26image%3Dhttps%253A%252F%252Fi.ytimg.com%252Fvi%252FSo_OhGtdtc0%252Fhqdefault.jpg%26type%3Dtext%252Fhtml%26schema%3Dyoutube%22%20width%3D%22640%22%20height%3D%22480%22%20scrolling%3D%22no%22%20title%3D%22YouTube%20embed%22%20frameborder%3D%220%22%20allow%3D%22autoplay%3B%20fullscreen%3B%20encrypted-media%3B%20picture-in-picture%3B%22%20allowfullscreen%3D%22true%22%3E%3C%2Fiframe%3E" />

## Overview

Scoop presentations (Canvases) combine the polish of PowerPoint with the power of live data. Create beautiful slide decks that automatically update when your data refreshes, eliminating manual copy-paste and ensuring stakeholders always see current numbers.

## Why Scoop Presentations?

| Traditional Approach | Scoop Presentations |
|---------------------|---------------------|
| Export data to Excel | Data stays connected |
| Copy charts to PowerPoint | Charts update automatically |
| Manually update each week | One-time setup, always current |
| Risk of stale numbers | Live data guarantee |

## Step-by-Step Guide

### Step 1: Create a New Canvas

1. Click **New** in the left sidebar
2. Select **Canvas / Presentation**
3. Choose a starting point:
   - **Blank canvas**: Start from scratch
   - **Import template**: Use your company's PowerPoint/Slides template
   - **Duplicate existing**: Copy and modify a previous presentation

### Step 2: Set Up Your Slides

Add slides using the **+** button in the slide panel. Each slide can contain:

- **Charts**: Live visualizations from your data
- **KPIs**: Prominent single-number displays
- **Tables**: Data grids with formatting
- **Text**: Titles, bullets, commentary
- **Images**: Logos, icons, screenshots
- **Shapes**: Boxes, lines, callouts

### Step 3: Add Live Data Elements

To add a chart or KPI:

1. Click **Insert** in the toolbar
2. Choose **Chart** or **KPI**
3. Select from your saved library, or create new
4. Position and resize on the slide

The data connection is maintained, so when your dataset refreshes, the chart updates automatically.

### Step 4: Style Your Presentation

Customize the look:

- **Background colors**: Match your brand
- **Fonts**: Use company typography
- **Layout**: Arrange elements with guides and snapping
- **Themes**: Apply consistent styling across slides

### Step 5: Add Context

Make your data tell a story:

- **Titles**: What is this slide about?
- **Annotations**: Call out key insights
- **Commentary**: Add narrative text explaining the "so what"
- **Comparisons**: Show vs. targets or previous periods

## Importing PowerPoint/Slides Templates

Scoop can use your existing templates:

1. Click **Import Template** when creating a canvas
2. Upload your .pptx or .slides file
3. Scoop preserves:
   - Slide layouts
   - Backgrounds and colors
   - Logo placements
   - Font styles
4. Add Scoop's live data elements on top

## Presenting and Sharing

### Present Live

Click **Present** to enter full-screen presentation mode. All data shows current values.

### Export Options

| Format | Use Case |
|--------|----------|
| **PDF** | Static snapshot for email/archive |
| **PowerPoint** | Edit further in Office apps |
| **Link** | Share live view with stakeholders |
| **Scheduled Email** | Auto-send weekly/monthly updates |

### Collaborate

- **Share with workspace**: All members can view/edit
- **Viewer mode**: Allow view-only access
- **Comments**: Add feedback on specific slides

## Best Practices

- **One insight per slide**: Don't overcrowd
- **Lead with the headline**: State the conclusion first
- **Use consistent layouts**: Makes decks easier to follow
- **Test with real data**: Ensure charts look good with actual values
- **Schedule updates**: Data should refresh before important meetings

## What's Next?

- Learn more about [importing templates](index)
- Create [charts](../../Exploring%20and%20Visualizing%20Data/chart-types/how-to-create-a-chart) for your presentation
- Add [KPIs](../../Exploring%20and%20Visualizing%20Data/creating-kpis/how-to-create-a-kpi) for executive summaries
