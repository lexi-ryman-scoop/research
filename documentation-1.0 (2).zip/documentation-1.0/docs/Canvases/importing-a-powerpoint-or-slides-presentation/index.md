---
title: Importing a Powerpoint or Slides Presentation
excerpt: 'Transform static slides into live, data-driven presentations'
deprecated: false
hidden: false
metadata:
  title: Importing PowerPoint Presentations
  description: >-
    Import PowerPoint or Google Slides into Scoop to create live data presentations
    with interactive visualizations layered on your existing slides.
  robots: index
next:
  description: ''
---

Transform your existing PowerPoint presentations into live, data-driven canvases. Scoop imports your slides while preserving formatting, then lets you layer interactive visualizations directly on top—creating presentations that update automatically with fresh data.

# Why Import Presentations?

| Benefit | Description |
|---------|-------------|
| **Preserve branding** | Keep your company's slide templates and styling |
| **Add live data** | Layer real-time charts and KPIs on familiar slides |
| **Reduce maintenance** | One source updates automatically |
| **Enable interactivity** | Drill into data during presentations |
| **Collaborate in Google Slides** | Edit content in either platform |

# Importing a Presentation

## Step 1: Start Import

1. Go to the Canvas Navigator
2. Click **New Canvas**
3. Select **Canvas from Presentation**

<Image align="center" width="400px" src="https://files.readme.io/1a40af7-image.png" />

## Step 2: Upload Your File

Upload a `.pptx` file from your computer. Scoop imports:

| Element | Preserved? |
|---------|-----------|
| Master slides | ✅ Yes |
| Layouts | ✅ Yes |
| Backgrounds | ✅ Yes |
| Images | ✅ Yes |
| Diagrams | ✅ Yes |
| Text | ✅ Yes |
| Tables | ✅ Yes |
| Animations | ❌ Not supported |
| Embedded videos | ❌ Re-add in Scoop |

## Step 3: Review Results

After import:
- Each PowerPoint slide becomes a Scoop frame
- A Google Slides copy is created automatically
- Color themes are extracted for use in visualizations

# Working with Imported Slides

## Slides as Backgrounds

Imported slides serve as backgrounds for your frames. You can:
- Edit text directly in Scoop
- Move and resize elements
- Delete unnecessary items
- Add Scoop visualizations on top

## Adding Live Data

Layer Scoop elements over your slides:

```
┌─────────────────────────────────────────────┐
│ Your imported PowerPoint slide (background) │
│  ┌──────────────────┐  ┌────────────────┐   │
│  │  Scoop Chart     │  │   Scoop KPI    │   │
│  │  (live data)     │  │   (live data)  │   │
│  └──────────────────┘  └────────────────┘   │
│                                             │
│  [Original slide text and graphics]         │
└─────────────────────────────────────────────┘
```

Elements you can add:
- Charts and tables from your datasets
- KPI summaries with real-time values
- Sheetlets from Live Worksheets
- Prompts for filtering

## Editing in Google Slides

Every imported presentation syncs with Google Slides:

1. Open **Manage Frames** in Scoop
2. Click the link next to any slide to open it in Google Slides
3. Edit in Google Slides
4. Sync changes back to Scoop

<Image align="center" width="350px" src="https://files.readme.io/d22234a-image.png" />

# Managing Frames

The **Manage Frames** window provides:

| Feature | Description |
|---------|-------------|
| **Google Slides link** | Open each slide directly in Google Slides |
| **Hide/Unhide** | Show or hide slides in presentation |
| **Synchronize** | Pull latest changes from Google Slides |
| **Reorder** | Change slide sequence |
| **Delete** | Remove individual frames |

## Synchronizing Changes

To update slides from Google Slides:

1. Make edits in Google Slides
2. Open Manage Frames in Scoop
3. Select slides to synchronize
4. Click **Sync Selected**
5. Scoop re-imports those slides with your changes

**Note:** Synchronization replaces the slide background—any Scoop elements you've added remain in place.

# Color Theme Import

Scoop extracts color themes from your presentation:

## Automatic Import

Colors from your PowerPoint theme are available for:
- Chart colors
- KPI backgrounds
- Text highlighting
- Shape fills

## AI-Generated Colors

Scoop also analyzes your presentation and suggests complementary colors using AI. See [AI Generated Color Themes](ai-generated-color-themes) for details.

## Using Imported Colors

When creating visualizations:
1. Open the color picker
2. Look for "Presentation Colors" section
3. Select colors that match your slides

# Best Practices

## Before Import

- **Simplify complex animations** — They won't transfer
- **Use standard fonts** — Or ensure fonts are available
- **Optimize images** — Large images slow loading
- **Consider layout** — Leave space for data elements

## After Import

- **Add visualizations strategically** — Don't overcrowd
- **Use consistent placement** — Data in same location across slides
- **Test interactivity** — Ensure drilling works
- **Verify colors match** — Adjust if needed

## For Ongoing Updates

- **Edit in Google Slides** — For slide content changes
- **Edit in Scoop** — For data visualization changes
- **Sync regularly** — Keep both platforms in sync
- **Document which slides have data** — For team awareness

# Common Workflows

## Monthly Report Updates

1. Import standard monthly template once
2. Add live data visualizations
3. Data updates automatically each month
4. Sync template changes from Google Slides as needed

## Executive Presentations

1. Import branded executive template
2. Add KPIs and charts with live data
3. Present with current numbers
4. Drill into details during Q&A

## Sales Decks

1. Import sales presentation template
2. Add pipeline and performance charts
3. Customize per client with prompts/filters
4. Share with preset filters for each region

# Troubleshooting

## Fonts Look Different

- Check if fonts are web-safe or installed
- Consider using standard fonts in original
- Scoop substitutes unavailable fonts

## Images Not Displaying

- Verify images were embedded, not linked
- Check image file sizes
- Re-add problematic images in Scoop

## Layout Shifted

- Complex layouts may need adjustment
- Use Scoop's alignment tools
- Consider simplifying original slides

## Colors Don't Match

- Check color theme was imported
- Verify using RGB values
- Manually set colors if needed

# Related Topics

- [AI Generated Color Themes](ai-generated-color-themes) - Automatic color matching
- [What is a Canvas](../what-is-a-canvas-and-what-can-it-do) - Canvas overview
- [Presenting a Canvas](../presenting-a-canvas) - Presentation mode
- [Drawing Objects](../canvas-objects/drawing-objects) - Adding visual elements
