---
title: Sharing a Presentation
excerpt: 'Share live, interactive dashboards with your team and stakeholders'
deprecated: false
hidden: false
metadata:
  title: Sharing a Presentation
  description: >-
    Share Scoop canvases as live, interactive presentations. Options for private,
    invitation-only, or public access with personalized data filtering.
  robots: index
next:
  description: ''
---

Sharing in Scoop goes far beyond sending a static deck. When you share a canvas, you're providing a live, interactive data application that updates automatically and lets viewers explore, drill, and filter—all in their browser.

# Sharing Options

Click the **Share** icon in the upper right of your canvas to open the sharing dialog:

<Image align="center" width="400px" src="https://files.readme.io/174a161-image.png" />

| Mode | Access | Authentication | Best For |
|------|--------|----------------|----------|
| **Private** | Only you | Your login | Development, personal use |
| **Invitation Only** | Specific people | Scoop account | Teams, sensitive data |
| **Anyone with Link** | Anyone | None | Public dashboards, embedding |

# Private Sharing

Private links are accessible only to you:

- Use for work-in-progress dashboards
- Test changes before publishing
- Personal reference dashboards

**When to use:** You're the only one who needs to see this canvas.

# Invitation-Only Sharing

Share with specific people who have Scoop accounts:

## Setting Up Invitations

1. Select "Invitation Only"
2. Enter email addresses of invitees
3. Optionally set prompt restrictions (see below)
4. Send invitations

## User Experience

Invitees receive an email with:
- Link to the canvas
- Instructions to log in (or create account)
- Any preset filters applied

## Access Management

- Add or remove users anytime
- Track who has accessed
- Revoke access immediately if needed

**When to use:** Sensitive business data, team dashboards, client portals.

# Public Sharing (Anyone with Link)

Create a public URL that anyone can access:

- No authentication required
- Works in any browser
- Embeddable in websites
- Shareable via email, Slack, etc.

## Security Considerations

Public links expose your data:
- Filter to only what should be public
- Don't include sensitive customer data
- Consider using prompts to limit scope
- Monitor link usage

**When to use:** Marketing dashboards, public reports, website embedding.

# Personalized Data with Prompts

The most powerful sharing feature: give each person their own filtered view of the same canvas.

## How It Works

1. Create a canvas with prompts (e.g., Region selector)
2. Share with "Invitation Only"
3. Enable "Restrict Access with Prompts"
4. Set each invitee's prompt values

<Image align="center" width="400px" src="https://files.readme.io/2cb54bd-image.png" />

## Example: Regional Sales Managers

**Canvas:** Company-wide sales dashboard with Region prompt

| Invitee | Preset Prompt | What They See |
|---------|---------------|---------------|
| Sarah (West) | Region = West | Only West data |
| Mike (Central) | Region = Central | Only Central data |
| Lisa (East) | Region = East | Only East data |
| CEO | No restriction | All regions |

## Benefits

- **Single canvas:** Maintain one dashboard for everyone
- **Data security:** Users can't see other segments
- **Personalization:** Each person sees relevant data
- **Efficiency:** No duplicate dashboards to maintain

# Interactive Features When Shared

Shared canvases remain fully interactive:

| Feature | Works When Shared? |
|---------|-------------------|
| Drill down on charts | Yes |
| Filter with prompts | Yes (unless locked) |
| Edit sheetlet values | Yes |
| View updated data | Yes (real-time) |
| Export data | Configurable |
| Print/screenshot | Yes |

## Live Data Updates

Shared viewers always see current data:
- Data syncs overnight (or more frequently)
- No need to re-share after updates
- Viewers see changes automatically

# Embedding in Websites

Public canvas links can be embedded:

```html
<iframe
  src="https://app.scoopanalytics.com/canvas/YOUR_CANVAS_ID"
  width="100%"
  height="600px"
  frameborder="0">
</iframe>
```

## Embedding Best Practices

- Size the iframe appropriately
- Consider mobile responsiveness
- Test interactivity within iframe
- Monitor public link usage

# Sharing Best Practices

## Before Sharing

1. **Review data:** Ensure nothing sensitive is exposed
2. **Test prompts:** Verify filters work correctly
3. **Check permissions:** Confirm invitee email addresses
4. **Preview:** View as each user type to verify experience

## Naming and Organization

- Use descriptive canvas names
- Include date or version if relevant
- Organize canvases into workspaces by audience

## Communication

When sharing, tell recipients:
- What the dashboard shows
- How often data updates
- How to use interactive features
- Who to contact with questions

## Monitoring

For shared canvases:
- Track who accesses
- Monitor engagement
- Gather feedback
- Update based on usage

# Managing Shared Canvases

## Updating Content

Changes to a shared canvas appear immediately:
- Add/remove elements
- Update data sources
- Modify prompts
- Viewers see changes on refresh

## Revoking Access

To remove access:
1. Open sharing settings
2. Remove individual users, or
3. Change sharing mode to Private

## Versioning

For major changes:
- Consider duplicating the canvas first
- Share new version when ready
- Archive old versions

# Troubleshooting

## Invitee Can't Access

- Verify email address is correct
- Confirm they have a Scoop account
- Check if invitation was sent
- Resend invitation if needed

## Data Not Updating

- Verify dataset sync is running
- Check for errors in data source
- Confirm viewer is refreshing the page

## Prompt Restrictions Not Working

- Verify prompts are linked to elements
- Check preset values are correct
- Test as the invited user

## Link Not Working

- Confirm sharing mode is correct
- Check if link was copied correctly
- Verify canvas still exists

# Related Topics

- [Presenting a Canvas](presenting-a-canvas) - Live presentation mode
- [Prompts](canvas-objects/prompts) - Add filter controls
- [Interactive Charts and Tables](canvas-objects/interactive-charts-and-tables) - Drillable visualizations
- [What is a Canvas](what-is-a-canvas-and-what-can-it-do) - Canvas overview
