---
title: How to Save a KPI
excerpt: Save your KPIs for dashboards and automated reporting
deprecated: false
hidden: false
metadata:
  title: How to Save a KPI
  description: >-
    Learn how to save KPIs in Scoop Analytics for reuse in dashboards, presentations,
    and automated reporting workflows.
  robots: index
next:
  description: ''
---

<Embed url="https://www.youtube.com/watch?v=8FXoJCI5iys" title="How to save a KPI in Scoop" favicon="https://www.youtube.com/favicon.ico" image="https://i.ytimg.com/vi/8FXoJCI5iys/hqdefault.jpg" provider="youtube.com" href="https://www.youtube.com/watch?v=8FXoJCI5iys" typeOfEmbed="youtube" html="%3Ciframe%20class%3D%22embedly-embed%22%20src%3D%22%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Fsrc%3Dhttps%253A%252F%252Fwww.youtube.com%252Fembed%252F8FXoJCI5iys%253Ffeature%253Doembed%26display_name%3DYouTube%26url%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253D8FXoJCI5iys%26image%3Dhttps%253A%252F%252Fi.ytimg.com%252Fvi%252F8FXoJCI5iys%252Fhqdefault.jpg%26type%3Dtext%252Fhtml%26schema%3Dyoutube%22%20width%3D%22640%22%20height%3D%22480%22%20scrolling%3D%22no%22%20title%3D%22YouTube%20embed%22%20frameborder%3D%220%22%20allow%3D%22autoplay%3B%20fullscreen%3B%20encrypted-media%3B%20picture-in-picture%3B%22%20allowfullscreen%3D%22true%22%3E%3C%2Fiframe%3E" />

## Overview

After [creating a KPI](how-to-create-a-kpi), save it to your library for reuse across dashboards and presentations. Saved KPIs automatically update when your data refreshes, keeping your metrics current without manual effort.

## Step-by-Step Guide

### Step 1: Configure Your KPI

Make sure your KPI displays exactly what you want:
- Correct metric and aggregation
- Appropriate filters applied
- Comparison period set (if desired)
- Formatting finalized

### Step 2: Click Save

Click the **Save** button in the KPI toolbar.

### Step 3: Name Your KPI

Give your KPI a clear, descriptive name:

**Good names:**
- "Monthly Revenue"
- "Active Customers Count"
- "Avg Deal Size (Enterprise)"

**Avoid:**
- "KPI 1"
- "New metric"
- Overly long descriptions

### Step 4: Choose Location

Select where to save:

- **Personal Library**: Private to you
- **Workspace Library**: Visible to all workspace members
- **Directly to Presentation**: Add to an existing canvas

### Step 5: Confirm and Save

Click **Save** to finalize. Your KPI is now available for reuse.

## Managing Saved KPIs

### Find Your KPIs

Access saved KPIs from:
- The **KPI Library** in the left sidebar
- The **Insert** menu when editing a canvas
- Your **Personal Assets** section

### Edit a Saved KPI

1. Open the KPI from your library
2. Modify the configuration
3. Click **Save** to update (or **Save As** for a new version)

### Duplicate a KPI

Create variations quickly:
1. Right-click the saved KPI
2. Select **Duplicate**
3. Rename and modify as needed

### Delete a KPI

1. Right-click the KPI in your library
2. Select **Delete**
3. Confirm removal

## Live Updates

Saved KPIs stay current automatically:

| Data Refresh | KPI Behavior |
|--------------|--------------|
| Daily sync | KPI shows yesterday's data |
| Hourly sync | KPI updates every hour |
| Real-time | KPI reflects latest data |

Filters like "This Month" or "Last 7 Days" automatically roll forward as time passes.

## Using Saved KPIs

### In Presentations

Drag KPIs from your library onto any canvas slide. They'll display as prominent, styled number cards.

### In Dashboards

Combine multiple KPIs at the top of a dashboard for an executive summary view.

### In Scheduled Reports

Include saved KPIs in automated email reports. Recipients see the current values at send time.

## Best Practices

- **Standardize naming**: Use consistent patterns like "{Metric} - {Filter}"
- **Document filters**: Add notes if the KPI has non-obvious filters
- **Review periodically**: Archive KPIs no longer in use
- **Share wisely**: Workspace KPIs should have broad relevance

## What's Next?

- Create [charts](../chart-types/how-to-create-a-chart) to complement your KPIs
- Build a [presentation](../../Canvases/importing-a-powerpoint-or-slides-presentation/how-to-create-a-presentation) with your saved assets
