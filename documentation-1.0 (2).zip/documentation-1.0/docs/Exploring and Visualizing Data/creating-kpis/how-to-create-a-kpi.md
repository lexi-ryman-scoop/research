---
title: How to Create a KPI
excerpt: Display key metrics as prominent, easy-to-read numbers
deprecated: false
hidden: false
metadata:
  title: How to Create a KPI
  description: >-
    Learn how to create KPI (Key Performance Indicator) displays in Scoop Analytics.
    Show important metrics as large, prominent numbers with optional comparisons.
  robots: index
next:
  description: ''
---

<Embed url="https://www.youtube.com/watch?v=Pi4N147DZFU" title="How to create a KPI in Scoop" favicon="https://www.youtube.com/favicon.ico" image="https://i.ytimg.com/vi/Pi4N147DZFU/hqdefault.jpg" provider="youtube.com" href="https://www.youtube.com/watch?v=Pi4N147DZFU" typeOfEmbed="youtube" html="%3Ciframe%20class%3D%22embedly-embed%22%20src%3D%22%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Fsrc%3Dhttps%253A%252F%252Fwww.youtube.com%252Fembed%252FPi4N147DZFU%253Ffeature%253Doembed%26display_name%3DYouTube%26url%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253DPi4N147DZFU%26image%3Dhttps%253A%252F%252Fi.ytimg.com%252Fvi%252FPi4N147DZFU%252Fhqdefault.jpg%26type%3Dtext%252Fhtml%26schema%3Dyoutube%22%20width%3D%22640%22%20height%3D%22480%22%20scrolling%3D%22no%22%20title%3D%22YouTube%20embed%22%20frameborder%3D%220%22%20allow%3D%22autoplay%3B%20fullscreen%3B%20encrypted-media%3B%20picture-in-picture%3B%22%20allowfullscreen%3D%22true%22%3E%3C%2Fiframe%3E" />

## Overview

KPIs (Key Performance Indicators) are single-number displays that highlight your most important metrics. Unlike charts that show trends or comparisons, KPIs present one prominent value, making them perfect for executive dashboards and at-a-glance reporting.

## When to Use a KPI

KPIs work best when you need to answer questions like:

- "What's our total revenue this month?"
- "How many active customers do we have?"
- "What's the average deal size?"
- "How does this period compare to last?"

## Step-by-Step Guide

### Step 1: Open Your Dataset

Navigate to the dataset containing the metric you want to display.

### Step 2: Access KPI Builder

Click the **KPI** button in the toolbar, or select a numeric column and choose "Create KPI" from the menu.

### Step 3: Select Your Metric

Choose the number you want to display:

- **Sum**: Total of all values (e.g., total revenue)
- **Count**: Number of rows (e.g., number of deals)
- **Average**: Mean value (e.g., average order size)
- **Min/Max**: Extremes (e.g., highest sale)

### Step 4: Apply Filters (Optional)

Narrow your KPI to specific data:

- **Date range**: "This month" or "Last 30 days"
- **Categories**: "Enterprise customers only"
- **Conditions**: "Deals > $10,000"

### Step 5: Add Comparison (Optional)

Make your KPI more meaningful with context:

| Comparison Type | Example |
|-----------------|---------|
| **vs. Previous Period** | Revenue this month vs. last month |
| **vs. Same Period Last Year** | Q4 2024 vs. Q4 2023 |
| **vs. Target** | Actual vs. Goal |

Scoop shows the change as both a percentage and absolute value, with color coding (green for improvement, red for decline).

### Step 6: Format the Display

Customize how your number appears:

- **Number format**: Currency, percentage, decimal places
- **Abbreviations**: Show "1.2M" instead of "1,200,000"
- **Labels**: Add a title and subtitle
- **Colors**: Match your brand or use conditional formatting

## KPI Examples

| Metric | Aggregation | Filters | Comparison |
|--------|-------------|---------|------------|
| Monthly Recurring Revenue | Sum of MRR | Active customers | vs. Previous Month |
| Customer Count | Count of rows | None | vs. Same Month Last Year |
| Average Deal Size | Average of Amount | Closed-Won only | vs. Target |
| Days to Close | Average of Sales Cycle | This quarter | vs. Last Quarter |

## Best Practices

- **One metric per KPI**: Don't combine multiple numbers
- **Use meaningful comparisons**: Context makes numbers actionable
- **Keep labels short**: "Revenue" not "Total Monthly Recurring Revenue from Active Customers"
- **Group related KPIs**: Place them together in your dashboard

## What's Next?

- [Save your KPI](how-to-save-a-kpi) for reuse
- Add KPIs to a [presentation](../../Canvases/importing-a-powerpoint-or-slides-presentation/how-to-create-a-presentation)
- Create [charts](../chart-types/how-to-create-a-chart) to show trends behind the number
