---
title: Re-usable Visual Themes
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Reusable Visual Themes
  description: >-
    Themes in Scoop allow for consistent styling across visualizations by
    containing formatting settings such as color palette, fonts, chart settings,
    and table settings. Users can import, manually change, and create new themes
    from scratch.
  robots: index
next:
  description: ''
---
Themes are a powerful visual feature in Scoop. They allow one to maintain consistent styling across visualizations within a presentation. Themes contain most formatting settings that are offered in Scoop visualizations, ensuring that you can have commonality across a wide variety of format settings:

* Color palette (a list of colors that are used when charting)
* Fonts
* Chart settings
* Table settings

Scoop has built-in defaults, but it also allows you to both import and manually change your themes.

You can access themes by clicking on the Style tab in the right panel of Explorer and then clicking on Switch theme.

<Image align="center" width="300px" src="https://files.readme.io/792bcfb-image.png" />

You can then select a them by clicking on it to preview how it will look on your visualization, and then choosing Apply to make it active for your visualization.

<Image align="center" width="300px" src="https://files.readme.io/1c3841b-image.png" />

When importing a slide presentation from PowerPoint, Scoop will import all color schemes that are present in that presentation, allowing you to re-use them in your visualizations. It will also generate an AI generated recommended color palette as well for you to use based on the colors actually present in your presentation. See [AI Generated Color Themes](doc:ai-generated-color-themes) for more detail.

# Creating a New Theme from Scratch

Clicking on the plus icon next to Search themes allows you to create an entirely new theme.

<Image align="center" width="400px" src="https://files.readme.io/10ba80c-image.png" />

When you create a theme you must specify it's name and an initial color palette. All other formatting settings are set to their default values. Scoop will help you create an initial color palette. Scoop will recommend colors consistent with a base set of colors that you choose.

<Image align="center" width="400px" src="https://files.readme.io/ffebfef-image.png" />

As you can see, above there are two base colors and Scoop is asked to create a palette of 5 colors that harmonize with those two. You can add more base colors of your choosing and also increase the number of recommended colors that Scoop will generate.

<Image align="center" width="400px" src="https://files.readme.io/752b310-image.png" />

Once you have selected an initial palette you can confirm. If you would like to precisely change on or more colors in the palette, you can do that as described below.

# Modifying a Theme and Overriding Theme Settings

Once you have selected your theme, you can then modify anything in the style tab, including the palette.

<Image align="center" width="300px" src="https://files.readme.io/8b18bbf-image.png" />
