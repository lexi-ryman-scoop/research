---
title: Visualizing Data by Time
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Visualizing Data by Time
  description: >-
    Scoop is a data analysis tool optimized for analyzing data over time,
    allowing users to compare metrics over different time periods to assess
    business performance. The tool provides features that make it easy to
    understand data over time from datasets, offering powerful insights that are
    difficult to achieve with other tools.
  robots: index
next:
  description: ''
---
At its core, Scoop is highly optimized to help you analyze data over time. Ultimately analysis is generally only useful when numbers are compared against each other. Comparing metrics over time provides one of the most powerful tools to assess business performance by allowing one to assess whether things are going better or worse than before. As a result, there are a number of features built into Scoop that allow you to understand data over time from your datasets in ways that are very difficult to do with other tools and would require extensive coding in complex Business Intelligence tools.

# Time Concepts in a Scoop Dataset

When you ingest data in Scoop, it tracks as much as it can about time. Let's say that you are ingesting a report that contains snapshots of your sales pipeline every day. That dataset has you current sales opportunities at any point in time. Each opportunity, however, also has a created date and a closed date (when the sales rep expects the deal will close). That immediately creates three ways that we can slice this dataset by time:

1. By the date of each report ingested into Scoop (i.e. the Snapshot Date)
2. By the created date of the sales opportunity
3. By the closed date of the sales opportunity

Scoop understands this and allows you to analyze the same dataset by all three dates. For more detail on how Scoop derives these dates and uses them in your dataset see [Understanding Scoop Datasets](doc:scoop-dataset-basics). For now, just accept that Scoop is doing the right things to allow you to analyze the same dataset by all these dates.

In this example, say that I click on the Amount field (which is the amount of the sales opportunity on the report). You would see something like the following:

![](https://files.readme.io/e1fd685-image.png)

Scoop displays your metrics by time by default. And, by default, it chooses the report ingest date (or the Snapshot Date) by default. In this example a sales opportunities report has been uploaded daily for many months and by default, Scoop shows the amount by day. 

However, one might want to summarize that better and show the amount monthly or quarterly. One can change the Period Frequency to adjust that. Changing this to monthly yields.

![](https://files.readme.io/7e9c4cd-image.png)

Notice also the time range. In this example, the default is the last year of data. You can change how far back Scoop displays data to the last day, week, month, quarter or year or you can define a custom date range to control what period you would like to analyze.

## Period End Types

Notice also in this example that Period End is set to Rolling by default. This means that when you are looking at the last week or month or year it is always relative to today. This allows you to look at, say, the last month vs previous months from today and doesn't have the issues of partial periods at the end. If you look at the dates in on the bottom axis you can see that they are not at the beginning or ending of a month. These dates represent the last day of the rolling month that is being examined. 

However, some people want to see their data based on calendar periods so you can change Period End to Calendar and it will show you the data aggregated by calendar month. Switching to Calendar will yield dates that are always calendar month end.

![](https://files.readme.io/47079c8-image.png)

# Grouping Data

While looking at a single metric over time can be interesting, what might be more interesting is seeing how that depends on specific attributes. In this case, every sales opportunity has a key status field called Stage. The Stage of an opportunity is an assessment of where a deal is in it's life with the idea that, if successful, a deal moves through each stage from initial contact with a customer, to a closed won deal. Unfortunately things rarely work as linearly as that, but this status is key for understanding where a deal is at any time. As a result, one might really be interested to see how many deals were at each stage at the end of each month. To see this, you can simply select the Stage attribute (which is present in the dataset), in the Group By drop down.

![](https://files.readme.io/86dae37-image.png)

If one filters out the closed deals (i.e. deals that are no longer active), one can get a clear picture of the health of their pipeline at any one time. See [Filtering Data](doc:filtering-data) for more details on how to filter your dataset.

![](https://files.readme.io/2a6e184-image.png)

# Changing the Date of Analysis

So far we have only showed how data can be analyzed by the load or snapshot date of the report. As described above, Scoop also tracks any other dates present in your dataset and allows you to utilize those. Scoop remembers all reports that have ever been ingested and remembers the latest status of each date in your dataset. It then allows you to analyze by that date. The previous analysis compares the state of the pipeline over time. However, let's now say we want to analyze the current set of deals instead to see how many were created over time. This would give us a sense of our ability to create new deal opportunities which is also extremely valuable. To do that, we need to change the analysis date for our Amount metric. The charts above are based on using the report Snapshot date to analyze data.

![](https://files.readme.io/4ad0b9f-image.png)

By clicking on the three dots next to the Amount metric we can change this to the Created Date.

![](https://files.readme.io/884cc42-image.png)

This analysis shows all deals by their created date. Notice that the Amount axis is much smaller, only $3 million vs. $18 million when analyzing by snapshot date. This is because when analyzing by any date other than the snapshot date, one is only looking at the current status of deals. For each deal that Scoop has ever seen, there is only one value. When looking by Snapshot Date, a deal may be in many, many snapshots because it is alive for a long time. 

This analysis shows the current deal stage of all deals based on when they were created. We can similarly switch to show the current stage of all deals based on when they are expected to close by selecting Closed Date

![](https://files.readme.io/77f4aee-image.png)

As one can see in this example, the further out into the future a deal is expected to close, the more likely that it is at an early stage.
