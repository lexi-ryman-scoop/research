---
title: Filtering Data
excerpt: 'Focus your analysis on exactly the data you need'
deprecated: false
hidden: false
metadata:
  title: Filtering Data
  description: >-
    Filter your datasets in Scoop Explorer to focus analysis on specific
    segments, time periods, or conditions. Support for text, numeric, and date
    filters.
  robots: index
next:
  description: ''
---

Filters let you focus your analysis on a specific subset of your data. Instead of analyzing your entire dataset, you can drill into particular regions, time periods, customer segments, or any other dimension that matters to your business.

# Creating Filters

## Basic Filter Creation

1. In Explorer, click the **Filter** tab in the left panel
2. Click **+ New Filter**
3. Select the column you want to filter by
4. Choose your filter condition and values

<Image align="center" width="300px" src="https://files.readme.io/aa2c347-image.png" />

<Image align="center" width="300px" src="https://files.readme.io/78478b5-image.png" />

## Selecting Filter Columns

Click on any column from your dataset to use it as a filter:

<Image align="center" width="350px" src="https://files.readme.io/f4c2fcd-image.png" />

# Filter Types by Column

## Text Columns

For text/categorical columns, you have three options:

| Operator | Description | Example |
|----------|-------------|---------|
| **Equals** | Exact match | Region equals "West" |
| **Not Equals** | Exclude specific values | Status not equals "Cancelled" |
| **Like** | Contains text anywhere | Product like "Pro" matches "ProPlan", "Product Pro", etc. |

### Selecting Multiple Values

You can select multiple values to include or exclude:

<Image align="center" width="350px" src="https://files.readme.io/cdaee50-image.png" />

**Include mode:** Show only rows where the column matches ANY selected value
**Exclude mode:** Show all rows EXCEPT those matching selected values

### Searching High-Cardinality Columns

For columns with many unique values (like customer names or product IDs):
1. Use the **Search** box to find specific values
2. Type part of the value to filter the list
3. Select from the filtered results

This is especially useful when a column has hundreds or thousands of unique values.

## Numeric Columns

For numeric columns, use comparison operators:

| Operator | Description | Example |
|----------|-------------|---------|
| **Equals** | Exact value | Amount = 1000 |
| **Not Equals** | Exclude value | Quantity ≠ 0 |
| **Greater Than** | Above threshold | Revenue > 50000 |
| **Greater Than or Equal** | At or above | Score ≥ 80 |
| **Less Than** | Below threshold | Days < 30 |
| **Less Than or Equal** | At or below | Cost ≤ 100 |
| **Between** | Range of values | Price between 10 and 50 |

### Filtering for Outliers

To find outliers or anomalies:
- **High values:** Greater than [threshold]
- **Low values:** Less than [threshold]
- **Specific range:** Between [min] and [max]

## Date Columns

Date filters support both absolute and relative options:

### Relative Date Filters

| Filter | Description |
|--------|-------------|
| **Last 7 days** | Rolling week from today |
| **Last 30 days** | Rolling month from today |
| **Last quarter** | Previous 3-month period |
| **Last year** | Previous 12 months |
| **This month** | Current calendar month |
| **This quarter** | Current calendar quarter |
| **This year** | Current calendar year |

### Absolute Date Filters

- **Specific date:** March 15, 2024
- **Date range:** January 1, 2024 to March 31, 2024
- **Before/After:** Before July 1, 2024

# Combining Multiple Filters

## AND Logic (All Conditions Must Match)

When you add multiple filters, they combine with AND logic:

**Example:**
- Filter 1: Region = "West"
- Filter 2: Revenue > 10000

Result: Shows only West region deals with revenue over $10,000

## OR Logic Within a Filter

When you select multiple values within a single filter, they combine with OR logic:

**Example:**
- Region equals "West" OR "Central" OR "East"

Result: Shows all three regions, excluding others

## Complex Filter Combinations

Combine AND and OR for sophisticated filtering:

**Example:**
- (Region = "West" OR Region = "Central") AND
- (Deal Stage = "Closed Won") AND
- (Close Date in Last Quarter)

Result: Closed deals from West or Central regions in the last quarter

# Saving and Reusing Filters

## Save Current Filters

After creating your filter combination:
1. Your filters are automatically saved with the chart or visualization
2. When you save a chart, its filters are preserved

## Filter Presets

For commonly used filter combinations:
1. Create your filters
2. Save the chart with a descriptive name (e.g., "West Region Q4 Deals")
3. Access this preset anytime from your saved charts

# Using Filters with AI Chat

When you ask questions in the Insights chat, you can specify filters naturally:

**Examples:**
- "Show me revenue by product for the West region"
- "What's our win rate for deals over $50K?"
- "Compare this quarter to last quarter for enterprise customers"

Scoop's AI understands filter intent and applies appropriate filters automatically.

# Filters vs. Grouping

Understanding when to use filters vs. grouping:

| Use Filters When... | Use Grouping When... |
|--------------------|---------------------|
| You want to exclude data | You want to see all categories |
| Focusing on a specific segment | Comparing across segments |
| Reducing noise in analysis | Understanding distribution |
| Answering "for this segment..." | Answering "by category..." |

**Example:**
- **Filter:** "Show me West region revenue" → Single number
- **Group:** "Show me revenue by region" → Table comparing all regions

# Best Practices

## Start Broad, Then Narrow
1. Begin with your full dataset
2. Add one filter at a time
3. Verify each filter shows expected results
4. Build toward your specific analysis

## Use Descriptive Chart Names
When saving filtered views, include filter context:
- "Pipeline by Stage (Enterprise Only)"
- "Monthly Revenue (Excluding Returns)"
- "Q4 Deals Closed Won"

## Check Filter Logic
Before drawing conclusions:
1. Verify filter count shows expected reduction
2. Spot-check a few records to confirm filter accuracy
3. Consider if excluded data might affect conclusions

## Combine with Snapshots
For time-based analysis:
1. Use snapshot date filters to compare periods
2. Filter to specific snapshot dates for point-in-time views
3. Combine with other filters to track segment changes over time

# Troubleshooting

## No Results After Filtering
- Check if filters are too restrictive
- Verify spelling/case for text filters
- Ensure date ranges contain data
- Try removing filters one at a time to find the issue

## Unexpected Results
- Review all active filters (they combine with AND)
- Check for hidden filters from saved charts
- Verify column data types match filter type

## Performance with Many Filters
- Complex filter combinations may take longer
- Consider pre-filtering in a blended dataset for frequently-used combinations
- Use indexed columns when available

# Related Topics

- [Charting Time Series Data](charting-time-series-data) - Visualizing filtered data over time
- [Tables and Pivot Tables](tables-and-pivot-tables) - Viewing filtered data in tabular form
- [Visual Themes](visual-themes) - Styling your filtered visualizations
