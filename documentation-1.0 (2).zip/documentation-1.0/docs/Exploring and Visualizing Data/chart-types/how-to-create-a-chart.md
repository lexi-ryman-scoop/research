---
title: How to Create a Chart
excerpt: Build visualizations from your data in just a few clicks
deprecated: false
hidden: false
metadata:
  title: How to Create a Chart
  description: >-
    Learn how to create charts and visualizations in Scoop Analytics. Step-by-step
    guide to building bar charts, line charts, pie charts, and more from your data.
  robots: index
next:
  description: ''
---

<Embed url="https://www.youtube.com/watch?v=6MO2eNbL3C4" title="How to create a chart in Scoop" favicon="https://www.youtube.com/favicon.ico" image="https://i.ytimg.com/vi/6MO2eNbL3C4/hqdefault.jpg" provider="youtube.com" href="https://www.youtube.com/watch?v=6MO2eNbL3C4" typeOfEmbed="youtube" html="%3Ciframe%20class%3D%22embedly-embed%22%20src%3D%22%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Fsrc%3Dhttps%253A%252F%252Fwww.youtube.com%252Fembed%252F6MO2eNbL3C4%253Ffeature%253Doembed%26display_name%3DYouTube%26url%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253D6MO2eNbL3C4%26image%3Dhttps%253A%252F%252Fi.ytimg.com%252Fvi%252F6MO2eNbL3C4%252Fhqdefault.jpg%26type%3Dtext%252Fhtml%26schema%3Dyoutube%22%20width%3D%22640%22%20height%3D%22480%22%20scrolling%3D%22no%22%20title%3D%22YouTube%20embed%22%20frameborder%3D%220%22%20allow%3D%22autoplay%3B%20fullscreen%3B%20encrypted-media%3B%20picture-in-picture%3B%22%20allowfullscreen%3D%22true%22%3E%3C%2Fiframe%3E" />

## Overview

Scoop makes it easy to transform your data into compelling visualizations. Whether you want a simple bar chart or a complex time series, you can create charts in just a few clicks.

## Step-by-Step Guide

### Step 1: Open Your Dataset

Navigate to your dataset in Scoop. Make sure your data is loaded and you can see the spreadsheet view.

### Step 2: Select Data to Visualize

Click on a column header to select it, or use the **Explorer** panel to choose which dimensions and metrics to visualize:

- **Dimensions** (text/categories): These become your chart labels (X-axis, legend)
- **Metrics** (numbers): These become your chart values (Y-axis)

### Step 3: Choose Chart Type

Click the **Chart** button in the toolbar. Scoop offers several chart types:

| Chart Type | Best For |
|------------|----------|
| **Bar Chart** | Comparing categories |
| **Line Chart** | Trends over time |
| **Pie Chart** | Part-to-whole relationships |
| **Area Chart** | Cumulative trends |
| **Scatter Plot** | Correlations between metrics |
| **Table** | Detailed data with multiple metrics |

### Step 4: Configure Your Chart

In the chart configuration panel:

1. **Select dimensions** for grouping (e.g., Region, Product Category)
2. **Select metrics** to measure (e.g., Revenue, Count)
3. **Add filters** to focus on specific data subsets
4. **Adjust date range** if working with time-based data

### Step 5: Customize Appearance

Fine-tune your chart's look:

- **Colors**: Click the color picker to match your brand
- **Labels**: Toggle data labels on/off
- **Legend**: Position the legend where it works best
- **Sorting**: Order bars/segments by value or alphabetically

## Tips for Great Charts

- **Keep it simple**: One chart, one insight. Don't overcrowd with too many series.
- **Use appropriate scales**: Let Scoop auto-scale, or set manual min/max for emphasis.
- **Add context**: Include titles that explain the "so what" of the visualization.
- **Consider your audience**: Executives prefer high-level summaries; analysts may want drill-down capability.

## What's Next?

Once you've created a chart you like, learn how to [save it](how-to-save-a-chart) for reuse and sharing.
