---
title: Chart Types
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: Chart Types
  description: >-
    This document provides examples and explanations of different types of
    charts, including columns, lines, areas, and bars, with a focus on bar
    charts when time is not a category.
  robots: index
next:
  description: ''
---
# Column

![](https://files.readme.io/8562ad1-image.png)

<iframe
  width="560"
  height="315"
  src="https://www.youtube.com/embed/lPDYQuVYD34?si=lrn5MlRfvHGbkaSn"
  title="YouTube video player"
  frameborder="0"
  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
  referrerpolicy="strict-origin-when-cross-origin"
  allowfullscreen
></iframe>

Column charts with support for both categories and category groups as well as a diverse set of formatting options are available.

# Line

![](https://files.readme.io/30a721e-image.png)

<br />

Line charts are particularly useful in showing trends and metrics over time.

# Area

Area charts display relative amounts over time and help communicate magnitude well.

![](https://files.readme.io/f59cb63-image.png)

<br />

# Bar

When time is not a category (i.e. you have chosen a different category axis than time in the right panel), bar charts are also possible.

Bar charts support a horizontal layout. This can be especially useful if you have a lot of categories or their names are long.

![](https://files.readme.io/30e5508-image.png)

# Pie

<br />

| Regular Pie                                    | Half Pie                                       |
| :--------------------------------------------- | :--------------------------------------------- |
| ![](https://files.readme.io/afac663-image.png) | ![](https://files.readme.io/be9b7d9-image.png) |
|                                                |                                                |

Scoop supports pie charts with a variety of options to display relative amounts.

# Donut

![](https://files.readme.io/e054842-image.png)

Donut charts provide a bit more flair in displaying relative amounts.

# Pictorial Charts

![](https://files.readme.io/d8ba720-image.png)

Pictorial charts allow you to creatively visualize the semantics of a given data element with uploaded images and add some style to your charts.

# Gauge

![](https://files.readme.io/2a8c81b-image.png)

Gauges can be useful in showing progress towards a goal.

# Radial Charts

![](https://files.readme.io/c639a49-image.png)

Radial charts provide another method of showing relative contribution or value.