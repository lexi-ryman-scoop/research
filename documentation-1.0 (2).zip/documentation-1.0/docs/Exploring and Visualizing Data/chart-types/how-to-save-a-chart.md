---
title: How to Save a Chart
excerpt: Save your visualizations for reuse and sharing with your team
deprecated: false
hidden: false
metadata:
  title: How to Save a Chart
  description: >-
    Learn how to save charts in Scoop Analytics for reuse in presentations,
    sharing with teammates, and building dashboards.
  robots: index
next:
  description: ''
---

<Embed url="https://www.youtube.com/watch?v=eRUlq7X1slQ" title="How to save a chart in Scoop" favicon="https://www.youtube.com/favicon.ico" image="https://i.ytimg.com/vi/eRUlq7X1slQ/hqdefault.jpg" provider="youtube.com" href="https://www.youtube.com/watch?v=eRUlq7X1slQ" typeOfEmbed="youtube" html="%3Ciframe%20class%3D%22embedly-embed%22%20src%3D%22%2F%2Fcdn.embedly.com%2Fwidgets%2Fmedia.html%3Fsrc%3Dhttps%253A%252F%252Fwww.youtube.com%252Fembed%252FeRUlq7X1slQ%253Ffeature%253Doembed%26display_name%3DYouTube%26url%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253DeRUlq7X1slQ%26image%3Dhttps%253A%252F%252Fi.ytimg.com%252Fvi%252FeRUlq7X1slQ%252Fhqdefault.jpg%26type%3Dtext%252Fhtml%26schema%3Dyoutube%22%20width%3D%22640%22%20height%3D%22480%22%20scrolling%3D%22no%22%20title%3D%22YouTube%20embed%22%20frameborder%3D%220%22%20allow%3D%22autoplay%3B%20fullscreen%3B%20encrypted-media%3B%20picture-in-picture%3B%22%20allowfullscreen%3D%22true%22%3E%3C%2Fiframe%3E" />

## Overview

After creating a chart, you can save it for future use. Saved charts automatically update when your underlying data refreshes, making them perfect for recurring reporting and live dashboards.

## Step-by-Step Guide

### Step 1: Create or Select Your Chart

First, [create a chart](how-to-create-a-chart) or open an existing visualization that you want to save.

### Step 2: Click Save

Click the **Save** button in the chart toolbar. You'll see the save dialog appear.

### Step 3: Name Your Chart

Give your chart a descriptive name that makes it easy to find later. Good naming conventions include:

- **What it shows**: "Monthly Revenue by Region"
- **Who it's for**: "Sales Team Pipeline Overview"
- **When it's used**: "Q4 2024 Performance Summary"

### Step 4: Choose Save Location

Select where to save your chart:

- **Personal Library**: Only you can see and use this chart
- **Workspace Library**: All workspace members can access it
- **Specific Presentation**: Save directly to a canvas/presentation

### Step 5: Confirm Save

Click **Save** to finalize. Your chart is now saved and will appear in your chart library.

## Using Saved Charts

Once saved, your charts can be:

| Action | How |
|--------|-----|
| **Reopen** | Find in your chart library and click to view |
| **Add to Canvas** | Drag from library onto any presentation |
| **Duplicate** | Create a copy to modify for new analysis |
| **Share** | Send a link or export as image/PDF |
| **Schedule** | Set up automated email delivery |

## Auto-Refresh Behavior

Saved charts are **live by default**:

- When your dataset refreshes (daily, hourly, etc.), the chart automatically shows the latest data
- Filters and date ranges you set are preserved
- No manual updates needed for recurring reports

## Best Practices

- **Use descriptive names**: Future you will thank you
- **Organize by project or team**: Keep related charts together
- **Review periodically**: Archive charts you no longer use
- **Version with dates**: If tracking point-in-time snapshots, include the date in the name

## What's Next?

- Learn how to [create a KPI](../creating-kpis/how-to-create-a-kpi) for single-metric displays
- Add your chart to a [presentation](../../Canvases/importing-a-powerpoint-or-slides-presentation/how-to-create-a-presentation) for stakeholder reporting
