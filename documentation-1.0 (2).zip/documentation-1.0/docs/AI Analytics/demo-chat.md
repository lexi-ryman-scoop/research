---
title: Demo Chat
excerpt: Try Scoop's AI analytics without signing up
deprecated: false
hidden: false
metadata:
  title: Demo Chat - Try Scoop Free
  description: >-
    Experience Scoop's AI-powered analytics with our public demo datasets.
    No signup required. Explore real housing data or sales opportunities.
  robots: index
---

## Overview

Demo Chat lets you experience Scoop's AI analytics capabilities without creating an account. Ask questions about real datasets and see how Scoop investigates data, creates visualizations, and delivers insights.

## Available Demo Datasets

### Housing Market Data

Explore real estate market trends, pricing patterns, and geographic analysis.

**Access**: [go.scoopanalytics.com/demo-chat/housing](https://go.scoopanalytics.com/demo-chat/housing)

**Sample Questions to Try**:
- "What's the average home price by city?"
- "Show me price trends over the last year"
- "Which neighborhoods have the highest inventory?"
- "Compare median prices across regions"
- "What's the relationship between days on market and final sale price?"

### Sales Opportunities

Analyze a sales pipeline with deal stages, amounts, and conversion patterns.

**Access**: [go.scoopanalytics.com/demo-chat/opportunities](https://go.scoopanalytics.com/demo-chat/opportunities)

**Sample Questions to Try**:
- "Show me deals by stage"
- "What's the average deal size?"
- "Which opportunities are at risk?"
- "Compare win rates by source"
- "What factors predict deal success?"

## How It Works

1. **Click a demo link** above to open the chat interface
2. **Ask questions** in natural language
3. **Get answers** with charts, tables, and insights
4. **Follow up** with more questions to drill deeper

Demo Chat uses the same AI engine as the full Scoop platform. The only differences are the fixed demo datasets and a daily prompt limit.

## Demo Limits

| Feature | Demo | Full Account |
|---------|------|--------------|
| Prompts per day | 20 | Unlimited |
| Datasets | 2 demo datasets | Your own data |
| Chat history | Not saved | Saved |
| Visualizations | Full access | Full access |
| ML analysis | Full access | Full access |

## What You Can Do

Demo Chat gives you full access to Scoop's query and analysis capabilities:

- **Ask questions** in natural language
- **Get charts and tables** auto-generated from your query
- **Drill down** by asking follow-up questions
- **Run ML analysis** (clustering, predictive models, comparisons)
- **Export results** as images

## Tips for Best Results

1. **Be specific**: "Show revenue by month for Q4" works better than "show me data"
2. **Ask follow-ups**: Build on previous answers to explore deeper
3. **Try comparisons**: "Compare X vs Y" or "What changed between periods?"
4. **Request visualizations**: "Show this as a bar chart" or "Create a line chart"

## Ready for Your Own Data?

When you're ready to analyze your own datasets:

- **Web App**: [Start Free Trial](https://go.scoopanalytics.com) - Full features, no credit card
- **Slack**: [Add to Slack](https://www.scoopanalytics.com/integrations/slack) - 1-click install, works immediately

## Frequently Asked Questions

### Do I need to sign up?

No. Demo Chat is completely public and requires no account.

### What happens after 20 prompts?

The counter resets daily. Come back tomorrow for 20 more, or sign up for unlimited access.

### Can I upload my own data in demo mode?

No. Demo mode uses fixed datasets. Sign up for a free trial to analyze your own data.

### Is this the same AI as the paid version?

Yes. Demo Chat uses the identical AI engine, just with limited datasets.
