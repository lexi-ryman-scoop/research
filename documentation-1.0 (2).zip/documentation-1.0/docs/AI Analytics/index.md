---
title: AI Analytics
excerpt: How Scoop's AI investigates and analyzes your data
deprecated: false
hidden: false
metadata:
  title: AI Analytics - Scoop Documentation
  description: Learn how Scoop's autonomous AI data analyst works - from automated dataset analysis to machine learning insights.
  robots: index
---

# AI Analytics

Scoop is an **autonomous AI data analyst** that thinks, investigates, and discovers insights like a senior analyst would. This section explains how Scoop's AI capabilities work.

---

## How Scoop's AI Works

### The Investigation Approach

Unlike traditional BI tools that just show you charts, Scoop **investigates** your data:

1. **You ask a question** - in plain English, like "Why did sales drop in March?"
2. **Scoop plans an investigation** - determines what analyses will find the root cause
3. **Multiple probes execute** - each uncovering different aspects of the answer
4. **AI synthesizes findings** - combining evidence into actionable insights

This is fundamentally different from dashboards or chat-based SQL tools. Scoop doesn't just run queries - it **reasons** about your data.

### Key AI Capabilities

| Capability | What It Does | Example |
|------------|--------------|---------|
| **Automated Analysis** | Instantly understands your data structure, types, and relationships | Upload a CSV → Scoop identifies dates, metrics, dimensions automatically |
| **Natural Language** | Ask questions in plain English | "What's driving customer churn?" |
| **Investigation** | Multi-step analysis that finds root causes | Discovers that churn is driven by support response times > 7 days |
| **Machine Learning** | Clustering, prediction, and comparison without code | Automatically segments customers into behavioral groups |
| **Narrative Generation** | Writes business-friendly summaries | "Revenue increased 23% primarily due to enterprise segment growth" |

---

## AI-Powered Features

### Automated Dataset Analysis
When you upload or connect data, Scoop automatically:
- Detects data types and column meanings
- Identifies relationships between fields
- Generates summary statistics
- Suggests relevant analyses

[Learn more about Automated Dataset Analysis](automated-analysis.md)

### Machine Learning Analytics
Scoop makes enterprise ML accessible without coding:

- **Predictive Analysis** - What factors predict an outcome?
- **Segmentation/Clustering** - Find natural groups in your data
- **Group Comparisons** - What differentiates high vs low performers?
- **Time Period Analysis** - What changed between periods?

[Explore ML Analytics](ai-explorer.md)

### AI-Powered Presentations
Scoop doesn't just find insights - it presents them:
- Auto-generates executive slide decks
- Writes narrative summaries for each chart
- Applies your brand colors and templates
- Creates presentation-ready visualizations

[Learn about AI Presentations](ai-presentations/index.md)

---

## Understanding Scoop's AI

### Transparency
Every AI analysis in Scoop is **transparent**:
- You can see the queries that were run
- ML model rules are shown in plain English
- Confidence levels are provided
- All calculations are auditable

### Accuracy
Scoop's AI is built on **real analytics**, not just language models:
- Queries execute against your actual data
- ML uses proven algorithms (decision trees, clustering)
- Results are validated, not hallucinated
- Statistical significance is calculated

### When AI Says "No Pattern Found"
This is valuable information! It means:
- The factors you're looking at don't explain the outcome
- You should investigate other variables
- Saves you from chasing false correlations

---

## Getting Started with AI Analytics

1. **Upload or connect data** - Scoop's AI immediately starts analyzing
2. **Ask a question** - Try "Why did [metric] change?" or "What predicts [outcome]?"
3. **Review the investigation** - Watch Scoop's multi-probe analysis unfold
4. **Act on insights** - Get specific recommendations, not just data

> **Tip**: Start with "why" questions. They trigger Scoop's most powerful investigation capabilities.
