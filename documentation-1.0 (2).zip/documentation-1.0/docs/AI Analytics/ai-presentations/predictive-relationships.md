---
title: Predictive Relationships
deprecated: false
hidden: false
metadata:
  robots: index
---
Predictive relationships in your datasets open a world of practical insights—telling you not just what happened, but why, and what might happen next. In Scoop Analytics, will use machine learning models to automatically uncover these relationships, all without requiring deep technical expertise or coding skills.

***

## What Are Predictive Relationships?

A predictive relationship describes how one variable (for example, "Closed Won" in sales) is likely to change depending on other variables (such as "Deal Size," "Product Type," or "Lead Source"). By analyzing your data, Scoop can reveal these patterns—helping you answer questions like “What factors most strongly influence customer churn?” or “Which deal characteristics increase the likelihood of success?”

![](https://files.readme.io/153ce17446b6ca31b122fa8f0e2ae221b1f829afdf8bf790ee4fbafd142d8f29-image.png)

<br />

***

## How Does Scoop Find Predictive Relationships?

Scoop uses built-in machine learning algorithms—including **machine learning models**—to search for meaningful patterns. The platform automatically scans your dataset and, when prompted, tries to find the variables that most affect a particular outcome.

### Explainable Models

Scoop derives “if-this-then-that” questions and "rules-of-thumb" based on your data which makes the models easy to understand and explain. It looks for combinations of variables and derives likely patterns (e.g., “When deal size greater than $10,000, what types are most common?”), helping to split and segment your records until clear patterns or predictions emerge. Ultimately, the goal is to help you understand your data in clear terms:

> If Product = Software *and* Contract Length > 1 year, then Churn Risk = Low.

These rules are easy to read and share—ideal for business review meetings or communicating with less technical stakeholders.

> **Tip:** You don't need to know machine learning to use these features. Scoop's AI does the heavy lifting, producing easy-to-understand summaries and visuals.

***

## Why Is Variable Importance Important?

In any predictive analysis, some columns (variables) turn out to be much more influential than others. For instance, “Contract Value” might be a stronger driver of win/loss than “Sales Rep Email.”

When you run predictive models in Scoop, the results highlight which variables matter most for your particular outcome. This helps you:

* Focus on what actually drives business results
* Build targeted strategies (for example, to allocate resources, optimize pricing, or tailor follow-ups)
* Discard the noise—ignore variables that offer little predictive value

> **Tip:** Variable importance helps you prioritize your analytics, marketing, and operational efforts for maximum impact.

***

## What Might a Predictive Relationship Look Like in Scoop?

When Scoop finishes analyzing your dataset, it reports key rules and decision points, such as:

* Deals with deal size > $100k and product type = Custom tend to close faster
* Customers from region A with low usage in the first month are at higher risk for churn
* Opportunities with more than 3 follow-ups have twice the win rate

You'll see a summary of these findings, often with clear bullet points and supporting sub-bullets. These summaries translate complex machine learning models into English you can act on.

***

## How To Use Predictive Relationships In Your Work

1. **Pick an Outcome to Predict:** Choose a target variable—like churn, deal close, upgrade rate, or customer satisfaction score.
2. **Let Scoop Analyze:** Use the built-in machine learning prompts to ask Scoop to find what drives that outcome.
3. **Review Results:** Scoop returns key rules and variable importance—a summary you can instantly use.
4. **Take Action:** Apply the rules and insights—for example, adjust marketing campaigns, refine qualification criteria, or alert teams to high-risk customers.

***

## Real-World Examples

* *Sales:* “Deals sourced via Partner have a 35% higher close rate, especially when lead time is under 15 days.”
* *Customer Success:* “Customers with onboarding satisfaction \< 3 are 4x more likely to churn within 6 months.”
* *Operations:* “Orders with shipping delay > 2 days combined with customer tier = Gold almost always trigger support tickets.”

***

## Best Practices

* **Avoid Perfect Predictors:** If a variable is always the same for an outcome (e.g., Status = Closed when IsClosed = True), it's usually not interesting—Scoop focuses on less obvious, more actionable drivers.
* **Check for Binned/Derived Features:** Scoop can automatically create new attributes (like “Deal Age Bucket” or “Usage Tier”) to make patterns easier to spot.
* **Iterate:** Try predicting different outcomes (conversion, upsell, renewals, etc.) to surface a broader range of business levers.

> **Tip:** Each predictive analysis you run grows your understanding—helping you ask sharper questions and make smarter decisions each time.

***

Ready to let Scoop's AI uncover your most valuable predictive relationships? Select a target outcome and run your predictive analysis today!