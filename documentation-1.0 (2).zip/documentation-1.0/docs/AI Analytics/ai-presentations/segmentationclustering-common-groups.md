---
title: Segmentation/Clustering (Common Groups)
deprecated: false
hidden: false
metadata:
  robots: index
---
Clustering is a powerful analytical technique that automatically finds patterns and groups—sometimes called **segments**—within your data, revealing natural similarities among records that may not be obvious at first glance. In Scoop Analytics, clustering is designed for business users and is accessible directly within your workflow, with no need for coding or expert-level data science.

![](https://files.readme.io/19da2022997115ad07ab3ca487047cb497b307c1d575da5394307d77547baf53-image.png)

<br />

## What is Clustering?

Clustering is an unsupervised machine learning method used to group records in your dataset into buckets ("clusters") where members of each cluster share similar characteristics. Scoop uses advanced machine learning algorithms to find and define these clusters for you.

Unlike grouping or filtering by a specific value (like ‘Region’ or ‘Status’), clustering considers *combinations* of behaviors and attributes across multiple columns at the same time. This multi-dimensional approach lets Scoop uncover customer segments, opportunity stages, behavior patterns, or performance groups you might not have thought to look for.

> **Tip:** Clustering is ideal when you want to discover natural groupings in your data—like identifying customer types, purchase patterns, or groups with similar support needs—without knowing what defines those groups in advance.

## How Does Clustering Work in Scoop?

Here’s the typical clustering workflow:

1. **Select Your Dataset**: Start by loading the dataset you wish to analyze (e.g., deals, customers, support tickets).
2. **Click 'Find Common Groups'**: Access this from the Data Science Studio tab within Insights.
3. **Scoop Builds the Clusters**: Using the EM algorithm, Scoop automatically determines how many clusters best fit your data and analyzes records across *multiple* columns, not just one.
4. **Clusters are Interpreted and Named**: Scoop’s explainable AI then runs rules-based algorithms to translate statistical clusters into understandable human descriptions—"Fast Closers", "Long Cycle Enterprises", "Frequent Callers", etc.—using patterns found in your data.
5. **Cluster Results Delivered**: You’ll see summaries, visual profiles, and clear descriptions of what defines each cluster.

> **Tip:** You don’t need to know anything about data science or the underlying math. Scoop handles all variable selection, scaling, and cluster assignment automatically.

## How Clusters Are Named and Explained

After finding clusters in your data, Scoop does something special: it translates the *technical details* behind each cluster into plain-language explanations that you can instantly understand and act on.

* **Interpreting Clusters**: Scoop uses decision trees and rules modeling to examine the attributes that define each cluster. For example, Cluster 1 might mostly contain high-revenue accounts with short sales cycles; Cluster 2 might consist of smaller deals with longer cycles and more contacts involved.
* **Naming Clusters**: Each cluster gets a descriptive, human-friendly name based on distinguishing features ("Quick Wins", "Strategic Accounts", or "High Touch Customers"). These aren’t random—instead, they’re derived from the real patterns that the algorithm detects.
* **Cluster Profiles**: For every cluster, you’ll see a summary of key characteristics and the rules that most strongly predict cluster membership—in other words, *why* certain records ended up together.

### Example: What Might a Cluster Tell You?

Let’s say you’re analyzing support tickets. After running clustering, Scoop might show you clusters like:

* **"Quick Resolutions"**: Tickets that are resolved in less than 1 hour, typically from repeat customers.
* **"Escalated Criticals"**: Tickets involving certain product lines, with high severity, and longer times-to-close.
* **"Low Engagement Issues"**: Tickets with minimal customer responses or incomplete problem descriptions.

Each of these tells you something actionable—perhaps which customers might need more proactive support, or which issues require your team’s best experts.

> **Tip:** You can use the cluster descriptions for targeted follow-up, reporting, or even as an input to other analyses—like comparing how clusters’ behavior changes over time or which campaigns reach different segments.

## Best Practices for Clustering in Scoop

* **Use for "Unknown Unknowns"**: Run clustering when you want the system to show you natural groupings, not just to group by a column you already know.
* **Act on Insights**: Once clusters are named and described, you can use them to target communications, improve processes, or focus analysis on what matters.
* **Deep Dive with Rules**: Each cluster can be filtered with its defining rules, so you can see exactly which records belong, analyze them further, or export for action.

## Bringing It All Together

Clustering in Scoop Analytics is all about finding powerful, **hidden segments** that drive your business. Whether you’re in sales, marketing, operations, or customer success, clustering helps you move from a sea of data to clear, actionable stories—without needing to write code or learn complicated math.

If you’re curious which groups are hiding in your data, just point Scoop at your dataset and click "Find Common Groups"—we’ll do the rest, and hand you the insights you need!