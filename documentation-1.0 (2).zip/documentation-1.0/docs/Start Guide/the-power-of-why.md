---
title: The Power of Why - Autonomous Investigations
deprecated: false
hidden: false
metadata:
  robots: index
  description: How Scoop's AI analyst turns why questions into multi-probe investigations that reveal root causes
  keywords: root cause analysis, AI investigation, why questions, business analytics
---

# The Power of Why: How Scoop Investigates Like a Senior Analyst

## Stop Asking "What" - Start Asking "Why"

Traditional analytics tools answer "what" questions. Scoop is built to investigate "why" - just like a senior data analyst would, but in seconds instead of days.

## How "Why" Questions Trigger Deep Investigations

### Example 1: "Why did sales drop in March?"

**What happens behind the scenes:**

```
Your Question: "Why did sales drop in March?"

Scoop's Investigation Plan:
├── Probe 1: Measure sales change magnitude
│   └── Finding: -23% vs February, -18% vs March last year
├── Probe 2: Analyze by dimension breakdowns
│   └── Finding: Enterprise segment down 45%, SMB up 5%
├── Probe 3: Investigate enterprise segment specifically
│   └── Finding: 3 major accounts churned
├── Probe 4: Analyze churn patterns
│   └── Finding: All 3 had support tickets > 7 days
├── Probe 5: Check historical support correlation
│   └── Finding: 72% correlation between 7+ day tickets and churn
└── Synthesis: Poor support response driving enterprise churn

Root Cause Identified + Action Plan Provided
```

**What you get:** Not just "sales are down" but WHY and WHAT TO DO.

## The Investigation Process

### 1. Strategy Formation
When you ask "why", Scoop:
- Identifies the metric or change to investigate
- Creates a hypothesis-driven exploration plan
- Determines which probes will reveal root causes

### 2. Multi-Probe Execution
Each probe can:
- Analyze different dimensions
- Compare time periods
- Find statistical anomalies
- Identify correlations
- Detect pattern changes

### 3. Intelligent Chaining
Unlike simple queries, each finding influences next steps:
- If regional difference found → Investigate that region
- If segment pattern found → Deep dive on that segment
- If correlation found → Test causation hypothesis

### 4. Synthesis & Recommendations
Scoop doesn't just list findings. It:
- Identifies primary root causes
- Ranks contributing factors
- Suggests specific actions
- Explains in business terms

## Types of "Why" Investigations

### Performance Changes
- "Why did conversion rate drop?"
- "Why are costs increasing?"
- "Why did productivity improve?"

**Scoop investigates**: Period comparisons, dimension analysis, correlation discovery, anomaly detection

### Business Outcomes
- "Why do some customers churn?"
- "Why do certain deals close faster?"
- "Why are some regions outperforming?"

**Scoop investigates**: Behavioral patterns, success factors, environmental variables, predictive indicators

### Operational Issues
- "Why are deliveries delayed?"
- "Why did quality scores decrease?"
- "Why is inventory building up?"

**Scoop investigates**: Process bottlenecks, cascade effects, systemic issues, root dependencies

## Real Investigation Examples

### "Why did customer satisfaction drop?"

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/682e5a69fd7ef4ea8c8ded86_Screenshot%20from%202025-05-21%2015-57-23.png" width="600px" />

*Scoop discovering patterns in customer data over time*

**Investigation reveals**:
1. Response time increased 40% starting March 1st
2. Correlated with new support system deployment
3. Specific issue: Ticket routing to wrong teams
4. Impact: 15% of tickets delayed > 24 hours
5. Customer segment most affected: Enterprise
6. Predicted churn risk: $2.3M in next quarter
7. **Fix**: Reconfigure routing rules (specific instructions provided)

### "Why are we losing deals to competitors?"

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/683262ea4991f2e7ab2c1bdb_Screenshot%20from%202025-05-24%2014-48-04.png" width="600px" />

*Decision tree analysis revealing what drives win/loss outcomes*

**Investigation reveals**:
1. Loss rate increased in deals > $50K
2. Common factor: 3+ stakeholders involved
3. Competitor advantage: Better multi-stakeholder tools
4. Our sales cycle: 45 days vs their 32 days
5. Key moment: Week 3 when additional stakeholders join
6. **Strategy**: New collateral for technical buyers, accelerate POCs

### "Why did profit margins shrink?"

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/685ed60b1e3c4636e3cc32bb_scoop-slack-opportunity-bar-chart.png" width="600px" />

**Investigation reveals**:
1. Revenue stable but costs up 12%
2. Primary driver: Shipping costs (+34%)
3. Root cause: Order size decreased 23%
4. Reason: New free shipping threshold too low
5. Customer behavior: Splitting orders to hit minimum
6. **Solution**: Adjust threshold or incentivize larger orders

## Advanced Investigation Patterns

### The Cascade Investigation
"Why did revenue drop?" leads to:
- Why did sales volume decrease?
  - Why did conversion drop?
    - Why did trial-to-paid decrease?
      - Why did feature adoption fall?
        - Root cause: Onboarding bug in v2.3

### The Comparison Investigation
"Why is Region A outperforming Region B?" reveals:
- Different customer mix (found through ML segmentation)
- Different competitive landscape
- Different sales team structure
- Key insight: Region A's model is replicable

### The Prediction Investigation
"Why might we miss our target?" uncovers:
- Current trajectory analysis
- Leading indicator changes
- Risk factor assessment
- Scenario modeling
- Preventive actions needed now

## When to Use "Why" Questions

### ✅ Perfect for:
- Understanding changes in metrics
- Diagnosing problems
- Finding improvement opportunities
- Discovering hidden relationships
- Getting actionable insights

### 💡 Try These Powerful Starters:
- "Why did [metric] [change]?"
- "Why are we seeing [pattern]?"
- "Why do some [entities] [behavior]?"
- "Why is there a difference between [A] and [B]?"
- "Why isn't [expected thing] happening?"

## The Magic: You Don't Need to Be Specific

### Traditional BI Challenge:
You need to know exactly what to ask and where to look

### Scoop's Approach:
Vague questions trigger comprehensive investigations

**Example**:
- Vague: "Why are things weird this month?"
- Scoop: Investigates all major metrics, finds anomalies, identifies that customer acquisition cost spiked due to a marketing channel issue

## What Makes This Possible?

### 1. Reasoning Engine
- 859-line prompt system for analytical thinking
- Multi-step reasoning with validation
- Context awareness across queries

### 2. ML Integration
- Automatic pattern detection
- Clustering for segmentation
- Correlation analysis
- Predictive modeling

### 3. Business Intelligence
- Understands metric relationships
- Knows investigation patterns
- Applies domain expertise
- Maintains context

## Start Investigating Now

<Image align="center" src="https://cdn.prod.website-files.com/65fdc9041545b81c2e66e5ac/6866fd89288f09a7e696151e_slack-sales-opporuntity-export-to-powerpoint.png" width="600px" />

*Export your investigations to PowerPoint with one click*

### Your First "Why" Question:
1. Think of a metric that changed
2. Ask Scoop: "Why did [metric] [change]?"
3. Watch the investigation unfold
4. Get root causes, not just data

### Power User Tips:
- Don't pre-filter your question
- Let Scoop determine what's relevant
- Ask follow-up "whys" on findings
- Trust the investigation process

## Beyond "Why": Other Investigation Triggers

- **"What's driving..."** → Factor analysis
- **"What influences..."** → Correlation investigation
- **"What explains..."** → Statistical modeling
- **"What's causing..."** → Causation analysis

## The Bottom Line

Every business has "why" questions that go unanswered because investigating them manually takes too long. Scoop is your always-available senior analyst who can investigate any "why" in seconds, not days.

**Stop wondering. Start discovering.**

[Try Your First Why Question] | [See Investigation Demo]