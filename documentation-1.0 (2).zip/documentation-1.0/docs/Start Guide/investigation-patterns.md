---
title: Investigation Patterns - What to Ask Your AI Analyst
deprecated: false
hidden: false
metadata:
  robots: index
  description: Powerful investigation patterns and starter questions for Scoop's autonomous AI analyst
  keywords: investigation patterns, AI analytics questions, data analysis patterns
---

# Investigation Patterns: What to Ask Your AI Analyst

## The Secret: Think Like an Executive, Not a Query Writer

Don't ask for data. Ask for insights, investigations, and understanding.

## Core Investigation Patterns

### 1. The "Why" Investigation
**Purpose**: Uncover root causes of changes or issues

**Pattern**: "Why did [metric] [change]?"

**Examples**:
- "Why did revenue drop last month?"
- "Why are conversion rates improving?"
- "Why did customer satisfaction decrease?"
- "Why are costs rising faster than revenue?"

**What Scoop Does**: Multi-probe investigation → root cause identification → action plan

---

### 2. The "Analyze" Investigation
**Purpose**: Discover patterns and segments you don't know exist

**Pattern**: "Analyze my [entity/area]"

**Examples**:
- "Analyze my customer base"
- "Analyze sales performance"
- "Analyze product usage patterns"
- "Analyze team productivity"

**What Scoop Does**: ML-powered discovery → hidden segments → strategic insights

---

### 3. The "What Drives" Investigation
**Purpose**: Find non-obvious factors influencing outcomes

**Pattern**: "What drives [outcome]?"

**Examples**:
- "What drives customer retention?"
- "What drives deal size?"
- "What drives product adoption?"
- "What drives team performance?"

**What Scoop Does**: Statistical analysis → correlation discovery → predictive factors

---

### 4. The "Find Patterns" Investigation
**Purpose**: Uncover hidden patterns and anomalies

**Pattern**: "Find patterns in [data/behavior]"

**Examples**:
- "Find patterns in customer churn"
- "Find patterns in sales cycles"
- "Find patterns in support tickets"
- "Find patterns in usage data"

**What Scoop Does**: Pattern recognition → anomaly detection → business implications

---

### 5. The "Compare" Investigation
**Purpose**: Understand differences and changes

**Pattern**: "Compare [A] to [B]"

**Examples**:
- "Compare this quarter to last quarter"
- "Compare high-value customers to others"
- "Compare successful deals to lost deals"
- "Compare top performers to average"

**What Scoop Does**: Multi-dimensional comparison → key differentiators → insights

## Advanced Investigation Patterns

### The Evolution Investigation
**Purpose**: Track how things change over time

**Examples**:
- "How has customer behavior evolved?"
- "How are our sales patterns changing?"
- "Show me pipeline evolution over time"
- "Track how usage patterns have shifted"

**Power**: Uses snapshot data to show progression, not just current state

---

### The Prediction Investigation
**Purpose**: Anticipate future outcomes

**Examples**:
- "Predict which customers might churn"
- "What will revenue look like next quarter?"
- "Which deals are likely to close?"
- "Forecast demand by product"

**Power**: ML models trained on your specific patterns

---

### The Segmentation Investigation
**Purpose**: Find natural groupings in your data

**Examples**:
- "Segment my customers"
- "Group products by performance patterns"
- "Cluster sales territories"
- "Find user behavior segments"

**Power**: Discovers segments you didn't know existed

---

### The Diagnostic Investigation
**Purpose**: Diagnose complex business issues

**Examples**:
- "Diagnose pipeline health"
- "Why is growth slowing?"
- "What's wrong with our conversion funnel?"
- "Diagnose customer satisfaction issues"

**Power**: Systematic investigation across all factors

## Industry-Specific Investigation Starters

### SaaS / Technology
- "Why is MRR growth slowing?"
- "Analyze churn patterns by cohort"
- "What drives expansion revenue?"
- "Find early indicators of account risk"
- "Compare feature adoption across segments"

### E-Commerce / Retail
- "Why did cart abandonment increase?"
- "Analyze customer lifetime value patterns"
- "What drives repeat purchase behavior?"
- "Find seasonal patterns I should plan for"
- "Compare channel performance deeply"

### Sales Organizations
- "Why are sales cycles lengthening?"
- "Analyze win/loss patterns"
- "What differentiates top performers?"
- "Find bottlenecks in our sales process"
- "Predict which deals will close"

### Marketing Teams
- "Why did CAC increase?"
- "Analyze campaign performance patterns"
- "What drives conversion at each funnel stage?"
- "Find the optimal channel mix"
- "Compare audience segment behavior"

### Financial Analysis
- "Why are margins shrinking?"
- "Analyze expense patterns"
- "What drives profitability by segment?"
- "Find cost optimization opportunities"
- "Compare budget vs actual deeply"

## The Power of Vague Questions

### Don't Be Too Specific!
Scoop's AI thrives on investigative freedom.

**Too Specific**: "Show me revenue by product by month for Q1"
**Better**: "Why did Q1 revenue disappoint?"

**Too Specific**: "List customers who churned last month"
**Better**: "Analyze recent churn patterns"

**Too Specific**: "Calculate average deal size by rep"
**Better**: "What drives sales performance?"

## Conversation Patterns

### The Progressive Investigation
Start broad, then narrow based on discoveries:

1. "Analyze my business performance"
2. (Scoop finds issue in customer segment)
3. "Why is that segment struggling?"
4. (Scoop finds product-related cause)
5. "What should we do about it?"

### The Multi-Angle Investigation
Approach problems from different angles:

1. "Why are we losing customers?"
2. "What do churned customers have in common?"
3. "Compare churned vs retained customers"
4. "Predict who might churn next"
5. "What interventions would help most?"

### The Time-Based Investigation
Understand evolution and trends:

1. "How has our business changed over time?"
2. "What's different about recent months?"
3. "When did these changes start?"
4. "What coincided with these changes?"
5. "Project these trends forward"

## Power User Secrets

### 1. Let Scoop Surprise You
- "What's interesting in my data?"
- "What should I know about my business?"
- "Find something surprising"
- "What am I missing?"

### 2. Use Business Language
- Not: "SELECT SUM(revenue) GROUP BY..."
- But: "How's business doing?"
- Not: "Join customers with orders where..."
- But: "Tell me about customer behavior"

### 3. Ask About Problems, Not Metrics
- Not: "Show me the churn rate"
- But: "Why are we losing customers?"
- Not: "Calculate revenue by segment"
- But: "Which segments drive growth?"

### 4. Trust the Investigation Process
- Don't pre-filter or constrain
- Let Scoop determine what's relevant
- Ask follow-ups on discoveries
- Build on what you learn

## Common Mistakes to Avoid

### ❌ Thinking Like SQL
"SELECT * FROM customers WHERE..." → "Analyze my customer patterns"

### ❌ Being Too Prescriptive
"Show me exactly X grouped by Y filtered by Z" → "Help me understand what's happening with [area]"

### ❌ Asking for Single Metrics
"What's the churn rate?" → "Why are customers leaving?"

### ❌ Ignoring Suggestions
Scoop suggests follow-ups for a reason - they lead to insights

## Your First Week of Investigations

### Day 1: Start with Why
Pick your biggest current concern and ask why it's happening

### Day 2: Analyze Something
Choose a business area and let Scoop analyze it completely

### Day 3: Find Drivers
Ask what drives your most important metric

### Day 4: Compare Periods
Have Scoop compare your recent performance to historical

### Day 5: Discover Segments
Let Scoop find hidden segments in your customers/products/data

### Day 6: Predict Something
Ask Scoop to predict an important future outcome

### Day 7: Get Strategic
Ask: "What should I focus on to improve performance?"

## The Bottom Line

Stop thinking about queries. Start thinking about questions that matter to your business. Scoop isn't waiting for perfect syntax - it's waiting to investigate your most important business challenges.

**Your AI analyst is ready. What mystery should it solve first?**

[Start Your Investigation] | [Watch Investigation Demo]