---
title: Team Management & Workspace Sharing
excerpt: >-
  Learn how to invite team members to your Scoop account and share workspaces
  with them. This guide covers the two-level permission system, role management,
  and step-by-step instructions for team collaboration.
deprecated: false
hidden: false
metadata:
  robots: index
---
## Overview

Scoop uses a two-level permission system to give you granular control over your team:

1. **Account-level access** - Who is part of your team
2. **Workspace-level access** - Which workspaces each team member can access

## Prerequisites

To invite team members, you need:

* A **Team** or **Enterprise** account (not available on Free or Individual plans)
* **Owner** or **Admin** role on the account

**Team account limits:** Up to 25 team members

***

## Inviting Members to Your Account

### Step 1: Send the Invitation

1. Navigate to **Account Settings** 

   <Image align="center" border={false} src="https://files.readme.io/988c6b3af5d704823dfb132f3b819e1a2a4cb9553f5eac40e679431476411560-Account_Settings.png" />
2. Click **Invite Member** 

   <Image align="center" border={false} width="50% " src="https://files.readme.io/1736756603b218078f8e32b53f551ca5d5045f02d87cb93f652bf5853a7e4f2e-Invite_team_member.png" />
3. Enter the team member's email address
4. Select their role:
   * **Member** - Standard access
   * **Admin** - Can manage team and settings
5. Click **Send Invitation**

### Step 2: Member Accepts Invitation

The invited person will receive an email invitation. When they click the link:

**If they already have a Scoop account:**

* They'll see the invitation acceptance screen
* Click "Accept Invitation"
* They'll be added to your team account

**If they're new to Scoop:**

* They'll be prompted to create an account first
* Enter their details and verify their email
* After account creation, they'll see the invitation acceptance screen
* Click "Accept Invitation" to join your team
* They'll then go through the standard onboarding flow

***

## Sharing Workspaces with Team Members

After inviting someone to your account, you can give them access to specific workspaces.

### Important Note

Adding someone to your account does **not** automatically give them access to your workspaces. You must share workspaces separately.

### How to Share a Workspace

1. Go to **Workspaces** 

   <Image align="center" border={false} src="https://files.readme.io/56165584f88adeb3c57bb8c05482b32a43bd317eb7e40159d13084deec2e26ed-Screenshot_2025-12-02_at_1.16.04_PM.png" />
2. Select the workspace you want to share
3. Click **Share** or **Invite to Workspace**
4. Select the team member from your account
5. Choose their workspace role:
   * **Member** - Can view and collaborate
   * **Admin/Owner** - Can manage workspace settings and invite others

### Workspace Sharing Permissions

* **Account Admins/Owners** can share any workspace with any team member
* **Workspace Owners/Admins** can only share workspaces they own or admin
* **Workspace Members** cannot invite others to that workspace

***

## Permission Levels Explained

### Account Level

* **Owner** - Full control over account, billing, and all settings
* **Admin** - Can manage team members and account settings
* **Member** - Standard team member access

### Workspace Level

* **Owner** - Created the workspace, full control
* **Admin** - Can manage workspace and invite members
* **Member** - Can access and work in the workspace, but cannot invite others

***

## Common Workflows

### Scenario 1: Adding a New Team Member

1. Invite them to your account (Account Settings > Invite Member)
2. They accept the invitation
3. Share specific workspaces with them based on their role

### Scenario 2: Giving Existing Team Member Access to a New Workspace

1. Go to the workspace you want to share
2. Invite the team member (they're already in your account)
3. Set their workspace permissions

### Scenario 3: Managing Multiple Workspaces

You can have different team members in different workspaces. This allows you to:

* Keep sensitive projects separate
* Organize teams by department or project
* Control who sees what information

***

## Troubleshooting

**Can't see "Invite Member" option?**

* Check that you have a Team or Enterprise account (not Free or Individual)
* Verify you're an Owner or Admin of the account

**Reached member limit?**

* Team accounts support up to 25 members
* Enterprise accounts have higher limits
* Contact support to upgrade if needed

**Can't share a workspace?**

* Verify you're the Owner or Admin of that specific workspace
* Check that the person is already a member of your account
