---
title: "Visualizations & Exports"
deprecated: false
hidden: false
metadata:
  robots: index
---
# Data Visualization & Export Mastery

Transform complex data into compelling visual stories and share insights in any format your team needs.

## The Art of Data Visualization

### 🎨 Natural Language to Beautiful Charts

Simply describe what you want to see:

```
@Scoop create a revenue trend chart
@Scoop show customer segments as a pie chart
@Scoop plot price vs satisfaction correlation
@Scoop visualize sales funnel stages
@Scoop compare this year to last year
```

!\[Screenshot: Various chart types created by Scoop]

### 🤖 Intelligent Chart Selection

Scoop automatically chooses the perfect visualization:

| Your Data | Scoop Creates | Why It Works |
|-----------|---------------|--------------|
| Time series | Line chart | Shows trends clearly |
| Categories | Bar/Column | Easy comparison |
| Parts of whole | Pie/Donut | Proportions at a glance |
| Correlations | Scatter plot | Reveals relationships |
| Distributions | Histogram | Shows data spread |
| Multi-dimensional | Heatmap | Patterns in complexity |
| Hierarchical | Treemap | Nested proportions |
| Flow/Process | Sankey | Visualizes journeys |

### 📊 Supported Visualizations

**Basic Charts**
- 📊 Bar Charts (horizontal/vertical)
- 📈 Line Charts (single/multi-series)
- 🥧 Pie & Donut Charts
- 📉 Area Charts (standard/stacked)
- 🔵 Scatter & Bubble Plots

**Advanced Visualizations**
- 🗺️ Heatmaps & Treemaps
- 🌊 Waterfall Charts
- 📊 Combo Charts (bar + line)
- 🎯 Gauge & Bullet Charts
- 🕸️ Radar/Spider Charts
- 📈 Candlestick (financial)
- 🔀 Sankey Diagrams
- 🌐 Geographic Maps

**Statistical Charts**
- 📊 Box & Whisker Plots
- 🔔 Distribution Curves
- 📈 Regression Lines
- 🎯 Control Charts
- 📉 Confidence Intervals

## Visualization Intelligence

### 🧠 Smart Enhancements

Every chart includes AI-powered enhancements:

```
📊 Monthly Revenue Trend
━━━━━━━━━━━━━━━━━━━━━━━━

Key Insights:
✓ 23% growth trend identified
✓ Seasonal peak in November
✓ Anomaly detected in July (investigation recommended)
✓ Forecast: $2.4M for next month (82% confidence)

Statistical Summary:
• Mean: $1.8M
• Trend: +$145K/month
• R²: 0.89 (strong correlation)
• Seasonality: Detected (Q4 peak)

[🔍 Investigate Anomaly] [📈 Show Forecast] [📊 Add Comparison]
```

### 🎯 Interactive Features

All visualizations are fully interactive:

**Hover Actions**
- View exact values
- See percentage of total
- Display calculations
- Show confidence intervals

**Click Actions**
- Drill down to details
- Filter other visuals
- Isolate series
- Zoom time ranges

**Legend Controls**
- Toggle series on/off
- Highlight specific data
- Reorder displays
- Change groupings

## Visualization Themes & Styling

### 🎨 Professional Themes

Scoop offers three visualization themes, easily selectable with a single click:

!\[Screenshot: Theme selector showing Dark, Light, and Auto options]

**Theme Selection Button**

On any visualization result, you'll see a theme button showing the current theme:
- Click "🌙 Dark" to see theme options
- Click "☀️ Light" to see theme options  
- Click "🎨 Auto" to see theme options

The button dynamically updates to show your current selection.

**🌙 Dark Theme**
- High contrast for presentations
- Reduced eye strain
- Modern aesthetic
- OLED-friendly
- Perfect for: Dashboards, monitors, dark rooms

**☀️ Light Theme**
- Print-friendly
- Classic professional
- High readability
- Report-ready
- Perfect for: Documents, emails, printed reports

**🎨 Auto Theme (Magic!)**
- Extracts your brand colors automatically
- Applies color theory for best contrast
- Maintains accessibility standards
- Consistent with your brand identity
- Perfect for: Company presentations, client reports

### How to Change Themes

**Method 1: Click the Theme Button**
```
1. Generate any visualization
2. Look for the theme button (e.g., "🌙 Dark")
3. Click to open theme selector
4. Choose your preferred theme
5. Chart instantly updates
```

**Method 2: Natural Language**
```
You: Show revenue chart in dark theme
You: Use light theme for this visualization
You: Apply our brand colors
```

**Method 3: Set Default**
```
You: Always use dark theme for visualizations
Scoop: ✅ Set dark as your default theme
```

### Theme Persistence

- **Session Memory**: Theme choice persists during your session
- **Personal Preference**: Scoop remembers your preference
- **Override Anytime**: Change themes per visualization
- **Export Consistency**: Exports use selected theme

### 🎨 Brand Customization

```
You: Use our brand colors for all charts

Scoop: 🎨 Brand theme activated!
Detected colors:
• Primary: #1E40AF (Blue)
• Secondary: #10B981 (Green)
• Accent: #F59E0B (Amber)

Applied with accessibility adjustments.
All future charts will use these colors.

[Keep Theme] [Adjust Colors] [Reset Default]
```

### 📐 Layout Intelligence

Scoop automatically optimizes layout:
- Responsive sizing
- Label positioning
- Legend placement
- Axis scaling
- Grid lines
- Annotations

## Advanced Visualization Techniques

### 📊 Multi-Metric Visualizations

Combine multiple data series intelligently:

```
@Scoop show revenue and customer count by month with different scales

Scoop: 📊 Creating dual-axis chart...

Left Y-Axis: Revenue ($M)
Right Y-Axis: Customer Count
X-Axis: Month

✓ Scales optimized for clarity
✓ Visual distinction maintained
✓ Correlation highlighted
```

### 🎯 Conditional Formatting

Automatic visual encoding of meaning:

```
Performance Dashboard:
🟢 Above target (>110%)
🟡 Near target (90-110%)
🔴 Below target (<90%)

Trends:
📈 Improving (green)
➡️ Stable (gray)
📉 Declining (red)

Confidence:
███ High (>90%)
██░ Medium (70-90%)
█░░ Low (<70%)
```

### 🔄 Dynamic Updates

Real-time visualization updates:

```
@Scoop create live dashboard of today's metrics

Scoop: 📊 Live dashboard created!

Updates every: 5 minutes
Last refresh: 2 seconds ago
Next update: In 4:58

Showing:
• Current revenue: $124,521 📈
• Active users: 1,247 👥
• Conversion rate: 3.2% 🎯
• Support queue: 12 tickets 🎫

[⏸ Pause Updates] [🔄 Refresh Now] [⚙️ Settings]
```

### 🎭 Visualization Compositions

Create comprehensive visual stories:

```
@Scoop create executive dashboard for Q4 review

Scoop: 🎨 Building comprehensive dashboard...

Page 1: Executive Summary
├─ KPI Gauges (4 metrics)
├─ Revenue Waterfall
└─ Regional Performance Map

Page 2: Detailed Analysis
├─ Trend Lines (3 metrics)
├─ Customer Segmentation
└─ Product Mix Evolution

Page 3: Predictive Insights
├─ Forecast Scenarios
├─ Risk Heatmap
└─ Opportunity Matrix

[View Dashboard] [Customize] [Export All]
```

## Smart Drill-Down Capabilities

### 🔍 Progressive Detail Revelation

Start high-level, dive deep on demand:

```
Level 1: Total Revenue by Region
    ↓ Click on "North America"
Level 2: North America by State
    ↓ Click on "California"
Level 3: California by City
    ↓ Click on "San Francisco"
Level 4: San Francisco by Customer Segment
    ↓ Click on "Enterprise"
Level 5: Enterprise Customer Details
```

### 🎯 Context-Aware Drill Paths

Scoop suggests logical drill-downs:

```
Viewing: Product Category Performance

Suggested Drill Paths:
→ By Sub-category
→ By Time Period
→ By Customer Segment
→ By Geography
→ By Price Range

[Apply Smart Drill] [Custom Path]
```

## Export Capabilities

### 📊 Excel Exports

Professional Excel workbooks with:

**Data Worksheet**
- Complete query results
- Formatted headers
- Data validation
- Frozen panes
- Auto-filters

**Analysis Worksheet**
- Summary statistics
- Pivot tables
- Conditional formatting
- Sparklines
- Key insights

**Charts Worksheet**
- All visualizations
- Interactive charts
- Linked to data
- Print-ready layout

**Metadata Worksheet**
- Query documentation
- Field definitions
- Calculation logic
- Update timestamp

!\[Screenshot: Export button and Excel file in Slack]

### 🖼️ Image Exports

High-quality images for presentations:

**Format Options**
- PNG (transparent background)
- JPG (optimized size)
- SVG (vector, scalable)
- PDF (print quality)

**Resolution Settings**
- Screen (1x) - Quick sharing
- Retina (2x) - Presentations  
- Print (4x) - Publications
- Custom DPI

**Export Presets**
```
[📧 Email] [📊 Slides] [🖨️ Print] [🌐 Web]
```

### 📄 PDF Reports

Automated report generation:

```
@Scoop create PDF report of monthly analysis

Scoop: 📄 Generating professional report...

Included sections:
✓ Executive Summary
✓ Key Metrics & KPIs
✓ Trend Analysis (6 charts)
✓ Detailed Tables
✓ Insights & Recommendations
✓ Appendix with methodology

Format: Letter, 12 pages
Style: Corporate template

[📥 Download PDF] [✏️ Edit Sections] [📧 Email Report]
```

### 🔗 Interactive Exports

Share live, interactive dashboards:

```
@Scoop create shareable dashboard link

Scoop: 🔗 Interactive dashboard created!

Share URL: https://go.scoopanalytics.com/view/x7k9m2p
Access: Anyone with link
Expires: 30 days
Features: Full interactivity, no edit

Embed code for websites:
<iframe src="https://go.scoopanalytics.com/embed/x7k9m2p" 
        width="800" height="600"></iframe>

[Copy Link] [Manage Access] [Get QR Code]
```

## Visualization Best Practices

### 📊 Chart Selection Guide

**DO Choose:**
- Line charts for trends over time
- Bar charts for comparing items
- Pie charts for parts of whole (≤7 segments)
- Scatter plots for correlations
- Heatmaps for multi-dimensional patterns

**DON'T Choose:**
- Pie charts for time series
- 3D charts (reduce clarity)
- Too many colors (>7)
- Dual axes without clear reason
- Complex charts for simple data

### 🎨 Design Principles

**Clarity First**
```
✅ Clear titles and labels
✅ Appropriate scale
✅ Consistent colors
✅ Readable fonts
✅ Sufficient contrast
```

**Tell a Story**
```
1. Start with the main message
2. Support with visual evidence
3. Highlight key insights
4. Guide to action
```

**Accessibility**
```
• Colorblind-friendly palettes
• High contrast ratios
• Alternative text descriptions
• Pattern alternatives to color
• Keyboard navigation
```

### 📈 Common Pitfalls to Avoid

**Scale Manipulation**
- ❌ Starting Y-axis at non-zero without reason
- ✅ Use full scale or clearly indicate break

**Overplotting**
- ❌ Too many series on one chart
- ✅ Use small multiples or facets

**Inappropriate Aggregation**
- ❌ Averages hiding important variation
- ✅ Show distributions when relevant

## Power User Features

### 🎯 Custom Calculations in Visuals

```
@Scoop plot revenue with 3-month moving average

@Scoop show actual vs forecast with confidence bands

@Scoop create cohort retention heatmap
```

### 🔧 Visualization Templates

Save and reuse visualization configurations:

```
@Scoop save this as "Monthly Executive Dashboard"

@Scoop apply "Monthly Executive Dashboard" to Q1 data

@Scoop share template with team
```

### 🤖 ML-Enhanced Visualizations

```
@Scoop show revenue with anomaly detection

@Scoop add trend line with seasonality

@Scoop highlight statistically significant changes

@Scoop show clustering visualization
```

## Real-World Examples

### 📊 Sales Performance Dashboard

```
You: Create a sales performance dashboard

Scoop: 📊 Building comprehensive sales dashboard...

Created 6 visualizations:

1. Revenue Trend (Line + Forecast)
2. Top 10 Performers (Bar)
3. Pipeline Stages (Funnel)
4. Regional Performance (Map)
5. Product Mix (Treemap)
6. Win Rate Trends (Line)

Key Insights Highlighted:
• 23% YoY growth
• APAC outperforming by 45%
• Product X driving 60% of growth
• Win rate improving to 34%

[View Dashboard] [Export PDF] [Share Link]
```

### 📈 Customer Analytics Suite

```
You: Visualize customer behavior patterns

Scoop: 🎨 Creating behavior analysis suite...

Generated visualizations:

1. Engagement Heatmap (Time × Activity)
2. Segment Distribution (Donut)
3. LTV by Cohort (Multi-line)
4. Churn Predictor (Scatter)
5. Journey Sankey (Flow)

Interactive features enabled:
• Click segments to filter
• Hover for user counts
• Zoom for time detail

[Explore Suite] [Download All]
```

## Next Steps

Ready to create stunning visualizations?

1. 🎯 **[Advanced Features](advanced-features.md)** - Deep reasoning & automation
2. 🤖 **[Machine Learning Analytics](machine-learning-analytics.md)** - ML-powered visuals
3. 📊 **[Working with Datasets](working-with-datasets-in-scoop-for-slack.md)** - Dataset management
4. 💡 **[FAQ & Troubleshooting](faq-troubleshooting.md)** - Common questions

---

**Pro tip**: Start with Scoop's automatic visualization, then refine based on your audience. A picture is worth a thousand rows of data! 📊✨