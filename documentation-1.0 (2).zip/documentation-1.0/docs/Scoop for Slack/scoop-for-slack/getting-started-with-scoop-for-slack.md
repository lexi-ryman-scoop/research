---
title: Getting Started with Scoop for Slack
deprecated: false
hidden: false
metadata:
  robots: index
---
# Getting Started with Scoop for Slack

Welcome to Scoop! There are two ways to get started with Scoop in Slack - choose the one that fits your needs.

## Method 1: Quick Start 

The fastest way to try Scoop for Slack

### Step 1: Add to Slack

1. **Signup for Scoop and add your data**
2. **Click the "Connect to Slack" button in your datasets tab - https://go.scoopanalytics.com/sources** 

   <Image align="center" border={false} src="https://files.readme.io/7c69fd12441e8131c026a2ef510c0197a01c966211259cb7c5340d6a247a07e3-scoop_connect_to_slack.png" />

   <Image align="center" border={false} src="https://files.readme.io/b66d8a0b33410be2c7f96eb83a757f0abb346b180ba7deb4c6d6f8e7312c0b95-connect_to_slack_popup.png" />

   * You'll be redirected to Slack's authorization page 

     <Image align="center" border={false} src="https://files.readme.io/853532153b670634f2c85fd9785a542ddca6d65b35f10fb705eba1431de185b5-connect_to_slack_auth.png" />
   * If not logged into Slack, you'll need to sign in first
3. **Review and authorize permissions**
   * Scoop will request permission to:
     * View messages that mention @Scoop
     * Send messages as Scoop
     * Access basic workspace information
   * Click "Allow" to proceed

### Step 2: Start Using Scoop Immediately

That's it! Here's what happens automatically:

* ✅ **Automatic account creation**: Scoop creates a shadow workspace for you
* ✅ **Your dataset is included**: Start exploring right away with your data
* ✅ **Personal workspace ready**: Upload your own files whenever you want
* ✅ **Zero friction**: Just start chatting with @Scoop in Slack

### Step 3: Your First Conversation

1. **Find @Scoop** in your Apps sidebar in Slack
2. **Send a message** like "Hello" or "Help"
3. **Start analyzing**:
   ```
   You: Show me what data is available
   Scoop: Here's what you can analyze:
   • Sample Sales Dataset (ready to use!)
   • Or upload your own CSV/Excel file
   ```

## Method 2: Enterprise Setup (For Existing Scoop Users) 🏢

If you already have a Scoop workspace with datasets, use this method to share specific datasets with Slack channels.

### Prerequisites

* Existing Scoop Analytics account
* Access to datasets you want to share
* Admin access to your Slack workspace (or permission to install apps)

### Step 1: Connect Slack to Your Scoop Workspace

1. **Log into Scoop** at [go.scoopanalytics.com](https://go.scoopanalytics.com)
2. **Navigate to Settings → Integrations**
3. **Click "Connect Slack"**
4. **Authorize the connection** when redirected to Slack

### Step 2: Share Datasets with Specific Channels

1. **Go to Dataset Index** in Scoop Analytics
2. **Right-click on a dataset** you want to share
3. **Select "Configure Slack sharing"**
4. **Choose channels**:
   * Search for channels by name
   * Check boxes next to channels that should access this dataset
   * Changes save automatically
5. **Click "Confirm"** to close the dialog

### Step 3: Channel-Specific Access

Now team members can:

* Query the shared dataset by mentioning @Scoop in those specific channels
* Only access datasets explicitly shared with their channel
* Benefit from any security filters you've configured

### Enterprise Features

* **Channel-level permissions**: Each dataset is only accessible in selected channels
* **Security filters**: Configure user-specific data filtering
* **Centralized management**: Control all dataset access from Scoop Analytics
* **Multiple datasets**: Share different datasets with different channels

## Using Scoop in Slack

### Direct Messages

Best for personal analysis and exploration:

```
You: Show me revenue trends
You: What drives customer churn?
You: Segment my customers
```

### Channel Mentions

Great for team collaboration:

```
@Scoop analyze last quarter's performance
@Scoop why did conversion rates drop?
@Scoop show top customers by region
```

### Slash Commands

Power user shortcuts:

* `/scoop query [question]` - Quick queries
* `/scoop dataset` - Switch datasets
* `/scoop save [name]` - Save queries
* `/scoop deck` - Run saved analysis
* `/scoop help` - Command reference

## Uploading Your Own Data

In either setup method, you can upload your own data:

1. **In a DM with @Scoop**, click the **+** button
2. **Select your file** (CSV or Excel, max 100MB)
3. **Upload directly** to the conversation
4. **Scoop processes it** and confirms when ready
5. **Start analyzing** your data immediately

## Tips for Success

### ✅ Best Practices

* **Be specific**: "Revenue by product last quarter" > "Show revenue"
* **Natural language**: No SQL or technical terms needed
* **Iterate**: Each answer can lead to deeper insights
* **Save queries**: Reuse analyses that you run frequently

### 🚀 Power Features

* **Deep reasoning**: Ask "why" questions for investigation
* **Machine learning**: "What predicts churn?" or "Find patterns"
* **Visualizations**: Automatic charts and graphs
* **Personal decks**: Save and run multiple queries at once

## Security & Privacy

### Method 1 (Quick Start)

* 🔒 **Personal shadow workspace**: Your data is completely private
* 🛡️ **Isolated environment**: No access to other users' data
* ✅ **SOC2 compliant**: Enterprise-grade security

### Method 2 (Enterprise)

* 🏢 **Workspace isolation**: Complete separation between organizations
* 🔐 **Channel-level access**: Datasets only visible where explicitly shared
* 👤 **User-level filtering**: Optional row-level security
* ✅ **Audit trails**: Track all data access

## Troubleshooting

### "Can't find Scoop in Slack"

1. Refresh Slack: `Cmd+R` (Mac) or `Ctrl+R` (Windows)
2. Check Apps section in sidebar
3. Search for "Scoop" in Slack search

### "No datasets available" (Method 1)

* Your dataset should load automatically
* Try typing "help"
* Upload your own file to get started

### "Can't see shared dataset" (Method 2)

* Verify the dataset was shared with your channel
* Check you're in the correct channel
* Ask your admin to verify sharing settings

### "Connection failed"

* Ensure you have permission to install Slack apps
* Try the authorization process again
* Contact [support@scoopanalytics.com](mailto:support@scoopanalytics.com)

## Getting Help

* **In Slack**: Type "help" to @Scoop
* **Documentation**: [docs.scoopanalytics.com](https://docs.scoopanalytics.com)
* **Email**: [support@scoopanalytics.com](mailto:support@scoopanalytics.com)
* **Examples**: Ask "what can you do?" for sample queries

## Next Steps

### For Quick Start Users

1. **Explore the sample dataset** - Learn Scoop's capabilities
2. **Upload your own data** - Real insights from your files
3. **Try advanced features** - ML, predictions, and deep reasoning

### For Enterprise Users

1. **Share more datasets** - Expand access across teams
2. **Configure security filters** - Set up row-level permissions
3. **Train your team** - Share this guide and best practices

Ready to transform how your team analyzes data? Say "Hello" to @Scoop!
