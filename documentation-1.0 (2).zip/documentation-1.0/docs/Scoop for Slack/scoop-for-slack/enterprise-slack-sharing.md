---
title: Enterprise Slack Sharing
deprecated: false
hidden: false
metadata:
  robots: index
---
# Enterprise Slack Sharing: Channel-Specific Dataset Access

The enterprise "Add to Slack" feature allows you to share specific datasets from your Scoop workspace with selected Slack channels, enabling controlled access and collaboration.

## Overview

This feature enables:
- **Granular control**: Share specific datasets with specific channels
- **Team collaboration**: Enable teams to query their data directly in Slack
- **Security**: Optional user-level filtering for data access
- **Centralized management**: Control all access from Scoop Analytics

## Prerequisites

1. **Slack Connection**: A Slack workspace must be connected to Scoop Analytics through OAuth authentication
2. **Dataset Access**: You must have access to the dataset you want to share
3. **Permissions**: You must have appropriate permissions to manage dataset sharing in Scoop

## How to Share Datasets with Slack Channels

### Step 1: Access Dataset Menu

1. **Navigate to the Dataset Index page** in Scoop Analytics
2. **Locate the dataset** you want to share with Slack
3. **Right-click on the dataset** to open the context menu
4. **Select "Configure Slack sharing"** 
   - This option only appears if a Slack connection exists
   - If you don't see it, ensure Slack is connected in Settings → Integrations

### Step 2: Configure Slack Sharing

The "Slack Sharing" dialog opens, displaying:

![Screenshot: Slack sharing dialog]

1. **Dataset name** at the top for confirmation
2. **Search bar** to filter channels
3. **List of all available Slack channels** from your connected workspace

#### Search for Channels (Optional)
- Use the search bar to filter channels by name
- Search is case-insensitive and updates in real-time
- Helpful for workspaces with many channels

#### Select/Deselect Channels
- **Check the box** next to each channel where you want this dataset accessible
- **Uncheck** to remove access from a channel
- Changes are **saved automatically** as you toggle checkboxes
- Real-time updates with optimistic UI feedback

#### Confirm Changes
- Click the **"Confirm"** button to close the dialog
- All changes are already saved due to the optimistic update mechanism

### Step 3: Using Shared Datasets in Slack

Once a dataset is shared with Slack channels:

#### In the Shared Channels
Team members can:
1. **Mention @Scoop** in the channel
2. **Query the shared dataset** directly
3. **Access only datasets** explicitly shared with that channel

Example:
```
@Scoop show me sales trends for this quarter
@Scoop what are our top customers?
@Scoop analyze conversion rates by region
```

#### Access Control
- **Channel-specific**: Only datasets shared with a channel are accessible there
- **Immediate updates**: Adding/removing access takes effect instantly
- **No cross-channel access**: Datasets shared with #sales won't be accessible in #marketing

## Advanced Features

### Security Filters

Configure user-level data filtering:
1. Set up security filters on the dataset in Scoop
2. When users query via Slack, they only see their permitted data
3. Perfect for sales teams seeing only their territories

### Multiple Dataset Management

- Share different datasets with different channels
- A channel can have access to multiple datasets
- Users can switch between available datasets using `/scoop dataset`

### Bulk Operations

For organizations with many channels:
- Use the search to find related channels (e.g., search "sales")
- Quickly toggle multiple channels
- Changes save automatically without waiting

## Technical Details

### Performance
- **Real-time Updates**: Changes apply immediately with optimistic updates
- **Error Recovery**: If a sharing operation fails, the UI automatically reverts
- **Debounced Search**: Channel search is optimized for smooth performance
- **Concurrent Operations**: Toggle multiple channels rapidly without conflicts

### API Integration
- Connection type identified as "Slack" in API connections
- OAuth flow handles authentication seamlessly
- No additional credentials required after initial connection

## Best Practices

### Channel Organization
1. **Create dedicated analytics channels**: e.g., #sales-analytics, #marketing-data
2. **Use consistent naming**: Makes searching and management easier
3. **Document access**: Let teams know which datasets are available where

### Security Considerations
1. **Review channel membership** before sharing sensitive data
2. **Use security filters** for user-specific data access
3. **Audit regularly**: Periodically review which datasets are shared where

### Communication
1. **Announce new datasets**: When sharing, let the channel know
2. **Provide examples**: Share sample queries to get teams started
3. **Designate champions**: Have power users in each channel help others

## Troubleshooting

### "Configure Slack sharing" option missing
- Ensure Slack is connected in Settings → Integrations
- Verify you have permission to manage dataset sharing
- Refresh the page and try again

### Channels not appearing in the list
- Ensure Scoop has access to private channels (may need re-authorization)
- Check that channels are not archived
- Try refreshing the Slack connection

### Changes not saving
- Check your internet connection
- Look for error messages in the UI
- Try refreshing and making changes again

### Users can't access shared dataset
- Verify the dataset is shared with their channel
- Ensure @Scoop is a member of the channel
- Check if security filters are blocking access

## Managing Slack Connections

The Slack connection is managed at the workspace level:

1. **Navigate to Settings → Integrations**
2. **View connected Slack workspaces**
3. **Disconnect or reconnect** as needed
4. **All dataset sharing** is preserved during reconnection

## Next Steps

1. **Start with one channel**: Pick a pilot team to test the feature
2. **Gather feedback**: Learn how teams prefer to query data
3. **Expand gradually**: Add more datasets and channels based on success
4. **Monitor usage**: Track which datasets get the most queries

Ready to empower your teams with data? Start sharing datasets with Slack channels today!