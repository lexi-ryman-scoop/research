---
title: "FAQ & Troubleshooting"
deprecated: false
hidden: false
metadata:
  robots: index
---
# FAQ & Troubleshooting Guide

Quick answers to common questions and solutions for any issues you might encounter.

## 🚀 Getting Started

### Installation & Setup

**Q: How do I install Scoop for Slack?**

A: Installation is simple:
1. Admin visits [go.scoopanalytics.com](https://go.scoopanalytics.com)
2. Navigate to Settings → Integrations
3. Click "Add to Slack" button
4. Authorize permissions
5. Scoop appears in your workspace!

Individual users don't need to install anything.

---

**Q: Why can't I see Scoop in my workspace?**

A: Try these steps in order:
1. **Refresh Slack**: Press `Cmd+R` (Mac) or `Ctrl+R` (Windows)
2. **Check Apps section**: Look in the left sidebar under Apps
3. **Search for Scoop**: Use Slack's search (Cmd/Ctrl + K)
4. **Verify installation**: Ask your Slack admin to confirm
5. **Permission check**: Ensure you have access to use Scoop

---

**Q: Do I need a separate Scoop account?**

A: No! If Scoop is installed in your Slack workspace, you're ready to go. Your Slack identity is all you need.

---

**Q: Which Slack permissions does Scoop need?**

A: Scoop requests minimal permissions:
- Read messages that mention @Scoop
- Post messages as Scoop bot
- Access basic workspace info
- View public channel info
- Access files you share

## 💬 Using Scoop

### Basic Interactions

**Q: How do I start using Scoop?**

A: Four ways to begin:
1. **Direct Message**: Click Scoop in Apps → Type your question
2. **In Channels**: Type `@Scoop your question here`
3. **Slash Commands**: Type `/scoop your question here`
4. **From App Home**: Visit Scoop's Home tab for guided start

---

**Q: Why does Scoop say "No dataset selected"?**

A: You need to select a dataset first:

In channels:
```
@Scoop show datasets
@Scoop use sales data
```

In DMs:
```
datasets
use customer analytics
```

---

**Q: What's the difference between DM and channel usage?**

A: Key differences:

| Feature | Direct Messages | Channels |
|---------|-----------------|----------|
| @ mention | Not needed | Required |
| Privacy | Always private | Private until shared |
| Context | Full history | Thread-based |
| Best for | Deep analysis | Team collaboration |

### Slash Commands

**Q: What are slash commands and how do I use them?**

A: Slash commands provide quick access to Scoop functionality:

**Available Commands:**
- `/scoop query [question]` - Ask any question about your data
- `/scoop dataset` - Select or change dataset
- `/scoop save [name]` - Save the last query with a name
- `/scoop run [name]` - Run a saved query by name
- `/scoop deck` - Run your personal deck
- `/scoop list` - List saved queries
- `/scoop list decks` - List saved decks
- `/scoop status` - Check current dataset and session
- `/scoop help` - Get command reference

**Shortcut:** Just type `/scoop [question]` to quickly query data!

---

**Q: What's the difference between `/scoop` and `@Scoop`?**

A: Both work, but have different use cases:

| Feature | `/scoop` Commands | `@Scoop` Mentions |
|---------|-------------------|-------------------|
| Speed | Faster | Standard |
| Privacy | Always private initially | Private until shared |
| Context | New conversation | Maintains thread context |
| Best for | Quick queries | Collaborative discussion |

---

**Q: Can I use slash commands in channels?**

A: Yes! Slash commands work everywhere:
- In channels: Results are private (ephemeral) initially
- In DMs: Results appear in the conversation
- In threads: Creates a new context

### Privacy & Sharing

**Q: Can others see my queries in channels?**

A: No! Channel responses are **private by default** (ephemeral messages). Only you see them until you explicitly share.

![Screenshot: Share button on Scoop response]

---

**Q: How do I share results with my team?**

A: Simple one-click sharing:
1. Get your result privately
2. Review for accuracy
3. Click "📢 Share with Channel"
4. Add context if needed
5. Team sees the insight!

---

**Q: Can I control what gets shared?**

A: Yes! When you share:
- ✅ Shared: The specific result/visualization
- ✅ Shared: Your name as discoverer
- ✅ Shared: Original query for context
- ❌ Not shared: Your exploration history
- ❌ Not shared: Failed attempts
- ❌ Not shared: Other private queries

## 📊 Data & Datasets

### File Uploads

**Q: What file types can I upload?**

A: Supported formats:

| Format | Extensions | Max Size | Notes |
|--------|-----------|----------|-------|
| Excel | .xlsx, .xls | 100MB | Multi-sheet support |
| CSV | .csv | 100MB | Auto-delimiter detection |
| JSON | .json | 50MB | Coming soon |
| PDF | .pdf | 25MB | Table extraction coming |

---

**Q: My file won't upload - why?**

A: Common issues and fixes:

1. **File too large**: Keep under 100MB
2. **Wrong format**: Save as .xlsx or .csv
3. **Complex layout**: Remove merged cells, multiple headers
4. **Special characters**: Use UTF-8 encoding
5. **Hidden data**: Remove hidden sheets/columns

---

**Q: Where is uploaded data stored?**

A: Your data is secure:
- 🔒 Personal workspace (private to you)
- 🔐 Encrypted storage
- 🛡️ Isolated from other users
- 🗑️ Deletable on demand
- ⏰ Auto-cleanup per retention policy

### Dataset Management

**Q: How do I switch between datasets?**

A: Quick switching:
```
@Scoop datasets                    # List all
@Scoop use "Q4 Sales"             # Switch
@Scoop current dataset            # Verify
```

---

**Q: Can I combine multiple datasets?**

A: Yes! Two approaches:

1. **Upload pre-joined data**: Combine in Excel first
2. **Cross-dataset analysis**: Ask questions that span datasets:
   ```
   @Scoop correlate support tickets with revenue by customer
   ```

---

**Q: How often is data refreshed?**

A: Depends on dataset type:

| Type | Refresh Frequency | How to Check |
|------|------------------|--------------|
| Organization | Admin-configured (usually daily) | `@Scoop dataset info` |
| Personal | Manual (re-upload) | Upload new version |
| Connected | Real-time or scheduled | Check integration settings |

## 🤖 Queries & Analysis

### Query Capabilities

**Q: What kinds of questions can I ask?**

A: Scoop understands everything from simple to complex:

**Basic Queries**
```
Show me all customers
What's our total revenue?
List top 10 products
```

**Analytical Questions**
```
Why did sales drop last month?
What drives customer churn?
Find anomalies in the data
```

**Predictive Queries**
```
Forecast next quarter
Predict which deals will close
What's our churn risk?
```

**Comparative Analysis**
```
Compare this year to last year
How do we compare to industry?
What changed between Q1 and Q2?
```

---

**Q: Why did Scoop misunderstand my query?**

A: Try these fixes:

1. **Be more specific**
   - ❌ "Show data"
   - ✅ "Show revenue by month"

2. **Use consistent terms**
   - Check column names: `@Scoop describe dataset`
   - Match terminology

3. **Break complex queries**
   - Step 1: "Show all deals"
   - Step 2: "Filter to closed won"
   - Step 3: "Add close date"

4. **Verify dataset**
   - Right dataset? `@Scoop current dataset`
   - Has needed data? `@Scoop columns`

---

**Q: Can I reference previous results?**

A: Yes! Scoop maintains context:
```
You: Show me top customers
Scoop: [displays list]
You: Add their revenue          # Scoop knows "their" = top customers
Scoop: [enhanced list]
You: Now show just enterprise   # Builds on previous
```

### Advanced Features

**Q: How do I use machine learning features?**

A: Natural language ML:
```
Find patterns in customer behavior
Segment our user base
What predicts success?
Classify these transactions
Detect anomalies
```

---

**Q: Can I save queries for reuse?**

A: Several options:

1. **Scroll history**: Past queries remain in chat
2. **Copy favorites**: Keep a note of useful queries
3. **Ask for templates**: `@Scoop show me query examples`
4. **Natural patterns**: Scoop learns your style

## 📈 Visualizations & Exports

### Chart Management

**Q: How do I customize visualizations?**

A: Interactive controls:
- **Theme**: Click 🌙/☀️/🎨 selector
- **Type**: Request specific charts: "show as pie chart"
- **Details**: Hover for values, click to drill down
- **Legend**: Click items to show/hide

---

**Q: Can I export visualizations?**

A: Multiple export options:

| Need | Solution |
|------|----------|
| Quick share | Screenshot (Cmd+Shift+4) |
| Data + chart | Export to Excel |
| Presentation | Copy/paste image |
| Interactive | Share to channel |

---

**Q: Why don't my brand colors appear?**

A: To enable brand colors:
1. Select "Auto" theme (🎨)
2. Scoop extracts colors from your uploads
3. Or: `@Scoop use brand colors #1E40AF #10B981`

### Export Issues

**Q: Excel export is taking forever - help?**

A: Normal export times:

| Rows | Expected Time | If Slower |
|------|--------------|-----------|
| Less than 10K | Instant | Check connection |
| 10-100K | 5-10 sec | Normal |
| 100K-1M | 30-60 sec | Consider filtering |
| More than 1M | 2-5 min | Use sampling |

Speed up options:
```
@Scoop export summary only
@Scoop export filtered view
@Scoop sample and export
```

## 🔒 Security & Privacy

### Data Security

**Q: Is my data secure with Scoop?**

A: Enterprise-grade security:
- ✅ End-to-end encryption
- ✅ SOC2 Type II certified
- ✅ Workspace isolation
- ✅ No data mixing
- ✅ Regular security audits

---

**Q: Who can see my analyses?**

A: Visibility control:

| Your Activity | Who Sees It |
|--------------|-------------|
| DM queries | Only you |
| Channel queries (private) | Only you |
| Shared results | Channel members |
| Personal datasets | Only you |
| Failed queries | Only you |

---

**Q: Can I delete my data?**

A: Yes, multiple options:
1. **Personal datasets**: `@Scoop delete dataset "name"`
2. **All personal data**: Contact admin
3. **Shared insights**: Follow Slack's deletion
4. **Account removal**: Admin can revoke access

### Compliance

**Q: Does Scoop comply with our security policies?**

A: Scoop provides:
- Detailed security documentation
- Compliance certificates
- Audit logs
- Data processing agreements
- Custom enterprise agreements

Contact security@scoopanalytics.com for details.

## 🔧 Troubleshooting

### Common Issues

**"Scoop is not responding"**

Try these steps:
1. Check Slack status: status.slack.com
2. Refresh Slack: Cmd/Ctrl + R
3. Check dataset: `@Scoop status`
4. Try simple query: `@Scoop help`
5. Contact support if persists

---

**"No data returned"**

Debugging steps:
```
@Scoop describe dataset     # Verify data exists
@Scoop show sample         # Check data format
@Scoop count records       # Ensure not empty
```

---

**"Unexpected results"**

Troubleshooting:
1. Verify query interpretation: `@Scoop explain last query`
2. Check filters: `@Scoop show active filters`
3. Validate data: `@Scoop data quality check`
4. Try step-by-step approach

### Performance Issues

**"Queries are slow"**

Speed optimization:
1. **Add time bounds**: "last 30 days" vs "all time"
2. **Be specific**: Name exact columns needed
3. **Use sampling**: "sample 1000 records"
4. **Pre-filter**: Start with filtered dataset

---

**"Visualizations won't load"**

Quick fixes:
1. Reduce data points: "top 20" instead of all
2. Simplify chart: Fewer series/dimensions
3. Check connectivity: Other Slack features working?
4. Try different chart type

### Error Messages

**"Dataset not found"**

Solutions:
- List available: `@Scoop datasets`
- Check spelling/case
- Verify permissions
- Refresh dataset list

---

**"Query too complex"**

Simplification strategies:
1. Break into multiple queries
2. Reduce conditions
3. Use simpler aggregations
4. Ask for help: `@Scoop help me write this query`

---

**"Access denied"**

Access issues:
- Verify dataset permissions with admin
- Check workspace membership
- Ensure Scoop has channel access
- Confirm data classification allows access

## 💡 Pro Tips

### Power User Shortcuts

**Quick Commands**
```
"qa" → Quick analysis with charts
"stats" → Summary statistics
"viz" → Auto-visualization
"export all" → Complete export package
```

**Context Commands**
```
"again" → Repeat last query
"undo" → Remove last filter
"reset" → Clear all filters
"explain" → Show query interpretation
```

### Best Practices

**For Fastest Results**
1. Start specific: Include dataset context
2. Use time bounds: "last month" vs all data
3. Name exact metrics: "revenue" not "sales"
4. Build incrementally: Add complexity gradually

**For Best Insights**
1. Ask "why" questions for deep analysis
2. Request confidence levels on predictions
3. Compare time periods for trends
4. Use ML for pattern discovery

## 🆘 Getting More Help

### Self-Service Resources

1. **In-Slack Help**: `@Scoop help [topic]`
2. **Interactive Guide**: Visit Scoop App Home
3. **Documentation**: docs.scoopanalytics.com
4. **Video Tutorials**: youtube.com/scoopanalytics

### Contact Support

**For technical issues**:
- Email: support@scoopanalytics.com
- Slack: #scoop-support channel
- Response time: Less than 2 hours (business hours)

**For account/billing**:
- Email: accounts@scoopanalytics.com
- Phone: 1-800-SCOOP-DATA

**For security concerns**:
- Email: security@scoopanalytics.com
- Urgent: security-urgent@scoopanalytics.com

## 🎓 Learning Resources

### Scoop Academy

Free courses available:
1. **Scoop Basics** (30 min): First queries to insights
2. **Advanced Analytics** (1 hr): ML and predictions
3. **Power User** (2 hr): Automation and workflows
4. **Admin Guide** (1 hr): Setup and management

### Community

Join the Scoop community:
- **User Slack**: scoopusers.slack.com
- **Office Hours**: Thursdays 2 PM ET
- **Webinars**: Monthly feature deep-dives
- **User Conference**: Annual ScoopCon

---

**Still stuck?** Remember, Scoop learns and improves. If something isn't working as expected, let us know - your feedback makes Scoop better for everyone! 🚀