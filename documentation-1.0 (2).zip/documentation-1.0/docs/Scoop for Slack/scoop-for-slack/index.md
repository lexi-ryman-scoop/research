---
title: Scoop for Slack
deprecated: false
hidden: false
metadata:
  robots: index
---
# Scoop for Slack

Transform your Slack workspace into a powerful analytics hub. Ask questions in plain English, get insights powered by AI.

## What is Scoop for Slack?

![](https://files.readme.io/364f1635e03cfd5179380fc149a79144f395198f1ccf2ad42e9aeb2b3db046f3-image.png)

Scoop brings enterprise-grade analytics directly into Slack through:
- **Natural Language Queries**: Just ask questions like you would to a colleague
- **AI-Powered Analysis**: From simple queries to complex multi-step investigations
- **Machine Learning**: Advanced algorithms accessible to everyone
- **Dataset Flexibility**: Switch between datasets seamlessly
- **Collaborative Insights**: Share and discuss findings with your team

## Key Capabilities

### 🧠 Deep Reasoning Engine
Ask "why" questions and watch Scoop investigate like a data scientist:
- Multi-step analysis with real-time progress
- Transparent reasoning you can follow
- Confidence levels and evidence trails
- Business impact assessment

### 🤖 Advanced Machine Learning
Enterprise ML without complexity:
- **Predictive Analytics**: What factors drive outcomes?
- **Segmentation**: Find natural customer groups
- **Comparison Analysis**: Understand population differences
- **Pattern Detection**: Discover hidden relationships

### 📊 Flexible Dataset Management
Work with multiple datasets efficiently:
- Quick dataset switching
- Personal and organizational datasets
- Automatic data refresh
- Secure data isolation

### 💬 Where You Already Work
Native Slack experience:
- Direct messages for private analysis
- Channel mentions for team collaboration
- Thread-based conversations
- File uploads via drag-and-drop

## Getting Started

1. [Install Scoop](getting-started-with-scoop-for-slack.md) in your workspace
2. [Upload data](uploading-and-analyzing-files.md) or connect existing datasets
3. [Start asking questions](using-scoop-in-direct-messages.md) in natural language
4. [Share insights](using-scoop-in-channels.md) with your team

## Quick Examples

```
📊 "Show me revenue trends"
🔍 "Why did churn increase last month?"
🤖 "What predicts customer lifetime value?"
📈 "Compare this quarter to last quarter"
📊 "Show me customer satisfaction metrics"
```

## Documentation Guide

### Getting Started
- [Getting Started with Scoop](getting-started-with-scoop-for-slack.md) - Installation and setup
- [Understanding Scoop AI](understanding-scoop-ai.md) - How our AI works

### Core Features
- [Using Direct Messages](using-scoop-in-direct-messages.md) - Private analysis workspace
- [Using Channels](using-scoop-in-channels.md) - Team collaboration
- [Uploading Files](uploading-and-analyzing-files.md) - Data import guide
- [Working with Datasets](working-with-datasets-in-scoop-for-slack.md) - Dataset management

### Advanced Analytics
- [Personal Decks & Saved Queries](personal-decks-saved-queries.md) - Automate your analytics
- [Machine Learning Analytics](machine-learning-analytics.md) - ML made simple
- [Advanced Features](advanced-features.md) - Deep reasoning & automation
- [Visualizations & Exports](visualizations-exports.md) - Charts and sharing

### Enterprise Features
- [Enterprise Slack Sharing](enterprise-slack-sharing.md) - Channel-specific dataset access
- [Bring Your Own Key (BYOK)](../../Enterprise%20Features/bring-your-own-key-byok.md) - Use your own AI API keys

### Support
- [FAQ & Troubleshooting](faq-troubleshooting.md) - Common questions and fixes

## Why Teams Love Scoop

### For Leaders
- Instant answers to strategic questions
- No waiting for analyst reports
- Confidence levels on all insights
- Natural language, no training needed

### For Analysts
- Automate routine queries
- Focus on strategic work
- Share insights instantly
- Collaborate on findings

### For Teams
- Democratized data access
- Shared source of truth
- Discussion around insights
- No context switching

## Quick Start Examples

### Sales Team
```
@Scoop what deals are at risk this quarter?
@Scoop why did win rate drop last month?
@Scoop which factors predict deal success?
```

### Marketing Team
```
@Scoop which campaigns drive quality leads?
@Scoop segment our audience by behavior
@Scoop how does engagement predict conversion?
```

### Customer Success
```
@Scoop which customers are likely to churn?
@Scoop what drives customer satisfaction?
@Scoop compare successful vs struggling accounts
```

### Operations
```
@Scoop where are our process bottlenecks?
@Scoop predict next month's support volume
@Scoop what causes delivery delays?
```

## Need Help?

- Type `@Scoop help` in Slack
- Visit [docs.scoopanalytics.com](https://docs.scoopanalytics.com)
- Email support@scoopanalytics.com
- Join our community at scoopusers.slack.com