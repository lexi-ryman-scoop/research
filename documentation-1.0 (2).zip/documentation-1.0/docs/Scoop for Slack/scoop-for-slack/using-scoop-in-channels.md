---
title: Using Scoop in Channels
deprecated: false
hidden: false
metadata:
  robots: index
---
# Collaborative Analytics in Slack Channels

Transform your team's decision-making with AI-powered insights delivered right where you work.

## The Power of Channel Analytics

Scoop in channels revolutionizes team collaboration:

### 🔐 Privacy-First Design
- Initial responses are private (only visible to you)
- Iterate and refine without channel noise
- Share when insights are ready
- Maintain clean channel conversations

### 🤝 Seamless Collaboration
- Natural language queries in team context
- One-click sharing of discoveries
- Build on each other's insights
- Preserve institutional knowledge

### ⚡ Real-Time Decision Support
- Answer questions during discussions
- Validate assumptions instantly
- Provide data-backed evidence
- Accelerate consensus building

## Getting Started in Channels

### Adding Scoop to Your Channel

**Option 1: Direct Invite**
```
/invite @Scoop
```

**Option 2: First Mention**
- Simply @mention Scoop in any message
- Slack prompts to add Scoop if not present
- Click "Invite Them" to proceed

### Your First Channel Query

Just @mention Scoop with natural language:

```
@Scoop what were our top performing products last month?
```

```
@Scoop compare this quarter's pipeline to last quarter
```

```
@Scoop show me customer satisfaction trends with confidence levels
```

!\[Screenshot: User mentioning @Scoop in a channel with a query]

## Understanding Private Responses

### Why Private by Default?

Scoop's ephemeral responses protect your workflow:

🔍 **Exploration Freedom**
- Test queries without team visibility
- Refine questions iteratively
- Fix typos or clarify intent
- Build confidence before sharing

🎯 **Channel Hygiene**
- Avoid cluttering team discussions
- Keep channels focused on decisions
- Reduce notification fatigue
- Maintain signal-to-noise ratio

### Private Response Indicators

```
(Only visible to you)
━━━━━━━━━━━━━━━━━━━━
📊 Revenue Analysis for Q4

Total Revenue: $2.4M (+18% QoQ)
Top Segment: Enterprise (62%)
Growth Driver: New Logo acquisition

[📢 Share with Channel] [💬 Continue in DM]
```

!\[Screenshot: Private Scoop response showing "Only visible to you" indicator]

## Smart Sharing Features

### One-Click Sharing

Transform private insights into team knowledge:

1. **Review your insight** - Ensure accuracy and relevance
2. **Click "📢 Share with Channel"** - Single action sharing
3. **Automatic formatting** - Scoop optimizes for readability
4. **Full attribution** - Your discovery is credited

### Enhanced Shared Messages

```
👤 Sarah Williams discovered:
━━━━━━━━━━━━━━━━━━━━━━━━━━

🔍 Query: "What's driving our APAC growth?"

📈 Key Findings:
• Partner channel contributing 45% of growth
• Enterprise segment up 67% YoY
• New product adoption at 34%

💡 Insight: Partner-driven enterprise deals in 
Singapore and Australia are primary growth engines

[📊 View Details] [🔄 Run Similar] [💬 Discuss]
```

!\[Screenshot: Shared Scoop insight in channel with attribution]

### What Gets Shared

✅ **Always Included:**
- Complete analysis results
- Visualizations and tables
- AI-generated insights
- Statistical confidence levels
- Your name as discoverer
- Original query for context

❌ **Never Shared:**
- Your exploration history
- Failed query attempts
- Private iterations
- Sensitive filters you tested

## Channel Analytics Best Practices

### 🎯 Query Strategies

**1. Context-Rich Questions**
```
@Scoop for tomorrow's pipeline review, show me deals 
stuck in negotiation for >30 days
```

**2. Progressive Refinement**
```
@Scoop show Q4 performance
@Scoop break that down by product line
@Scoop focus on enterprise segment only
@Scoop what's driving the growth in cloud products?
```

**3. Hypothesis Testing**
```
@Scoop test if longer sales cycles correlate with 
higher deal values
```

### 🔄 When to Switch to DM

Use the "Continue in DM" button when:

- You need 5+ query iterations
- Exploring sensitive scenarios
- Building complex analyses
- Learning Scoop's capabilities
- Preparing detailed reports

!\[Screenshot: "Continue in DM" button on Scoop response]

### 📊 Share-Worthy Insights

**High-Value Shares:**
- 🚨 Anomalies requiring attention
- 📈 Positive trends to celebrate
- 🎯 Goal achievement updates
- ⚠️ Risk indicators
- 💡 Unexpected discoveries
- 🔮 Predictive insights

**Timing Your Shares:**
- During active discussions
- Start of team meetings
- End of sprint reviews
- When decisions are needed
- To answer posted questions

## Advanced Channel Features

### 🗂️ Smart Dataset Mapping

**Automatic Context Detection**
Scoop intelligently selects datasets based on:
- Channel name and purpose
- Team membership patterns
- Historical query context
- Admin configurations

**Channel-Dataset Examples:**
```
#sales-team → CRM + Pipeline data
#marketing → Campaign + Lead data
#customer-success → Support + Usage data
#finance → Revenue + Billing data
```

**Override When Needed:**
```
@Scoop use marketing dataset: show me campaign ROI
```

### 🔔 Intelligent Notifications

**Notification Behaviors:**
- Shared insights notify @channel or @here based on importance
- Thread responses for continued discussion
- Highlight mentions in discoveries
- Smart batching to reduce noise

### 🧵 Thread Intelligence

Scoop maintains context within threads:

```
 Original: @Scoop why did revenue drop in March?
   ↳ Reply: @Scoop dig deeper into the enterprise segment
   ↳ Reply: @Scoop compare to March last year
   ↳ Reply: @Scoop what actions can we take?
```

### 🎭 Role-Based Responses

Scoop adapts communication style:
- **Executive channels**: High-level summaries
- **Analyst channels**: Detailed statistics
- **Sales channels**: Action-oriented insights
- **Support channels**: Problem-focused analysis

## Collaborative Intelligence Patterns

### 🏢 Meeting Support Workflows

**Pre-Meeting Preparation**
```
@Scoop create a dashboard for our weekly pipeline review:
- Current quarter forecast
- Deal velocity trends  
- Risk analysis
- Rep performance
```

**Live Meeting Support**
```
CEO: "What's our customer acquisition cost trending?"
You: @Scoop show CAC trend for last 6 months by channel

[Real-time answer appears privately]
[Share when validated]
```

**Post-Meeting Actions**
```
@Scoop based on our discussion, identify the top 5 
at-risk deals we need to focus on this week
```

### 🤝 Cross-Functional Collaboration

**Sales ↔ Marketing Alignment**
```
#sales-marketing-sync channel:

Sales: @Scoop which marketing campaigns generate 
       highest quality leads?
       
Marketing: @Scoop show conversion rates by campaign 
           and sales rep
```

**Product ↔ Customer Success**
```
#product-feedback channel:

CS: @Scoop what features correlate with low NPS scores?

Product: @Scoop analyze feature requests by customer 
         segment and MRR
```

### 📈 Performance Tracking

**Daily Standups**
```
@Scoop morning update: yesterday's metrics vs. target
```

**Weekly Reviews**
```
@Scoop week-over-week comparison of key KPIs with 
variance analysis
```

**Monthly Business Reviews**
```
@Scoop generate executive summary:
- Revenue attainment
- Growth drivers
- Risk factors
- Recommendations
```

## Quick Reference Guide

### 📝 Essential Commands

| Command | Purpose | Example |
|---------|---------|----------|
| `@Scoop help` | Show capabilities | Get command reference |
| `@Scoop datasets` | List available data | See all data sources |
| `@Scoop use [dataset]` | Switch dataset | `@Scoop use sales data` |
| `@Scoop status` | Current context | Check active dataset |
| `@Scoop export` | Download results | Get Excel/CSV file |

### 💬 Natural Language Patterns

**Comparison Queries**
```
@Scoop compare this month to last month
@Scoop benchmark us against industry standards
@Scoop show difference between A and B
```

**Predictive Questions**
```
@Scoop forecast next quarter revenue
@Scoop what predicts customer churn?
@Scoop predict deal close probability
```

**Investigative Analysis**
```
@Scoop why did metrics drop last week?
@Scoop what's driving growth in EMEA?
@Scoop find anomalies in this month's data
```

**Segmentation Requests**
```
@Scoop segment customers by behavior
@Scoop group accounts by potential
@Scoop cluster similar patterns
```

### 🎨 Visualization Options

```
@Scoop create a line chart of...
@Scoop show this as a pie chart
@Scoop visualize the correlation
@Scoop make a dashboard with...
```

### ⚡ Power User Shortcuts

**Chain Operations**
```
@Scoop analyze sales, predict next month, and 
identify top opportunities
```

**Conditional Analysis**
```
@Scoop if conversion > 50%, show factors; 
else show improvement areas
```

**Multi-Dataset Query**
```
@Scoop correlate support tickets with renewal rates
```

## Channel Success Stories

### 🏆 Real Team Wins

**Sales Team Victory**
> "During our pipeline review, @Scoop instantly showed 
> us 8 deals at risk we hadn't noticed. We saved $400K 
> in potential losses."
> - Sarah, Sales Director

**Marketing Breakthrough**
> "@Scoop revealed our webinar attendees convert 3x 
> better than other leads. We doubled down and hit 
> 142% of our target."
> - Mike, Marketing Manager

**Support Excellence**
> "Using @Scoop in our support channel, we identified 
> a pattern in tickets that led to a product fix, 
> reducing tickets by 30%."
> - Lisa, Support Lead

## Next Steps

### Continue Your Journey

1. 💬 **[Master Direct Messages](using-scoop-in-direct-messages.md)** - Deep personal analysis
2. 📊 **[Explore Datasets](working-with-datasets-in-scoop-for-slack.md)** - Data management
3. 🤖 **[Unlock ML Power](machine-learning-analytics.md)** - Advanced analytics
4. 🚀 **[Advanced Features](advanced-features.md)** - Deep reasoning & automation

### Pro Tips for Channel Success

1. **Start simple** - Build confidence with basic queries
2. **Share wins** - Celebrate insights with your team  
3. **Ask why** - Let Scoop's reasoning engine investigate
4. **Iterate publicly** - Show others how to refine queries
5. **Build knowledge** - Your shares become team resources

**Transform your channel into a data-driven command center with Scoop!**