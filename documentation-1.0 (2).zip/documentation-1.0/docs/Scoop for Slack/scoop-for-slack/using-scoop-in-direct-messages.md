---
title: Using Scoop in Direct Messages
deprecated: false
hidden: false
metadata:
  robots: index
---
# Direct Messages: Your Personal Analytics Workspace

Transform your data exploration with Scoop's powerful DM interface - where complex analysis meets conversational simplicity.

## Why Use Direct Messages?

Direct messages with Scoop provide your personal analytics command center:

### 🔒 Complete Privacy
- All queries and results stay between you and Scoop
- Experiment freely without team visibility
- Test analyses before sharing insights
- Work with sensitive data confidently

### 🚀 Maximum Efficiency
- No @ mentions required - just type naturally
- Instant responses without channel clutter
- Full conversation history and context
- Rapid iteration on complex analyses

### 🧠 Deep Analysis Sessions
- Multi-step investigations with context retention
- Progressive refinement of queries
- Complex ML and reasoning workflows
- Extended exploration without interruption

## Starting Your DM Session

### Method 1: Direct Navigation
1. Look for **Scoop** in your Apps section (left sidebar)
2. Click to open Scoop's profile
3. Click the **"Message"** button

### Method 2: Quick Start Command
1. Use Slack's quick switcher (Cmd/Ctrl + K)
2. Type "Scoop"
3. Select "Send a direct message to Scoop"

### Method 3: From Any Channel
1. See a Scoop response you want to explore?
2. Click **"Continue in DM"** button
3. Seamlessly transition to private analysis

### Method 4: From App Home
1. Navigate to Scoop's App Home tab
2. Click **"Start a Conversation"**
3. Begin with guided prompts

!\[Screenshot: Three ways to start a DM with Scoop]

## The DM Advantage

### Natural Conversation Flow

No @ mentions needed - just type like you're chatting with a colleague:

```
You: what were our top deals last quarter?
Scoop: Here are your top 10 deals from Q4...

You: interesting, which sales reps closed those?
Scoop: Breaking down by sales rep...

You: show me their win rates
Scoop: Analyzing win rates for these reps...
```

### Intelligent Context Retention

Scoop remembers your conversation context:
- Previous queries and results
- Applied filters and parameters
- Your analytical journey
- Dataset selections

### Progressive Analysis Building

Build complex analyses step by step:

```
You: show me customer churn
Scoop: [displays churn metrics]

You: add revenue impact
Scoop: [enhances with revenue data]

You: now predict next month
Scoop: [runs ML prediction]

You: what factors drive this?
Scoop: [launches deep reasoning analysis]
```

!\[Screenshot: DM conversation showing iterative refinement]

## Powerful DM-Only Features

### 📎 Instant File Analysis

Drag and drop or click to upload:
1. **Supported formats**: CSV, Excel, JSON, PDF reports
2. **Automatic processing**: Scoop detects structure and data types
3. **Immediate queries**: Start analyzing within seconds
4. **Smart suggestions**: Scoop recommends relevant analyses

```
[You upload sales_data.csv]

Scoop: ✅ Processed sales_data.csv
- 10,247 rows, 15 columns
- Date range: Jan 2023 - Dec 2023
- Key fields: revenue, customer, product, region

Suggested analyses:
• "Show revenue trends over time"
• "Which products drive most revenue?"
• "Segment customers by behavior"
```

!\[Screenshot: File upload in DM with Scoop]

### 🔬 Deep Reasoning Sessions

Perfect for complex investigations:

**Multi-Step Analysis**
```
You: Why did conversion drop last month?

Scoop: 🔍 Investigating conversion drop...
✓ Analyzing historical trends
✓ Checking seasonal patterns
✓ Examining campaign changes
✓ Reviewing competitor impacts

📊 Found 3 contributing factors...
```

**Hypothesis Testing**
```
You: Test if price changes affect churn

Scoop: 🧪 Testing hypothesis...
- Null: Price changes don't affect churn
- Alternative: Price changes influence churn
- Result: Significant correlation (p < 0.01)
- Impact: 10% price increase → 3.2% churn increase
```

### 🎯 Personal Analytics Workspace

**Private Experimentation**
- Test complex queries without judgment
- Learn Scoop's capabilities hands-on
- Build confidence before team sharing
- Explore edge cases freely

**Custom Report Building**
- Combine multiple analyses
- Create reusable query templates
- Build department-specific views
- Prepare executive summaries

### 💾 Saved Queries & Personal Decks

**Save Your Best Queries**

Never recreate the wheel - save queries for instant reuse:

```
You: show revenue by region with growth rates
Scoop: [displays comprehensive analysis]
You: save this as "Regional Performance Report"
Scoop: ✅ Saved! Run anytime with "run Regional Performance Report"
```

**Quick Save Options:**
- Natural language: "save this query"
- With name: "save as Monthly Summary"
- Button click: "💾 Save Query"
- Slash command: `/scoop save Monthly Summary`

**Running Saved Queries**

Execute any saved query with fresh data:
```
You: run Regional Performance Report
Scoop: 🔄 Running saved query with latest data...
[Updated results displayed]
```

**Managing Your Query Library**
```
You: list my saved queries
Scoop: 📚 Your saved queries:

1. "Regional Performance Report" 
   - Created: Dec 1, 2024
   - Last run: 2 days ago
   - Dataset: Sales Analytics

2. "Customer Health Check"
   - Created: Nov 28, 2024
   - Last run: Today
   - Dataset: Customer Success

3. "Weekly Pipeline Review"
   - Created: Nov 15, 2024
   - Last run: 1 week ago
   - Dataset: CRM Data

[Run Query] [Edit] [Delete] [Share]
```

**Building Personal Decks**

Combine saved queries into powerful analytics workflows:

```
You: create deck "Monday Morning Dashboard"
Scoop: 🎯 Created new deck. Add queries by saying "add to deck"

You: run Regional Performance Report
Scoop: [displays results]
You: add to deck
Scoop: ✅ Added (1 query in deck)

You: show pipeline velocity
Scoop: [displays metrics]
You: add this to deck
Scoop: ✅ Added (2 queries in deck)
```

**Run Your Deck**
```
You: run my Monday Morning Dashboard
Scoop: 📊 Running deck with 5 queries...

[Executes all queries in sequence]
[Fresh data for every query]
[Combined insights delivered]
```

## Mastering DM Analytics

### 🎯 The Progressive Query Pattern

Start broad, then narrow intelligently:

```
1️⃣ Overview
You: summarize the sales dataset
Scoop: Dataset contains 50K transactions...

2️⃣ Focus
You: show me enterprise customers only
Scoop: Filtering to 8,421 enterprise transactions...

3️⃣ Analyze
You: what drives their purchase decisions?
Scoop: Running ML analysis on purchase factors...

4️⃣ Predict
You: forecast their Q1 revenue
Scoop: Building predictive model...

5️⃣ Act
You: which accounts need attention?
Scoop: 15 accounts show risk signals...
```

### 🧠 Advanced Query Techniques

**Multi-Dimensional Analysis**
```
"Compare revenue by product, region, and time"
"Show me the intersection of high-value and high-risk"
"Correlate support tickets with renewal probability"
```

**Conditional Logic**
```
"If churn is above 5%, show me the causes"
"When revenue drops, what typically happens next?"
"For customers like Acme Corp, what works best?"
```

**Comparative Analytics**
```
"Compare this month to same month last year"
"How do we stack up against industry benchmarks?"
"What's different about our top vs bottom performers?"
```

### 💡 Power User Tips

**Query Templates to Save**
```
# Weekly Executive Dashboard
"Revenue MTD vs target, top deals, at-risk accounts, team performance"

# Customer Health Check
"Usage trends, support tickets, payment history, engagement score"

# Predictive Pipeline Review
"Forecast accuracy, deal velocity, stage conversion, rep performance"
```

**Context Shortcuts**
- "same analysis for EMEA" - Applies previous analysis to new segment
- "add that to the report" - Builds on existing results
- "dig deeper on outliers" - Investigates anomalies
- "make it visual" - Converts tables to charts

## Sharing Your Discoveries

### 📤 Smart Sharing Options

Found insights worth sharing? Multiple paths:

**1. Direct Channel Share**
```
✅ Click "Share with Channel" on any result
✅ Select target channel(s)
✅ Add context or commentary
✅ Scoop preserves formatting and visuals
```

**2. Refined Sharing**
```
✅ Click "Prepare for Sharing"
✅ Edit or annotate results
✅ Add executive summary
✅ Share polished insights
```

!\[Screenshot: Channel selector when sharing from DM]

**3. Export Options**
- **Excel**: Full data with formatting
- **PDF**: Presentation-ready reports
- **PNG**: Chart images for slides
- **CSV**: Raw data for further analysis

### 🎯 Sharing Best Practices

**Add Context**
```
"Team, here's the churn analysis we discussed:
- 23% of enterprise accounts at risk
- Primary driver: Poor onboarding
- Recommended action: Immediate outreach"
[Shared Scoop Analysis]
```

**Highlight Key Findings**
- Use Slack formatting to emphasize insights
- Add numbered takeaways
- Include recommended actions
- Tag relevant stakeholders

## Real-World DM Workflows

### 📊 Executive Morning Brief

```
You: Good morning - what should I know?

Scoop: 🌅 Morning Intelligence Brief:

📈 Key Metrics (vs. yesterday)
- Revenue: $127K (+12%)
- New Customers: 23 (+4)
- Churn: 2 accounts (-1)
- NPS: 72 (+3 points)

🚨 Requires Attention:
- Enterprise deal at risk ($450K)
- Support backlog growing (18% above normal)
- APAC revenue below target (-$32K)

✨ Positive Highlights:
- Record trial conversions (42%)
- Product adoption up 15%
- Sales team at 94% of quota

Would you like details on any area?
```

### 🔍 Root Cause Investigation

```
You: Revenue dropped 20% in March - why?

Scoop: 🔍 Investigating March revenue drop...

📊 Analysis Complete:

1. Seasonal Impact (30% of drop)
   - Historical March dip: -8-12%
   - This year: Amplified by market conditions

2. Lost Enterprise Deals (45% of drop)
   - TechCorp: $180K (went to competitor)
   - GlobalRetail: $210K (delayed to Q2)
   - Manufacturing Inc: $165K (budget frozen)

3. Reduced Expansion (25% of drop)
   - Existing customers postponing upgrades
   - Average expansion down from $45K to $28K

🎯 Recovery Actions:
- Re-engage lost deals for Q2
- Launch win-back campaign
- Accelerate Q2 pipeline

Want me to analyze win/loss patterns?
```

### 🎯 Strategic Planning Session

```
You: Help me identify our ideal customer profile

Scoop: 🎯 Analyzing customer patterns...

🏆 Ideal Customer Profile Discovered:

Demographics:
- Industry: Technology, Financial Services
- Size: 500-5000 employees
- Growth rate: 20%+ YoY
- Tech stack: Modern, cloud-first

Behavioral Indicators:
- Quick decision making (<45 day cycle)
- Multiple stakeholders engaged early
- Clear business pain identified
- Executive sponsor involved

Value Metrics:
- LTV: $380K average (3.2x overall average)
- Churn: 5% (vs. 18% average)
- Expansion rate: 140% net retention
- Support needs: 60% lower

Current Pipeline Match: 34 accounts fit ICP
Potential value: $12.9M

Shall I score all prospects against this ICP?
```

### 📈 Predictive Analytics Workflow

```
You: Predict Q1 revenue and risks

Scoop: 🔮 Building Q1 forecast model...

📊 Q1 Revenue Forecast:

Base Prediction: $4.2M (85% confidence)
- Confirmed pipeline: $2.8M
- Predicted closures: $1.1M
- Expansion revenue: $300K

Range: $3.9M - $4.5M

⚠️ Key Risks Identified:

1. Large Deal Dependency (Impact: -$400K)
   - MegaCorp decision delayed
   - Mitigation: Executive alignment meeting

2. Renewal Concerns (Impact: -$220K)
   - 3 accounts showing risk signals
   - Mitigation: Immediate success team intervention

3. Competition (Impact: -$180K)
   - Competitor aggressive pricing
   - Mitigation: Value differentiation campaign

✅ Upside Opportunities:
- Fast-track implementations: +$150K
- New product launch: +$200K
- Partner channel: +$100K

Want scenario planning for these risks?
```

## Pro Tips for DM Mastery

### 🚀 Productivity Shortcuts

**Reference Previous Results**
- "apply the same analysis to Q2 data"
- "show that in a chart instead"
- "break down the third row"
- "export everything we just discussed"

**Chain Complex Operations**
```
"Upload this file, clean the data, find patterns, 
predict next month, and create a summary"
```

**Use Contextual Commands**
- "zoom in on the anomaly"
- "explain that in business terms"
- "what should we do about this?"
- "how confident are you?"

### 💡 Hidden Power Features

**Smart Dataset Switching in DM**
```
"Switch to sales dataset"
"Show me the marketing data"
"Use my personal analytics file"
```

**Advanced ML Without Code**
```
"Segment customers by behavior patterns"
"What predicts account expansion?"
"Find anomalies in this month's data"
```

**Natural Language Calculations**
```
"Calculate customer lifetime value"
"What's our burn rate trending?"
"Show cohort retention curves"
```

### 🎯 When to Use DMs vs Channels

**Use DMs for:**
- Initial exploration and experimentation
- Sensitive data analysis
- Complex multi-step investigations
- Personal productivity workflows
- Learning and skill building

**Use Channels for:**
- Team collaboration on insights
- Shared dashboards and reports
- Real-time decision making
- Building collective knowledge
- Stakeholder updates

### 🔧 Troubleshooting in DMs

**If Scoop seems confused:**
- Start fresh with "let's begin a new analysis"
- Be more specific about your dataset
- Break complex questions into steps

**If results aren't what you expected:**
- Ask "explain how you calculated this"
- Try "show me the raw data"
- Request "verify this makes sense"

**If you need help:**
- Type "help" for command reference
- Ask "what can you do?"
- Say "show me examples"

## Your Analytics Journey Continues

### Start Now
1. Open a DM with Scoop
2. Upload your data or select a dataset
3. Ask your burning business question
4. Watch AI-powered insights unfold

### Next Steps
- 📊 [Working with Datasets](working-with-datasets-in-scoop-for-slack.md) - Master data management
- 🤖 [Machine Learning Analytics](machine-learning-analytics.md) - Unlock predictive power
- 👥 [Using Scoop in Channels](using-scoop-in-channels.md) - Collaborate with insights
- 🧠 [Understanding Scoop AI](understanding-scoop-ai.md) - How the magic works

Remember: Every expert was once a beginner. Start with simple questions and build your analytical confidence. Scoop grows more powerful as you explore its capabilities.

**Ready to transform your data into decisions? Start a DM with Scoop now!**