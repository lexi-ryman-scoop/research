---
title: Personal Decks & Saved Queries
deprecated: false
hidden: false
metadata:
  robots: index
---
# Personal Decks & Saved Queries: Your Analytics Automation Toolkit

Transform repetitive analysis into one-click insights. Build your personal library of queries and combine them into powerful decks for instant intelligence.

## 📚 What Are Saved Queries?

Saved queries are your personal analytics shortcuts - capture any analysis and rerun it with fresh data anytime. Perfect for:

- **Recurring Reports**: Weekly metrics, monthly summaries
- **Complex Analyses**: Multi-step queries you've perfected
- **Team Standards**: Consistent metrics everyone uses
- **Time Savers**: Never recreate the wheel

## 💾 Saving Your First Query

### Method 1: Natural Language

```
You: Show revenue by product category with YoY growth
Scoop: [displays comprehensive analysis]
You: save this as "Product Performance Report"
Scoop: ✅ Saved query "Product Performance Report"

You can now run this anytime by saying:
- "run Product Performance Report"
- "/scoop run Product Performance Report"
```

### Method 2: Button Click

After any query result, click the **💾 Save Query** button:

```
[Your analysis results here]

[📥 Export] [📢 Share] [💾 Save Query] [Menu]
        ↓
  Enter query name: "Weekly Pipeline Review"
  [Save] [Cancel]
```

### Method 3: Slash Command

```
/scoop save Monthly Customer Health Check
```
This saves your most recent query with the specified name.

### Smart Naming Tips

**✅ Good Names:**
- "Weekly Sales Pipeline Review"
- "Monday Morning Metrics"
- "Customer Health Check Q4"
- "Executive Revenue Summary"

**❌ Avoid:**
- "Query 1"
- "Test"
- "Revenue" (too generic)
- "asdfasdf"

## 🔄 Running Saved Queries

### Quick Execution

```
You: run Product Performance Report
Scoop: 🔄 Running saved query with latest data...

📊 Product Performance Report
━━━━━━━━━━━━━━━━━━━━━━━━━━━
Updated: Just now
Dataset: Sales Analytics (current data)

[Fresh results with current data displayed]
```

### Slash Command

```
/scoop run Weekly Pipeline Review
```

### From Your Library

```
You: list my saved queries
Scoop: 📚 Your Saved Query Library:

1. "Product Performance Report" 
   Created: Dec 1 | Last run: 2 days ago | Dataset: Sales

2. "Weekly Pipeline Review"
   Created: Nov 28 | Last run: Today | Dataset: CRM

3. "Customer Health Metrics"
   Created: Nov 15 | Last run: 1 week ago | Dataset: Success

[Run] [Edit] [Delete] [Add to Deck]
```

## 🎯 Personal Decks: Query Collections

Personal decks are collections of saved queries that run together - think of them as your analytics playlists. Create comprehensive dashboards with a single command.

### Creating Your First Deck

```
You: create deck "Monday Executive Dashboard"
Scoop: 🎯 Created new deck "Monday Executive Dashboard"

Now add queries by:
1. Running any query and saying "add to deck"
2. Adding from your saved queries
3. Creating new queries to add
```

### Building Your Deck

**Add Current Results:**
```
You: Show weekly revenue trend with forecast
Scoop: [displays chart]
You: add this to my Monday Executive Dashboard
Scoop: ✅ Added to deck (1 query)
```

**Add Saved Queries:**
```
You: add "Product Performance Report" to my deck
Scoop: ✅ Added saved query to deck (2 queries)
```

**Add Multiple Queries:**
```
You: Show me pipeline velocity
Scoop: [displays metrics]
You: add to deck

You: What are our top risk accounts?
Scoop: [displays list]
You: add to deck

You: Forecast next month's revenue
Scoop: [displays prediction]
You: add to deck

Scoop: ✅ Your deck now has 5 queries
```

## 📊 Running Decks

### Execute Your Deck

```
You: run my Monday Executive Dashboard
Scoop: 📊 Running deck "Monday Executive Dashboard"...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Query 1/5: Weekly Revenue Trend
[Chart displayed]

Query 2/5: Product Performance  
[Analysis displayed]

Query 3/5: Pipeline Velocity
[Metrics displayed]

Query 4/5: At-Risk Accounts
[List displayed]

Query 5/5: Revenue Forecast
[Predictions displayed]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Deck complete! All queries executed in 23 seconds.

[📥 Export All] [📊 Export to PowerPoint] [📢 Share Results]
```

### Quick Deck Execution

```
/scoop deck
```
Runs your most recently used deck.

### List Your Decks

```
You: show my decks
Scoop: 🗂️ Your Personal Deck Library:

📊 "Monday Executive Dashboard" (5 queries)
   Last run: 2 days ago
   Contents: Revenue, Products, Pipeline, Risk, Forecast
   
📈 "Weekly Team Review" (7 queries)
   Last run: Yesterday
   Contents: Performance, Goals, Blockers, Wins...
   
🎯 "Customer Success Scorecard" (4 queries)
   Last run: 1 week ago
   Contents: Health, Churn, Upsell, Support

[Run Deck] [Edit] [Share] [Export Template]
```

## 📤 Exporting Decks to PowerPoint

### One-Click PowerPoint Generation

After running any deck:

```
[📊 Export to PowerPoint]
        ↓
Scoop: 🎨 Generating PowerPoint presentation...

✅ Created "Monday Executive Dashboard.pptx"
- Title slide with date/time
- 5 content slides (one per query)
- Formatted charts and tables
- Executive summary slide
- Appendix with details

[📥 Download PowerPoint] [✉️ Email] [🔗 Share Link]
```

### PowerPoint Features

**Automatic Formatting:**
- Company branding applied (if configured)
- Consistent slide layouts
- High-resolution charts
- Formatted data tables
- Speaker notes with insights

**Slide Structure:**
```
Slide 1: Title & Agenda
Slide 2: Weekly Revenue Trend (with chart)
Slide 3: Product Performance (with table)
Slide 4: Pipeline Velocity (with metrics)
Slide 5: At-Risk Accounts (with action items)
Slide 6: Revenue Forecast (with confidence levels)
Slide 7: Executive Summary
Slide 8: Appendix & Methodology
```

### Customization Options

```
You: export deck to PowerPoint with dark theme
You: create PowerPoint with speaker notes
You: export deck as editable PowerPoint
```

## 🛠️ Managing Queries and Decks

### Edit Saved Queries

```
You: edit "Product Performance Report"
Scoop: 📝 Editing saved query...

Current query: "Show revenue by product category with YoY growth"
[Edit Query Text] [Update Name] [Change Dataset] [Save] [Cancel]
```

### Modify Decks

```
You: remove "Pipeline Velocity" from Monday Executive Dashboard
Scoop: ✅ Removed. Deck now has 4 queries.

You: reorder deck with Revenue Forecast first
Scoop: ✅ Reordered. New sequence:
1. Revenue Forecast
2. Weekly Revenue Trend
3. Product Performance
4. At-Risk Accounts
```

### Share Templates

```
You: share my Monday Executive Dashboard template
Scoop: 📤 Sharing options:

1. Export deck template (JSON)
2. Share query list (text)
3. Create team deck (admin only)
4. Generate setup instructions

[Export Template] [Copy Share Text]
```

## 💡 Advanced Features

### Conditional Queries

Add logic to your decks:

```
You: add "If churn rate > 5%, analyze churn drivers" to deck
Scoop: ✅ Added conditional query. Will only run if condition is met.
```

### Parameterized Queries

Create flexible templates:

```
You: save "Revenue for [TIME_PERIOD] by [DIMENSION]" as template
Scoop: ✅ Saved parameterized query template

You: run template with "last quarter" and "region"
Scoop: Running: Revenue for last quarter by region...
```

### Scheduled Decks (Coming Soon)

```
You: schedule Monday Executive Dashboard for Mondays at 8am
Scoop: ⏰ Deck scheduled. You'll receive results via:
- Slack DM
- Email summary
- PowerPoint attachment
```

### Deck Insights

```
You: analyze my deck usage
Scoop: 📊 Deck Analytics:

Most run deck: "Monday Executive Dashboard" (52 times)
Average runtime: 18 seconds
Most edited query: "Revenue Forecast"
Time saved: ~4 hours/month
```

## 🎯 Best Practices

### Organize by Purpose

**Daily Operations Deck:**
- Key metrics snapshot
- Anomaly alerts
- Team performance
- Action items

**Weekly Review Deck:**
- Trend analysis
- Goal progress
- Pipeline health
- Competitive intel

**Monthly Executive Deck:**
- Strategic KPIs
- Predictive insights
- Market analysis
- Recommendations

### Query Design Tips

1. **Make them reusable**: Avoid hard-coded dates
2. **Clear naming**: Others should understand from name
3. **Add context**: Include brief descriptions
4. **Version control**: Date significant changes

### Deck Optimization

1. **Logical flow**: Tell a story with your queries
2. **Load balance**: Mix heavy and light queries
3. **Action focus**: End with next steps
4. **Time conscious**: Keep under 10 queries

## 🚀 Power User Workflows

### Morning Intelligence Brief

```
Deck: "Daily Intelligence"
1. Overnight anomalies
2. Key metric changes
3. At-risk alerts
4. Competitor updates
5. Team achievements

Auto-export to PowerPoint for 9am standup
```

### Board Meeting Prep

```
Deck: "Board Package"
1. Executive summary
2. Financial performance
3. Strategic initiatives
4. Risk assessment
5. Forecast & guidance

Export to PowerPoint with appendix
```

### Team Performance Review

```
Deck: "Team Scorecard"
1. Individual metrics
2. Team comparisons
3. Goal progress
4. Improvement areas
5. Recognition highlights

Share in team channel weekly
```

## 🔧 Troubleshooting

### Common Issues

**"Query not found"**
- Check exact name and spelling
- Verify query hasn't been deleted
- Try listing all saved queries

**"Deck won't run"**
- Ensure all queries in deck still exist
- Check dataset access
- Verify no syntax errors

**"Export failed"**
- Check export size limits
- Ensure visualization compatibility
- Try exporting queries individually

### Tips for Success

1. **Start small**: Build decks incrementally
2. **Test regularly**: Ensure queries stay relevant
3. **Document purpose**: Add descriptions to complex queries
4. **Share knowledge**: Export templates for team use

## Next Steps

Ready to automate your analytics?

1. **Save your most-used query** right now
2. **Create your first deck** with 3-5 queries
3. **Run it tomorrow** to see the time savings
4. **Export to PowerPoint** for your next meeting
5. **Share templates** with your team

Transform hours of analysis into seconds of insight with Personal Decks & Saved Queries! 🚀