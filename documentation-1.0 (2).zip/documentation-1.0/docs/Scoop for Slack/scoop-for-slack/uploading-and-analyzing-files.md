---
title: Uploading and Analyzing Files
deprecated: false
hidden: false
metadata:
  robots: index
---
# File Upload: Your Data, Instant Insights

Transform spreadsheets into insights in seconds. Upload, analyze, and share discoveries without leaving Slack.

## Why Upload Files to Scoop?

### 🚀 Instant Analysis
- Upload → Insights in under 10 seconds
- No data warehouse needed
- No SQL or coding required
- Natural language queries on your data

### 🔒 Complete Privacy
- Personal datasets stay private
- Share only what you choose
- Secure processing and storage
- Full control over your data

### 🎯 Perfect For
- Ad-hoc analysis requests
- External data exploration
- Quick data validation
- Combining multiple sources
- One-time reports
- Proof of concepts

!\[Screenshot: File upload process in Slack]

## Supported File Formats

### 📊 Excel Files (.xlsx, .xls)
- **Single or multi-sheet** workbooks
- **Automatic sheet detection** - Scoop finds your data
- **Formula support** - Calculated values preserved
- **Formatting aware** - Dates, currencies, percentages
- **Smart sampling** - Large files handled efficiently

### 📄 CSV Files (.csv)
- **Flexible delimiters** - Comma, tab, pipe, semicolon
- **Encoding support** - UTF-8, ASCII, Latin-1
- **Header detection** - Automatic or manual
- **Quote handling** - Embedded commas supported
- **Large file optimization** - Streaming for performance

### 📑 Coming Soon
- JSON files for API data
- PDF tables extraction
- Google Sheets direct import
- Database exports

### File Requirements

| Requirement | Details |
|------------|---------|
| **Max Size** | 100MB (larger files coming soon) |
| **Structure** | Tabular data with headers |
| **Format** | One header row + data rows |
| **Quality** | No merged cells or complex layouts |
| **Encoding** | UTF-8 recommended |

## Upload Methods

### Method 1: Direct Message Upload (Recommended)

**Step-by-Step:**
1. Open DM with Scoop
2. Click the **paperclip icon** 📎
3. Select your file(s)
4. Add optional context: "This is Q4 sales data"
5. Press Enter to upload

```
You: [Uploading sales_q4.xlsx] This is our Q4 sales data

Scoop: 📁 Received sales_q4.xlsx (2.4MB)
Would you like me to analyze this file?
[✅ Yes, Import] [❌ Skip]
```

!\[Screenshot: File upload button in Slack DM]

### Method 2: Drag and Drop

Simply drag files directly into:
- DM conversation with Scoop
- Channel where Scoop is present
- Thread with Scoop

!\[Screenshot: Drag and drop file upload]

### Method 3: In-Channel Upload

```
@Scoop analyze this data [attach file]
```

**Note**: Channel uploads create private datasets by default

### Method 4: Multiple File Upload

Upload multiple related files:
```
You: [Upload customers.csv + orders.xlsx + products.csv]

Scoop: 📁 Received 3 files. Analyzing relationships...
✅ Created unified dataset with automatic joins
```

## The Upload Experience

### 1️⃣ Immediate Recognition

```
Scoop: 📊 New file detected: "revenue_analysis.xlsx"

File Overview:
• Size: 3.2 MB
• Rows: 45,832
• Columns: 12
• Date Range: Jan 2023 - Dec 2023

Would you like to:
[📥 Import & Analyze] [👁 Preview First] [❌ Cancel]
```

### 2️⃣ Smart Processing

```
Scoop: 🔄 Processing your file...

✓ Detecting data types
✓ Analyzing structure
✓ Finding patterns
✓ Preparing for queries

⏱ Estimated time: 8 seconds
```

!\[Screenshot: File processing status messages]

### 3️⃣ Intelligent Confirmation

```
Scoop: ✅ Import Complete!

📊 Dataset: Q4 Sales Performance
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Summary:
• 45,832 transactions
• $12.4M total revenue
• 3,421 unique customers
• 156 products

Key Fields Detected:
• 📅 Order Date (Daily data)
• 💰 Revenue (USD)
• 👤 Customer Name & Segment
• 📦 Product Category & SKU
• 📍 Region & Territory

🎯 Suggested Analyses:
1. "Show revenue trends over time"
2. "Which products drive most profit?"
3. "Segment customers by value"
4. "Find seasonal patterns"
5. "Predict next month's revenue"

What would you like to explore?
```

## Data Preparation Best Practices

### ✅ Ideal File Structure

**Perfect CSV Example:**
```csv
Date,Customer,Product,Revenue,Quantity,Region
2024-01-15,Acme Corp,Widget Pro,5000,10,North
2024-01-16,TechCo,Service Plan,3500,1,South
2024-01-17,GlobalInc,Enterprise Suite,12000,3,West
```

**Perfect Excel Structure:**
- Row 1: Clear column headers
- Row 2+: Consistent data
- No merged cells
- No subtotals in data
- Dates in standard format

### ❌ Common Issues to Avoid

**Problem: Multiple Header Rows**
```
❌ Sales Report
❌ Q4 2024 Results
❌ Updated: January 2024
Customer | Revenue | Date | Product
```

**Solution: Single Header Row**
```
✅ Customer,Revenue,Date,Product
```

**Problem: Embedded Calculations**
```
❌ North Region,45000
❌ South Region,32000
❌ TOTAL:,77000  ← Remove this
```

**Solution: Pure Data**
```
✅ North Region,45000
✅ South Region,32000
```

!\[Screenshot: Good vs bad file formats]

### 🛠 Pre-Upload Checklist

- [ ] Single header row
- [ ] No merged cells
- [ ] Remove totals/subtotals
- [ ] Standard date formats
- [ ] Consistent data types per column
- [ ] No embedded formulas in CSV
- [ ] UTF-8 encoding for special characters

## Advanced Upload Features

### 📊 Multi-Sheet Excel Intelligence

```
Scoop: 📚 Found 4 sheets in your workbook:

1. "Sales Data" (45K rows) - Transaction details
2. "Customer List" (3.4K rows) - Customer master
3. "Products" (156 rows) - Product catalog
4. "Summary" - Pivot table detected

Currently analyzing "Sales Data". 

Commands:
• "analyze the Customer List sheet"
• "combine Sales and Customers data"
• "use all sheets together"
```

### 🔄 Automatic Data Enhancement

Scoop automatically:
- **Detects relationships** between tables
- **Standardizes dates** across formats
- **Recognizes currencies** and converts
- **Identifies hierarchies** (Category → Subcategory)
- **Suggests calculated fields**:

```
Scoop: 💡 Detected opportunities for enrichment:

✓ Calculate profit margin (Revenue - Cost)
✓ Compute customer lifetime value
✓ Add fiscal quarter/year
✓ Create customer segments
✓ Flag high-value transactions

Would you like me to add these?
[Add All] [Select Individual] [Skip]
```

### 🔗 Joining Multiple Files

```
You: [Upload customers.csv and orders.csv]

Scoop: 🔗 Relationship detected!
- Common field: "customer_id"
- Join type: Orders → Customers
- Match rate: 98.5%

✅ Files automatically joined. Ask questions across both:
"Which customer segment has highest order value?"
```

## After Upload: Immediate Actions

### 🎯 Quick Exploration Commands

**Data Overview**
```
"describe this dataset"
"show me summary statistics"
"what does this data contain?"
```

**Initial Analysis**
```
"show top 10 by revenue"
"find patterns in the data"
"any anomalies I should know about?"
```

**Visualization**
```
"create a revenue trend chart"
"visualize customer distribution"
"show correlation matrix"
```

### 💾 Dataset Management

Your uploaded data becomes a personal dataset:

```
Scoop: 💼 Dataset saved as "Q4 Sales Analysis"

Options:
• 🔄 "refresh with new file"
• 🏷 "rename to 2024 Revenue"
• 🔗 "combine with other dataset"
• 🗑 "delete this dataset"
• 👥 "share with team" (creates copy)
```

### 🚀 Power User Features

**Schedule Refreshes**
```
"update this dataset every Monday with new file"
```

**Create Views**
```
"save this filtered view as 'Enterprise Customers'"
```

**Build Templates**
```
"create a reusable analysis template from this"
```

## Sharing Insights from Uploads

### 🔒 Privacy-First Sharing

Uploaded data stays private until you choose to share:

1. **Analyze privately** in DM
2. **Find insights** worth sharing
3. **Share results** not raw data
4. **Team sees** only what you share

### 📤 Sharing Options

```
[Share Insight] - Shares specific finding
[Share Dataset] - Creates team copy
[Export Results] - Downloads analysis
[Create Report] - Formatted summary
```

## Troubleshooting

### 🚨 Common Issues & Solutions

**"File won't upload"**
- Check size < 100MB
- Ensure .xlsx/.xls/.csv format
- Verify Slack permissions
- Try drag-and-drop instead

**"No data found"**
- Ensure data starts in cell A1
- Remove blank rows/columns
- Check for hidden sheets
- Verify file isn't empty

**"Import failed"**
- Simplify complex layouts
- Remove pivot tables
- Convert to CSV if needed
- Check special characters

**"Wrong data types"**
```
You: "revenue showing as text"
Scoop: "I'll convert that to numbers"
```

### 🆘 Getting Help

```
Scoop: ❌ Upload failed: Complex layout detected

Here's how to fix it:
1. Save data as new sheet
2. Remove formatting
3. Export as CSV
4. Upload again

[📖 Detailed Guide] [💬 Contact Support]
```

## Security & Compliance

### 🔐 Enterprise-Grade Security

- **Encryption**: In transit and at rest
- **Isolation**: Workspace-level separation
- **Access Control**: Permission-based sharing
- **Audit Trail**: All actions logged
- **Retention**: Configurable policies
- **Compliance**: SOC2 certified

### 🛡 Data Handling

Your uploaded files are:
- ✅ Processed in isolated environment
- ✅ Stored in your workspace only
- ✅ Never used for training
- ✅ Deletable on demand
- ✅ Subject to your retention policy

## Pro Tips

### 🚀 Upload Productivity Hacks

1. **Batch Upload**: Select multiple files at once
2. **Quick Context**: Add description while uploading
3. **Template Files**: Keep clean templates ready
4. **Naming Convention**: Use descriptive filenames
5. **Version Control**: Include dates in filenames

### 📊 Analysis Shortcuts

```
"qa" → Quick analysis (summary + charts)
"patterns" → Find all patterns automatically
"ml" → Run all ML analyses
"export all" → Get complete analysis package
```

### 🎯 Best Use Cases

**Weekly Reports**
```
Upload Monday morning → Instant insights → Share in standup
```

**Ad-Hoc Requests**
```
"Can you analyze this?" → Upload → Answer in minutes
```

**Data Validation**
```
Upload new data → Compare to baselines → Spot issues
```

## Next Steps

Ready to go deeper?

1. 📊 **[Working with Datasets](working-with-datasets-in-scoop-for-slack.md)** - Manage your data
2. 📈 **[Visualizations & Exports](visualizations-exports.md)** - Beautiful charts
3. 🤖 **[Machine Learning Analytics](machine-learning-analytics.md)** - Advanced analysis
4. 🚀 **[Advanced Features](advanced-features.md)** - Deep reasoning & automation

---

**Pro tip**: Start with a simple CSV file to get comfortable, then explore multi-sheet Excel workbooks and advanced features. Your data journey begins with a single upload! 🚀