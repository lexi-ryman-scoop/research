---
title: Scoop Documentation
excerpt: Your autonomous AI data analyst
deprecated: false
hidden: false
metadata:
  title: Scoop Documentation
  description: Documentation for Scoop Analytics - the autonomous AI data analyst that investigates your data like a senior analyst would.
  robots: index
---

# Welcome to Scoop Documentation

Scoop is the world's first **autonomous AI data analyst** - an AI that thinks, investigates, and discovers insights like a senior analyst would, in seconds instead of days.

---

## Getting Started

New to Scoop? Start here to understand what makes Scoop different.

| Guide | Description |
|-------|-------------|
| [What is Scoop?](Start%20Guide/what-is-scoop.md) | Overview of Scoop's capabilities |
| [Meet Your AI Data Analyst](Start%20Guide/meet-your-ai-data-analyst.md) | How Scoop thinks and investigates |
| [The Power of Why](Start%20Guide/the-power-of-why.md) | Deep investigations that find root causes |
| [Investigation Patterns](Start%20Guide/investigation-patterns.md) | Common analysis patterns and examples |

---

## Choose Your Platform

### Scoop for Slack
Bring AI analytics directly into your Slack workspace.

- [Getting Started](Scoop%20for%20Slack/scoop-for-slack/getting-started-with-scoop-for-slack.md)
- [Using Direct Messages](Scoop%20for%20Slack/scoop-for-slack/using-scoop-in-direct-messages.md)
- [Using in Channels](Scoop%20for%20Slack/scoop-for-slack/using-scoop-in-channels.md)
- [Machine Learning Analytics](Scoop%20for%20Slack/scoop-for-slack/machine-learning-analytics.md)

### Web Application
Full-featured analytics with canvases and presentations.

- [Canvases & Presentations](Canvases/what-is-a-canvas-and-what-can-it-do.md)
- [Creating Charts](Exploring%20and%20Visualizing%20Data/how-to-create-a-chart.md)
- [Creating KPIs](Exploring%20and%20Visualizing%20Data/how-to-create-a-kpi.md)

---

## Connect Your Data

### Quick Start
- [Choose a Data Source](Connecting%20to%20Data/connect-your-data/choose-a-data-source.md)
- [Upload a File](Connecting%20to%20Data/connect-your-data/upload-a-file-or-spreadsheet.md)
- [Connect to a Business Application](Connecting%20to%20Data/connect-your-data/connecting-to-a-business-application.md)

### Popular Integrations
- [Salesforce](Connecting%20to%20Data/specific-applications/salesforce.md)
- [HubSpot](Connecting%20to%20Data/specific-applications/hubspot.md)
- [Google Analytics](Connecting%20to%20Data/specific-applications/google-analytics.md)
- [Snowflake](Connecting%20to%20Data/specific-applications/snowflake.md)

[View All Integrations](Connecting%20to%20Data/specific-applications/index.md)

---

## AI-Powered Analytics

### Understanding Scoop's AI
- [AI Analytics Overview](AI%20Analytics/index.md)
- [How Scoop AI Works](Scoop%20for%20Slack/scoop-for-slack/understanding-scoop-ai.md)
- [Automated Dataset Analysis](AI%20Analytics/automated-analysis.md)

### Machine Learning
- [ML Analytics Overview](Scoop%20for%20Slack/scoop-for-slack/machine-learning-analytics.md)
- [Predictive Relationships](AI%20Analytics/ai-presentations/predictive-relationships.md)
- [Segmentation & Clustering](AI%20Analytics/ai-presentations/segmentationclustering-common-groups.md)
- [Group Comparisons](AI%20Analytics/ai-presentations/grouppopulation-comparisons.md)

---

## Advanced Features

### Process Mining
- [Process Mining Overview](Process%20Mining/scoop-process-mining.md)
- [Process Analysis](Process%20Mining/process-analysis.md)

### Data Preparation
- [Dataset Basics](Preparing%20Datasets/scoop-dataset-basics/index.md)
- [Calculated Columns](Preparing%20Datasets/adding-calculated-columns.md)
- [Blending Datasets](Preparing%20Datasets/blending-two-datasets/index.md)
- [Snapshot Datasets](Preparing%20Datasets/scoop-dataset-basics/snapshot-datasets.md)

### Enterprise Features
- [Enterprise Overview](Enterprise%20Features/index.md)
- [Admin Guide](Enterprise%20Features/admin-guide.md)
- [Security & Compliance](Enterprise%20Features/security-compliance.md)
- [Bring Your Own Key (BYOK)](Enterprise%20Features/bring-your-own-key-byok.md)
- [CRM Writeback](Enterprise%20Features/crm-writeback.md)

---

## Compare Scoop

| Resource | Description |
|----------|-------------|
| [Scoop vs Traditional BI](comparisons/scoop-vs-traditional-bi.md) | Why Scoop is different from dashboards |
| [Technical Blueprint](Start%20Guide/scoop-technical-blueprint.md) | Architecture and capabilities |

---

## Need Help?

- **Slack**: Type `@Scoop help` in any channel
- **Email**: support@scoopanalytics.com
- **FAQ**: [Troubleshooting Guide](Scoop%20for%20Slack/scoop-for-slack/faq-troubleshooting.md)
