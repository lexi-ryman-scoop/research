---
title: Installing Scoop for Sheets Plugin for Google Sheets
excerpt: 'Set up the plugin to query Scoop data from Google Sheets'
deprecated: false
hidden: false
metadata:
  title: Installing Scoop for Sheets Plugin
  description: >-
    To install the Scoop for Sheets plugin, go to "Extensions" > "Add-ons" >
    "Get Add-ons", search for "Scoop for Sheets", select it, click "Install",
    verify your account, and grant the necessary permissions.
  robots: index
next:
  description: ''
---

The Scoop for Sheets plugin connects your Google Sheets to your Scoop datasets, enabling you to pull live data directly into your spreadsheets.

# Prerequisites

Before installing:

| Requirement | Description |
|-------------|-------------|
| **Scoop Account** | Active Scoop account with workspace access |
| **Google Account** | Google account for Google Sheets |
| **Live Worksheet** | The plugin only works with Scoop-linked Live Worksheets |

# Installation Steps

## Step 1: Open Google Workspace Marketplace

In any Google Sheet:

1. Click **Extensions** in the menu bar
2. Select **Add-ons**
3. Click **Get add-ons**

![](https://files.readme.io/29ab379-image.png)

## Step 2: Find Scoop for Sheets

In the Google Workspace Marketplace:

1. Search for **"Scoop for Sheets"**
2. Select the Scoop for Sheets add-on from the results

![](https://files.readme.io/af790ce-image.png)

## Step 3: Install

1. Click **Install**
2. Verify you're using the correct Google account
3. Review the permissions requested
4. Click **Allow** to grant necessary permissions

## Permissions Explained

The plugin requests these permissions:

| Permission | Purpose |
|------------|---------|
| **View and manage spreadsheets** | Read worksheet structure, write query results |
| **Connect to external service** | Communicate with Scoop servers for data |
| **Display content** | Show the plugin sidebar interface |

These permissions are standard for spreadsheet add-ons and are used only for Scoop functionality.

# After Installation

## Opening the Plugin

1. Open a **Live Worksheet** (not a regular Google Sheet)
2. Go to **Extensions → Scoop for Sheets → Manage Queries**
3. The plugin sidebar opens

## First-Time Setup

On first use:
1. You may be prompted to sign in to Scoop
2. The plugin connects to your Scoop workspace
3. Your datasets become available for querying

## Verifying Installation

The plugin is correctly installed when:
- "Scoop for Sheets" appears in the Extensions menu
- The sidebar opens without errors
- Your datasets are visible in the query builder

# Troubleshooting Installation

## Plugin Not Appearing

- Refresh the Google Sheet
- Close and reopen the browser tab
- Clear browser cache
- Try a different browser

## Permission Errors

- Ensure you're logged into the correct Google account
- Check that third-party cookies are enabled
- Verify your organization allows Google Workspace add-ons

## "Not a Live Worksheet" Error

The plugin only works with Scoop-linked worksheets:
1. Go to Scoop → Live Worksheets
2. Create a new Live Worksheet or open an existing one
3. Use the plugin in that worksheet

## Connection Issues

If the plugin can't connect to Scoop:
- Verify your Scoop session is active (log into Scoop in another tab)
- Check your internet connection
- Try signing out and back into the plugin

# Updating the Plugin

Google automatically updates add-ons. To manually check:

1. Go to **Extensions → Add-ons → Manage add-ons**
2. Find Scoop for Sheets
3. Click the three-dot menu → **Check for updates**

# Removing the Plugin

To uninstall:

1. Go to **Extensions → Add-ons → Manage add-ons**
2. Find Scoop for Sheets
3. Click the three-dot menu → **Remove**

# Next Steps

After installation:
- [Create a query](scoop-for-sheets-plugin) - Pull Scoop data into your spreadsheet
- [Create a Live Worksheet](creating-a-livesheet) - Set up Scoop-connected spreadsheets
- [Embed on canvas](adding-a-named-range-to-a-canvas) - Display spreadsheet data on canvases
