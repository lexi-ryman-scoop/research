---
title: Google Sheets Plugin
excerpt: 'Query Scoop datasets and inject live data into your spreadsheets'
deprecated: false
hidden: false
metadata:
  title: Google Sheets Plugin
  description: >-
    The Scoop for Sheets plugin allows users to query Scoop datasets and inject
    live data into Google Sheets, with options to edit and refresh queries
    individually or all at once, and advanced control through direct
    modification of the underlying query sheet.
  robots: index
next:
  description: ''
---

The Scoop for Sheets plugin brings live Scoop data directly into your Google Sheets. Create queries that pull from your datasets, and the results populate dedicated sheets that refresh on demand or automatically.

<Image align="center" width="300px" src="https://files.readme.io/3baa788-image.png" />

# How the Plugin Works

Each query you create:
1. Is defined in a hidden "Scoop Queries" configuration sheet
2. Populates its own dedicated data sheet with results
3. Can be refreshed individually or all at once
4. Supports filters, date ranges, and column selection

```
┌─────────────────────────────────────────────────────┐
│                Your Live Worksheet                   │
├─────────────────────────────────────────────────────┤
│  [Scoop Queries]    ← Hidden config sheet           │
│  [Sales Data]       ← Query 1 results               │
│  [Customer List]    ← Query 2 results               │
│  [Analysis]         ← Your formulas referencing     │
│                       the data sheets               │
└─────────────────────────────────────────────────────┘
```

# Creating a Query

## Using the Plugin UI

1. Open your Live Worksheet in Google Sheets
2. Go to **Extensions → Scoop for Sheets → Manage Queries**
3. Click **New Query**
4. Configure your query:

| Setting | Description |
|---------|-------------|
| **Dataset** | Select which Scoop dataset to query |
| **Columns** | Choose which columns to include |
| **Filters** | Add conditions to limit results |
| **Date Range** | Specify start and end dates |
| **Sheet Name** | Name for the results sheet |

5. Click **Execute** to run the query and populate the sheet

## Query Results

When executed, your query creates a sheet with:
- Column headers in the first row
- Data rows below
- Formatting preserved from the dataset

The results sheet is a standard Google Sheet—you can reference it from other sheets, create charts, or use it as input to formulas.

# Managing Multiple Queries

## Refresh Options

| Action | Description |
|--------|-------------|
| **Refresh Single** | Re-run one query to update its sheet |
| **Refresh All** | Re-run all queries in the workbook |

## Editing Queries

1. Open the plugin (**Extensions → Scoop for Sheets**)
2. Select the query from the list
3. Modify settings
4. Execute to apply changes

## Deleting Queries

Removing a query:
- Deletes the query definition
- Optionally removes the results sheet
- Does not affect formulas that reference the data (they'll show errors)

# Advanced: The Query Definition Sheet

For advanced control, work directly with the underlying query configuration.

## Showing the Query Sheet

Click **"Show Query Tab"** in the plugin to reveal the hidden "Scoop Queries" sheet. This sheet contains the actual query definitions that drive data retrieval.

## Query Sheet Structure

Each query is defined in columns:

```
┌────────────────────────────────────────────────────────────┐
│ Row             │ Query 1      │ Query 2      │ ...        │
├────────────────────────────────────────────────────────────┤
│ Sheet Name      │ Sales Data   │ Customers    │            │
│ Dataset ID      │ D123456      │ D789012      │            │
│ Start Date      │ 2024-01-01   │ =TODAY()-30  │ ← Formula! │
│ End Date        │ 2024-12-31   │ =TODAY()     │ ← Formula! │
│ Column 1        │ Revenue      │ Name         │            │
│ Column 2        │ Region       │ Email        │            │
│ Filter Type     │ Equals       │              │            │
│ Filter Column   │ Region       │              │            │
│ Filter Value 1  │ West         │              │            │
│ Filter Value 2  │ East         │              │            │
└────────────────────────────────────────────────────────────┘
```

## Formula-Driven Parameters

The power of direct sheet editing is using formulas for query parameters:

### Dynamic Date Ranges

```
Start Date: =EOMONTH(TODAY(),-1)+1    ← First of current month
End Date:   =EOMONTH(TODAY(),0)       ← Last of current month
```

```
Start Date: =DATE(YEAR(TODAY()),1,1)  ← January 1 of current year
End Date:   =TODAY()                   ← Today
```

### Calculated Filters

```
Filter Value: =TEXT(YEAR(TODAY()),"0000")  ← Current year as text
```

```
Filter Value: =IF(MONTH(TODAY())<=6,"H1","H2")  ← Current half
```

### Cell References

```
Filter Value: =Settings!B2  ← Reference another cell for the value
```

This allows you to create a "Settings" sheet where users change a single cell to filter all queries.

## Filter Syntax

In the query sheet, filters are defined with:

| Row | Purpose | Example Values |
|-----|---------|----------------|
| Filter Type | The operator | Equals, NotEquals, Contains, GreaterThan, LessThan |
| Filter Column | Which column to filter | Region, Status, Amount |
| Filter Value 1 | First value | West |
| Filter Value 2+ | Additional values (for multi-select) | East, Central |

## Best Practices for Query Sheets

- **Don't delete rows**—the structure is fixed
- **Use formulas** for dynamic parameters
- **Test in the UI first**, then copy the pattern to the sheet
- **Keep formulas simple** to avoid calculation errors

# Use Cases

## Automated Weekly Reports

Create queries with rolling date windows:

```
Start Date: =TODAY()-7
End Date:   =TODAY()
```

Refresh every Monday to get last week's data.

## Parameterized Dashboards

Create a "Parameters" sheet with:
- Region selector (dropdown)
- Date range inputs
- Threshold values

Reference these in your query sheet so changing one cell updates all queries.

## Data Blending

Pull data from multiple datasets into separate sheets, then combine with formulas:

```
Sheet1: Sales data from CRM
Sheet2: Cost data from ERP
Sheet3: =VLOOKUP to join and calculate margin
```

## Snapshot Comparisons

Create multiple queries against the same dataset with different date ranges:

- Query 1: This month
- Query 2: Last month
- Query 3: Year-over-year

Then calculate changes with formulas.

# Troubleshooting

## Query Returns No Data

- Verify the dataset has data for the specified date range
- Check filter values match actual data (case-sensitive)
- Ensure you have access to the dataset

## Formulas Not Calculating

- Formula cells must start with `=`
- Check for circular references
- Verify cell references are valid

## Plugin Not Appearing

- Ensure you're in a Live Worksheet (not a regular Google Sheet)
- Reinstall the plugin if needed
- Check browser extensions aren't blocking it

## Refresh Fails

- Check your Scoop session is active
- Verify dataset still exists and is accessible
- Look for error messages in the plugin

> 📘 **Tip**: Scoop uses spreadsheet logic, so AI tools like ChatGPT can help you create and refine formulas for dynamic query parameters.

# Related Topics

- [Creating a Live Worksheet](creating-a-livesheet) - Set up cloud-connected spreadsheets
- [Installing Scoop for Sheets](installing-scoop-plugin-for-google-sheets) - Plugin installation
- [Embedding Named Ranges](adding-a-named-range-to-a-canvas) - Display spreadsheet data on canvases
- [Dataset Queries](../Preparing%20Datasets/dataset-queries) - Query syntax reference
