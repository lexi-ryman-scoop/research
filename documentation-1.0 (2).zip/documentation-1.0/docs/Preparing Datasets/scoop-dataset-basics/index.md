---
title: Understanding Scoop Datasets
excerpt: How Scoop's AI automatically structures and understands your data
deprecated: false
hidden: false
metadata:
  title: Understanding Scoop Datasets
  description: >-
    Learn how Scoop's AI automatically analyzes, structures, and understands your data -
    eliminating manual setup and enabling immediate investigation.
  robots: index
next:
  description: ''
---

# Understanding Scoop Datasets

When you bring data into Scoop, something powerful happens: **Scoop's AI immediately analyzes and understands your data** - identifying structure, data types, relationships, and meaning. This is fundamentally different from traditional tools that require manual configuration.

---

## How Scoop's AI Understands Your Data

### Automatic Analysis

When you upload a file or connect a data source, Scoop's AI:

1. **Detects Structure** - Identifies columns, rows, headers, and embedded totals/subtotals
2. **Infers Data Types** - Determines which fields are dates, numbers, categories, or text
3. **Discovers Relationships** - Understands how columns relate to each other
4. **Generates Semantics** - Creates human-readable descriptions of what each column means
5. **Calculates Statistics** - Runs summary statistics (min, max, distribution, outliers)

> **Result**: Within seconds, Scoop knows enough about your data to start answering questions - no manual setup required.

### The Dataset "Fingerprint"

Scoop creates a unique fingerprint for each dataset based on:
- Column structure and names
- Data types and patterns
- Embedded relationships

This fingerprint allows Scoop to:
- Recognize when new data matches an existing dataset
- Automatically merge updates with historical data
- Track changes over time without manual configuration

---

## Why This Matters

### Traditional BI Approach
```
1. Upload data
2. Manually define column types
3. Create relationships
4. Build calculated fields
5. Configure time handling
6. Finally... start analyzing
```
**Time to first insight: Hours to days**

### Scoop's AI Approach
```
1. Upload data
2. Ask a question
```
**Time to first insight: Seconds**

Scoop eliminates the technical overhead that typically requires a data team. Business users can go from raw data to investigation immediately.

---

## Dataset Types

### Basic Datasets
For transactional data where each row is a unique event:
- Sales transactions
- Support tickets
- Log entries

Each new data load adds to the dataset without replacing existing data.

### Snapshot Datasets
For data that represents a point-in-time state:
- Pipeline reports (deals change status over time)
- Inventory levels
- Employee rosters

Scoop automatically tracks changes, enabling powerful analysis:
- "What changed since last month?"
- "How long did deals stay in each stage?"
- "Which items moved from X to Y?"

[Learn more about Snapshot Datasets](snapshot-datasets.md)

---

## Intelligent Date Handling

Scoop recognizes that datasets often have multiple dates:
- **Load Date** - When data was brought into Scoop
- **Event Date** - When something happened (e.g., sale date)
- **Status Date** - When a snapshot was taken

Scoop automatically:
- Identifies which columns contain dates
- Understands their meaning
- Allows analysis by any date dimension

[Learn more about Date Handling](intelligent-handling-dates-in-data.md)

---

## Connecting to Data

Scoop can ingest data from:

- **File uploads** - CSV, Excel, and more
- **Connected applications** - 100+ SaaS integrations (Salesforce, HubSpot, etc.)
- **Databases** - Direct SQL connections for custom queries

See [Connecting to a Database](doc:connecting-to-a-database) for database setup.

---

## In This Section

| Guide | Description |
|-------|-------------|
| [How Scoop Derives a Dataset](how-scoop-derives-a-dataset-from-a-report.md) | Technical details of data analysis |
| [Snapshot Datasets](snapshot-datasets.md) | Tracking changes over time |
| [Intelligent Date Handling](intelligent-handling-dates-in-data.md) | Multi-date analysis |

---

## Next Steps

Once your data is in Scoop, you can immediately start investigating:

- Ask questions in natural language
- Let the AI find patterns and anomalies
- Generate presentations automatically

The goal is simple: **eliminate the technical barrier between you and your data insights**.
