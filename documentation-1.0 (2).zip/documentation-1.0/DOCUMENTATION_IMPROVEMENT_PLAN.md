# Documentation Improvement Plan

**Created**: November 24, 2025
**Status**: Ready for Implementation
**Estimated Effort**: 2-3 days total

---

## Executive Summary

Based on a thorough review of the documentation, the content is well-aligned with the "AI Data Analyst" positioning but has structural issues, gaps, and some stale content. This plan addresses these in priority order.

---

## Phase 1: Cleanup (Day 1 - 2-3 hours)

### 1.1 Remove Deprecated Content
- [x] Delete `docs/Start Guide/scoop-quick-start-guide.md` (marked deprecated, contains old "agentic platform" messaging) ✅ DONE

### 1.2 Fix Broken References
- [x] Verified `doc:` references - these are readme.com slug syntax and resolve correctly ✅ DONE
- Note: `doc:process-analysis` → points to `Advanced Analysis with Insights/process-analysis.md` (exists)
- Note: `doc:connecting-to-a-database` → points to `connecting-to-a-database-1.md` (exists)

### 1.3 Rename Folders (Filesystem/URL Safety)
Current folders with colons cause issues:
- [x] `Scoop AI:Automated Dataset Analysis` → `Scoop AI - Automated Dataset Analysis` ✅ DONE
- [x] `Scoop AI:Data Science` → `Scoop AI - Data Science` ✅ DONE

**Note**: This may require readme.com configuration updates.

### 1.4 Fix Positioning Inconsistencies
- [x] `docs/Scoop AI - Automated Dataset Analysis/automated-dataset-analysis.md` - Already aligned with AI analyst positioning ✅ DONE
- [x] `docs/Scoop AI - Data Science/unlocking-the-power-of-ai-in-scoop-analytics/index.md` - Updated "AI-powered partner" → "autonomous AI data analyst" ✅ DONE

---

## Phase 2: Structure Improvements (Day 1-2 - 4-6 hours)

### 2.1 Create Navigation Hub ✅ DONE (Day 1)
Created `docs/index.md` as documentation home:

```markdown
# Scoop Documentation

Welcome to Scoop - your autonomous AI data analyst.

## Getting Started
- [Meet Your AI Data Analyst](Start Guide/meet-your-ai-data-analyst.md)
- [The Power of Why](Start Guide/the-power-of-why.md)
- [Investigation Patterns](Start Guide/investigation-patterns.md)

## By Platform
- [Scoop for Slack](Scoop for Slack/scoop-for-slack/index.md)
- [Web Application](Canvases/what-is-a-canvas-and-what-can-it-do.md)

## Connect Your Data
- [Data Sources Overview](Connecting to Data/connect-your-data/index.md)
- [Specific Applications](Connecting to Data/specific-applications/index.md)

## Advanced Features
- [Machine Learning Analytics](Scoop for Slack/scoop-for-slack/machine-learning-analytics.md)
- [Process Mining](Process Mining/scoop-process-mining.md)
- [Enterprise Features](Enterprise Features/index.md)
```

### 2.2 Consolidate AI Sections
The current split between "Automated Dataset Analysis" and "Data Science" is confusing.

**Action**: Merge into single section `AI Analytics`:
- [ ] Create `docs/AI Analytics/index.md` as section overview
- [ ] Move `automated-dataset-analysis.md` → `AI Analytics/automated-analysis.md`
- [ ] Move `unlocking-the-power-of-ai-in-scoop-analytics/*` → `AI Analytics/`
- [ ] Update all internal links
- [ ] Archive old folders

### 2.3 Clean Up Orphan Sections
These sections have only 1 file - either expand or merge:

| Section | Files | Action |
|---------|-------|--------|
| `Recipes/` | 1 | Expand (Phase 3) or merge into Start Guide |
| `Reference/` | 1 | Expand (Phase 3) or merge into relevant section |
| `Advanced Analysis with Insights/` | 1 | Merge into AI Analytics |
| `3rd Party Enriched Partners/` | 1 | Rename to `Integrations - Third Party` or merge |

---

## Phase 3: Content Gaps (Day 2-3 - 6-8 hours)

### 3.1 Update Stale Content

**`docs/Preparing Datasets/scoop-dataset-basics/index.md`** (22 lines - too short)
- [ ] Expand with AI analyst framing
- [ ] Add examples of how Scoop understands data automatically
- [ ] Link to relevant AI features

### 3.2 Expand Recipes Section ✅ COMPLETE
Created 5 practical investigation recipes:

- [x] `Recipes/pipeline-investigation.md` - "Why did pipeline shrink?"
- [x] `Recipes/churn-investigation.md` - "What predicts churn?"
- [x] `Recipes/marketing-attribution.md` - "Which campaigns drive quality leads?"
- [x] `Recipes/team-performance-comparison.md` - "What differentiates top performers?"
- [x] `Recipes/period-comparison.md` - "What changed this quarter vs last?"

**Template for each recipe**:
```markdown
# Recipe: [Title]

## The Question
[What business question this answers]

## Sample Prompts
- "Why did..."
- "What predicts..."
- "Compare..."

## What Scoop Investigates
[Multi-probe investigation flow]

## Example Output
[Screenshot or formatted example]

## Follow-up Questions
[Natural next questions to ask]
```

### 3.3 Add Security & Compliance Page
Create `docs/Enterprise Features/security-compliance.md`:

- [ ] SOC 2 Type II certification
- [ ] Data encryption (at rest, in transit)
- [ ] GDPR compliance
- [ ] Data isolation (multi-tenant)
- [ ] Access controls
- [ ] Audit logging
- [ ] Data retention policies

### 3.4 Add Admin Guide
Create `docs/Enterprise Features/admin-guide.md`:

- [ ] User management (inviting, roles)
- [ ] Workspace configuration
- [ ] Dataset permissions
- [ ] Slack channel sharing
- [ ] BYOK configuration (link to existing doc)

---

## Phase 4: Nice-to-Have Improvements (Future)

### 4.1 Industry-Specific Guides
- [ ] `guides/saas-analytics.md` - MRR, churn, cohorts
- [ ] `guides/ecommerce-analytics.md` - CAC, LTV, funnel
- [ ] `guides/sales-analytics.md` - Pipeline, win rate, velocity

### 4.2 API Reference (If/When Needed)
- [ ] REST API endpoints
- [ ] Authentication
- [ ] Rate limits
- [ ] Code examples

### 4.3 Changelog
- [ ] `changelog.md` - Version history and new features

---

## Implementation Checklist

### Day 1: Cleanup & Structure ✅ COMPLETE (Nov 24, 2025)
- [x] Delete deprecated files
- [x] Verify broken links (readme.com slugs resolve correctly)
- [x] Rename folders (colons removed)
- [x] Create docs/index.md navigation hub
- [x] Fix positioning language inconsistencies
- [x] Update _order.yaml with new folder names

### Day 2: Content Consolidation ✅ COMPLETE (Nov 24, 2025)
- [x] Merge AI sections into new `AI Analytics/` folder
- [x] Handle orphan sections (moved to appropriate locations)
- [x] Update scoop-dataset-basics with AI framing
- [x] Create 5 investigation recipes (pipeline, churn, period-comparison, marketing-attribution, team-performance)
- [x] Update navigation hub with new paths

### Day 3: Gap Filling ✅ COMPLETE (Nov 24, 2025)
- [x] Create security-compliance.md (SOC2, GDPR, encryption, compliance)
- [x] Create admin-guide.md (users, workspaces, settings, Slack)
- [x] Update Enterprise Features index with new docs
- [x] Update navigation hub with enterprise links

---

## Files to Delete
```
docs/Start Guide/scoop-quick-start-guide.md
```

## Files to Create
```
docs/index.md
docs/AI Analytics/index.md
docs/Enterprise Features/security-compliance.md
docs/Enterprise Features/admin-guide.md
docs/Recipes/sales-pipeline-investigation.md
docs/Recipes/customer-churn-analysis.md
docs/Recipes/marketing-attribution.md
docs/Recipes/team-performance-comparison.md
docs/Recipes/time-period-analysis.md
```

## Files to Move/Rename
```
Scoop AI:Automated Dataset Analysis/ → AI Analytics/
Scoop AI:Data Science/ → (merge into AI Analytics/)
Advanced Analysis with Insights/ → (merge into AI Analytics/)
```

---

## Notes

- **ML Sidecar**: Implementation detail, not mentioned in user docs
- **Domain Intelligence**: Internal feature, not documented externally yet
- **Investigation Coordinator**: Referenced in "deep reasoning" but implementation details excluded
- **Embed Auth**: Not yet documented (still in testing)
- **GDPR**: Removed all GDPR compliance claims (not currently compliant) - Nov 24, 2025
- **Customer References**: EventBrite anonymized to "Global Events Platform" (no permission) - Nov 24, 2025

---

## Success Criteria

After implementation:
1. No broken internal links
2. No deprecated content
3. Clear navigation from docs home
4. Every section has 2+ substantive pages
5. Security/compliance documented for enterprise buyers
6. 5+ practical recipes for new users
7. Consistent "AI data analyst" positioning throughout
